﻿param(

 [Parameter(Mandatory=$True)]
 [string]
 $azureSPLoginID,

 [Parameter(Mandatory=$True)]
 [string]
 $azureSPPasswordFilePath

)

#sign in
Write-Verbose "Validating the input parametrers ";
if ((Test-Path $azureSPPasswordFilePath))
{

$azureLoginPassword = Get-Content -Path $azureSPPasswordFilePath | ConvertTo-SecureString

 #Set the powershell credential object
 $azureLoginCreds = New-Object -TypeName System.Management.Automation.PSCredential($azureSPLoginId ,$azureLoginPassword)
 Write-Verbose "Logging in...";
 $azureLoginContext = Login-AzureRmAccount -ServicePrincipal -Credential $azureLoginCreds -TenantId "ff9c7474-421d-4957-8d47-c4b64dec87b5";
 $azureSubcription = $azureLoginContext.Context.Subscription

 if($azureSubcription)
 {

   Write-Verbose "Logged-In Successfully..!!!!"

  #Write-Host "SubscriptionID : " $azureLoginContext.Context.Subscription.Id -ForegroundColor Green
  #Write-Host "SubscriptionName : " $azureLoginContext.Context.Subscription.Name -ForegroundColor Green
  #Write-Host "TenantID : " $azureLoginContext.Context.Tenant.TenantId -ForegroundColor Green
  #Write-Host "Environment :" $azureLoginContext.Context.Environment.Name -ForegroundColor Green
  
  
 }
  Else{
 
        Write-Error "Azure Login has failed..!!!!" 
     }

}