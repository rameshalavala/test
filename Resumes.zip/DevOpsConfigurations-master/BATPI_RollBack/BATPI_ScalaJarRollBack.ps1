﻿###############################DeployScalaJars###############################################################################################
#NAME: RollbackScalaJars.ps1
#AUTHOR: 
#DATE: 
#DESCRIPTION: This script will rollback the Scala Jars artifacts to specified environment of azure storage account.
#ARGUMENTS: $configurationFilePath
################################DeployScalaJars###############################################################################################

Param(

[Parameter(Mandatory=$True)]
 [string]
 $DeploymentEnv,

 [Parameter(Mandatory=$True)]
 [string]
 $subscriptionId,

 [Parameter(Mandatory=$True)]
 [string]
 $resourceGroupName,

 [Parameter(Mandatory=$True)]
 [string]
 $blobStorageName,

 [Parameter(Mandatory=$True)]
 [string]
 $containerName,

 [Parameter(Mandatory=$True)]
 [string]
 $DeploymentFolderPath,

 [Parameter(Mandatory=$True)]
 [string]
 $RootFolderName

)


$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"

Write-Verbose "Validating the roll back parameter"

   Write-Output "Getting Deployment configuration"
   #$configurationContext = Get-Content -Path $ConfigurationFilePath | Out-String | ConvertFrom-Json
   Write-Verbose "Initializing the input variabales and parameters"
   #$DeploymentEnv = $configurationContext.Environment 
   #$subscriptionId = $configurationContext.SubscrptionID
   #$resourceGroupName = $configurationContext.ResourceGroupName
   #$deploymentFolderPath = $configurationContext.DeploymentFolderPath
   #$RootFolderName = $configurationContext.ScalaJars.RootFolderName
   $RootFolderPath = (Get-ChildItem -Path $DeploymentFolderPath -Include $RootFolderName -Directory -Recurse).FullName
   #$blobStorageName = $configurationContext.ScalaJars.blobStorageName
   #$containerName = $configurationContext.ScalaJars.containerName
   $packageNumber = Split-Path $deploymentFolderPath -Leaf
  
   Write-Output "----------------------------------Deployment Configuration parameter----------------------------------------- "
   Write-Output "Enviroment Name : $DeploymentEnv"
   Write-Output "SubscriptionID: $subscriptionId"
   Write-Output "Resource Group Name: $resourceGroupName"
   Write-Output "Artifacts Version: $packageNumber"
   Write-Output "RootFolderPath: $RootFolderPath"
   Write-Output "Storage Account Name:  $blobStorageName"
   Write-Output "container Name:  $containerName"
   Write-Output "----------------------------------------End Of parameters-----------------------------------------------------"

   # select subscription
   Write-Output "Selecting subscription '$subscriptionId'";
   $subscriptionContext = Select-AzureRmSubscription -SubscriptionID $subscriptionId;
   Write-Output "Selected Subcription Name: " 
   Write-Output $subscriptionContext

   #Check for existing resource group
   Write-Verbose "Validating the Target deploymment resource"
   #Create or check for target resource 
   $rootFolderExist = Test-Path -Path "$RootFolderPath"
   $resourceNameExist = (Get-AzureRmResource -ResourceName "$blobStorageName" -ResourceGroupName $resourceGroupName).Name

   if(!$RootFolderPath)
   {
     Write-Output "The $RootFolderName directory does not exist in current deployment package."
   }

   elseif(!$resourceNameExist)
   { 
      Write-Error "Resource name '$resourceNameExist' does not exist.Exiting from current deployment";
   }
   
   Else{

         Write-Verbose "Getting storage account..."
         Write-Output "Getting storage account..."
         $StorageAccount = Get-AzureRmStorageAccount -ResourceGroupName $resourceGroupName -Name $blobStorageName;

         $storageAccountContext = $StorageAccount.Context
       
         $container = Get-AzureStorageContainer -Name $containerName -Context $storageAccountContext -ErrorAction SilentlyContinue
 
         $fileList =  Get-ChildItem -Path $RootFolderPath -Include *.jar -Recurse
        If(!$container)
           {
             Write-Warning "Blob Container '$containerName' does not exist, Creating the New container";
             Write-Output "Creating blob container '$containerName' in storage account" $StorageAccount.StorageAccountName;
             Write-Verbose "Creating blob container '$containerName' in storage account"
             $container= New-AzureStorageContainer -Name $containerName -Context $storageAccountContext -Permission Off
           }

          Else
             {
               Write-Verbose "Using existing blob container $containerName";
               Write-Output "Using existing blob container $containerName";
            }

        If($container -and $fileList)
          {
               foreach ($file in $fileList)
                  {
                     Write-Output "Uploading blob to '$containerName' conatiner"; 
                     $fileExtension = $file.Extension
                     $fileBaseName = $file.BaseName
                     $fileFullPath = $file.FullName
                     $fileNameWithExtension = "$fileBaseName" + "$fileExtension"

                    $deploymentContext = Set-AzureStorageBlobContent -File $fileFullPath -Container $containerName -Blob "$fileNameWithExtension" -Context $storageAccountContext -Force 
                
                    
                    Write-Output "-------------------------------------Deployment Context------------------------------------------------------" 
                    $deploymentContext   
                  }
            }

         Else
            {
              Write-Error "Did not find the rollback artifacts.....Exiting from the current deployment";
            }
    }


	
	
	
