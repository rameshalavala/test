﻿param(

 [Parameter(Mandatory=$True)]
 [string]
 $azureLoginID,

 [Parameter(Mandatory=$True)]
 [string]
 $azureLoginPasswordFilePath

)

#sign in
Write-Verbose "Validating the input parametrers ";
if ((Test-Path $azureLoginPasswordFilePath))
{

$azureLoginPassword = Get-Content -Path $azureLoginPasswordFilePath | ConvertTo-SecureString

 #Set the powershell credential object
 $azureLoginCreds = New-Object -TypeName System.Management.Automation.PSCredential($azureLoginId ,$azureLoginPassword)
 Write-Verbose "Logging in...";
 $azureLoginContext = Login-AzureRmAccount -Credential $azureLoginCreds;
 $azureSubcription = $azureLoginContext.Context.Subscription

 if($azureSubcription)
 {

   Write-Verbose "Logged-In Successfully..!!!!"

  #Write-Host "SubscriptionID : " $azureLoginContext.Context.Subscription.Id -ForegroundColor Green
  #Write-Host "SubscriptionName : " $azureLoginContext.Context.Subscription.Name -ForegroundColor Green
  #Write-Host "TenantID : " $azureLoginContext.Context.Tenant.TenantId -ForegroundColor Green
  #Write-Host "Environment :" $azureLoginContext.Context.Environment.Name -ForegroundColor Green
  
  
 }
  Else{
 
        Write-Error "Azure Login has failed..!!!!" 
     }

}