﻿######################################DeployConfigsScripts##############################################################################################
#NAME: DeployConfigsScripts.ps1
#AUTHOR: NileshKumar Rawal
#DATE: 26/03/2019
#DESCRIPTION: This script does the ENV changes in configs scripts mentioned in the input configuration file and deploys the Configs scripts 
#to azure data lake store.
#ARGUMENTS: $configurationFilePath
#######################################DeployConfigsScripts##############################################################################################

Param (
  
 [Parameter(Mandatory=$True)]
 [string]
 $configurationFilePath = "PIAzureDeploymentConfiguration.json",

 [Parameter(Mandatory=$True)]
 [string]
 $DeploymentFolderPath

)

Function ReplaceStringInFile
{
param(
 [Parameter(Mandatory=$True)]
 [string]
 $folderPath,

 [Parameter(Mandatory=$True)]
 [string]
 $findString,

 [Parameter(Mandatory=$True)]
 [string]
 $replaceString

)

Write-Host "-------------------------Input Paramerters---------------------------"
Write-Host "Root Folder Path:" $folderPath -ForegroundColor Yellow
Write-Host "Find String:" $findString -ForegroundColor Yellow
Write-Host "Replace String:" $replaceString -ForegroundColor Yellow

$files = Get-ChildItem $folderPath -File -Recurse -Include "*.txt" | Select-Object Name, FullName
$findstrings = $findString.Split(';')

Foreach($string in -split $findStrings)
 {
    Foreach($file in $files)
       {     
         $fileName= $file.Name
         $filePath= $file.FullName
         $fileContent = Get-Content $filePath         
         #Write-Host "File name : $fileName" -ForegroundColor Green
         #Write-host  "Find string : $string"
         $fileContent -replace "$string", "$replaceString" | Set-Content $filePath
      }
 } 
}

Function UpdateServicePrincipalDetails
{

param(

 [Parameter(Mandatory=$True)]
 [string]
 $FilePath,

 [Parameter(Mandatory=$True)]
 [string]
 $tag,

 [Parameter(Mandatory=$True)]
 [string]
 $replaceValue

)
 
Write-Output "-------------------------Input Paramerters for deployment changes---------------------------"
Write-Output "Master Config File Path: $FilerPath" -ForegroundColor Yellow
Write-Output "Find Tag : $tag" -ForegroundColor Yellow
Write-Output "Replace with: $replaceValue" -ForegroundColor Yellow

         $fileContent = Get-Content $filePath         
         
         $matchedString = $fileContent -cmatch $tag
         if($matchedString)
         {
            $splittedString = $matchedString -split $tag
            $findValue = $splittedString[1]
            if($findValue)
              {            
                $fileContent -replace [Regex]::Escape($findValue), "$replaceValue" | Set-Content $filePath       
              }       
          }
          Else{
               Write-Error "Could not find the Master config changes for deployment, please check the Master config files"
          
          }       
}

$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"

Write-Verbose "PreParing the artifacts to deploy in Requested environment"
Write-Verbose "Validating the Deployment Config file path"
If(Test-Path $ConfigurationFilePath)
{
   Write-Host "-------------------------------Pre-Deployment Activity----------------------------------------------"
   $configurationContext = Get-Content -Path $ConfigurationFilePath | Out-String | ConvertFrom-Json
   Write-Verbose "Initializing the input variabales and parameters  for setting up the taget env configuration"
   $DeploymentEnv = $configurationContext.Environment 
   $subscriptionId = $configurationContext.SubscrptionID
   $resourceGroupName = $configurationContext.ResourceGroupName
   #$deploymentFolderPath = $configurationContext.DeploymentFolderPath
   $RootFolderName = $configurationContext.Configs_Scripts.RootFolderName
   $RootFolderPath = (Get-ChildItem -Path $DeploymentFolderPath -Include $RootFolderName -Directory -Recurse).FullName
   $ADLSName = $configurationContext.Configs_Scripts.ADLSName
   $FindString = $configurationContext.FindStringADLS
   $ReplaceString = $configurationContext.ReplaceStringADLS
   $servicePrincipalID = $configurationContext.Configs_Scripts.ServicePrincipalID
   $servicePrincipalKey = $configurationContext.Configs_Scripts.ServicePrincipalKey
   $ConfigurationsPath = $configurationContext.Configs_Scripts.ConfigsPath
   $fullADLSName = "$ADLSName" + ".azuredatalakestore.net"
   
   $packageNumber = Split-Path $deploymentFolderPath -Leaf
   Write-Output "----------------------------------Deployment Configuration parameter----------------------------------------- "
   Write-Output "Enviroment Name : $DeploymentEnv"
   Write-Output "SubscriptionID: $subscriptionId"
   Write-Output "Resource Group Name: $resourceGroupName"
   Write-Output "Artifacts Version: $packageNumber"
   Write-Output "RootFolderPath: $RootFolderPath"
   Write-Output "Configuration Path for Deployment: $ConfigurationsPath"
   Write-Output "ENV Changes - Find string: $FindString"
   Write-Output "ENV Changes - Replace String: $ReplaceString"
   Write-Output "----------------------------------------End Of parameters-----------------------------------------------------"
   
   # select subscription
   Write-Output "Selecting subscription '$subscriptionId'";
   $subscriptionContext = Select-AzureRmSubscription -SubscriptionID $subscriptionId;
   Write-Output "Selected Subcription Name: " 
   Write-Output $subscriptionContext

   #Check for existing resource group
   Write-Verbose "Validating the Target deployment resource"
   #Create or check for target resource 
   $resourceNameExist = (Get-AzureRmResource -ResourceName "$ADLSName" -ResourceGroupName $resourceGroupName).Name
   
     if(!$resourceNameExist)
            { 
              Write-Error "Resource name '$resourceNameExist' does not exist.Exiting from current deployment";
            }
      Else{
             Write-Output "Getting the configuration for ENV changes"
             Write-Verbose "Getting the Configuration files for ENV changes"
             Write-Verbose "********************************* Configs file Count******************************"
             $FileCount = Get-childitem $RootFolderPath -Recurse -Depth 0 -Directory | %{@{$_.Name = (Get-ChildItem $_.FullName -File -Recurse).count}} | Format-Table @{L=’Configs’;E={$_.Name}}, @{L=’Count’;E={$_.Value}}
             $FileCount
             
             Write-Verbose ($FileCount | Out-String)
             Write-Verbose "Updating the ENV configuration with Target ENV configuration"          
             ReplaceStringInFile -folderPath $RootFolderPath -findString $FindString -replaceString $ReplaceString
             $Files = Get-ChildItem -Path $RootFolderPath -File -Recurse -Include "*.txt"                       
             Write-Output "Deploying the Config files"
             Write-Verbose "Deploying the Config files"

             $count=1
             $destinationFilePath=""
            
             ForEach($file in $Files)
                      { 
                        $fileName = $file.Name
                        $filePath = $file.FullName
                        if($filePath.Contains("ProdOperationalToWorking"))
                        {
                          $destinationFilePath = "/Global/Working"
                          $i=8
                        }
                        else{
                             $destinationFilePath = "/Global/ConfigFiles"
                             $i=7
                        }

                        if($filePath.Contains("Master"))
                        {
                           Write-Verbose "Updating the service principla configuration in master Config file - $fileName"
                           Write-Output "Updating the service principla configuration in master Config file $fileName"
                           UpdateServicePrincipalDetails -filePath $filePath -tag ":=ClientId:=" -replaceValue $servicePrincipalID
                           UpdateServicePrincipalDetails -filePath $filePath -tag ":=ClientKey:=" -replaceValue $servicePrincipalKey
                           
                         }

                        $folders = $filePath.Split("\")
                        $length = $folders.Length
                        for($i; $i -lt $folders.Length;$i++)
                            {
                                 $destinationFilePath = $destinationFilePath + "/" + $folders[$i]
                            }

                        Write-Verbose "$count. `nSource FileName -- $fileName `nDestinationPath  -- $destinationFilePath"
                        Import-AzureRmDataLakeStoreItem -AccountName $fullADLSName -Path "$filePath" -Destination "$destinationFilePath" -Force
                        $count++;
              
                      }
                                 

        }

}