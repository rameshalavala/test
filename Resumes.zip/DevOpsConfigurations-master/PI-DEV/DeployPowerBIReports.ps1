﻿Param (
  
 [Parameter(Mandatory=$True)]
 [string]
 $configurationFilePath = "PIAzureDeploymentConfiguration.json",

 [Parameter(Mandatory=$True)]
 [string]
 $DeploymentFolderPath

)


Function ReplaceStringInPowerBIReport
{
param(
 [Parameter(Mandatory=$True)]
 [string]
 $folderPath,

 [Parameter(Mandatory=$True)]
 [string]
 $FindStringforServerName,

 [Parameter(Mandatory=$True)]
 [string]
 $ReplaceStringforServerName,

 [Parameter(Mandatory=$True)]
 [string]
 $FindStringforDBName,

 [Parameter(Mandatory=$True)]
 [string]
 $ReplaceStringforDBName

)

Write-Host "-------------------------Input Paramerters---------------------------"
Write-Host "Root Folder Path:" $folderPath -ForegroundColor Yellow
Write-Host "Find String:" $findString -ForegroundColor Yellow
Write-Host "Replace String:" $replaceString -ForegroundColor Yellow
$pbixfiles = Get-ChildItem $folderPath -File -Include ".pbix" 
  foreach($file in $pbixfiles)
    {

    $fileBaseName = $file.Basename
    $filename = $fileBaseName + ".zip"
    Rename-Item $file.FullName $filename
    $dir=$file.BaseName + "unzip"

    $emptydir=New-Item "$Folderpath\$dir" -ItemType Directory

    function unzip{
    param([string]$zipfile ,[string]$path)
    [System.IO.Compression.ZipFile]::ExtractToDirectory($zipfile, $path)
    }
    
    unzip "$Folderpath\$filename" $emptydir


     (Get-Content "$emptydir\Connections") | ForEach-Object{ $_ -replace $FindstringforServerName,$ServerName -replace $FindstringforDBName,$DBName} | Set-Content "$emptydir\Connections"

     [string]$zipFN = "$Folderpath\$filename"
     [string]$fileToZip = "$emptydir\Connections"
     [System.IO.Compression.ZipArchive]$ZipFile = [System.IO.Compression.ZipFile]::Open($zipFN, ([System.IO.Compression.ZipArchiveMode]::Update))
     $Entry=$ZipFile.GetEntry("Connections")
     if ($Entry)
      {
         $Entry.Delete()
       }
      $result=[System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($ZipFile, $fileToZip, (Split-Path $fileToZip -Leaf))
      $ZipFile.Dispose()
      Remove-Item $emptydir -Force -Recurse

    
      If(Test-Path $zipFN)
       {
         $finalpbix=$fileBaseName + ".pbix"
         Rename-Item $zipFN $finalpbix
        }
}


}

$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"

[Reflection.Assembly]::LoadWithPartialName( "System.IO.Compression.FileSystem" )
Import-Module -Name "C:\Program Files (x86)\WindowsPowerShell\Modules\PowerBIPS"
#Import-Module "C:\Program Files\WindowsPowerShell\Modules\PowerBIPS\2.0.2.1\PowerBIPS.psm1"
Write-Verbose "PreParing the artifacts to deploy to target environment"
Write-Verbose "Validating the Deployment Configuration file path"
If(Test-Path $ConfigurationFilePath)
{
   Write-Host "-------------------------------Pre-Deployment Activity----------------------------------------------"
   $configurationContext = Get-Content -Path $ConfigurationFilePath | Out-String | ConvertFrom-Json
   Write-Verbose "Initializing the input variabales and parameters  for setting up the taget env configuration"
   $DeploymentEnv = $configurationContext.Environment 
   $powerBIContext= $configurationContext.PowerBI 
   $RootFolderName = $configurationContext.PowerBI.RootFolderName
   $RootFolderPath = (Get-ChildItem -Path $DeploymentFolderPath -Include $RootFolderName -Directory -Recurse).FullName
   $AASServer = $configurationContext.PowerBI.AASServer
   $CubeDetails = $powerBIContext.CubeDetails
   
   $packageNumber = Split-Path $deploymentFolderPath -Leaf
   Write-Output "----------------------------------Deployment Configuration parameter----------------------------------------- "
   Write-Output "Enviroment Name : $DeploymentEnv"
   Write-Output "Artifacts Version: $packageNumber"
   Write-Output "RootFolderPath: $RootFolderPath"
   Write-Output "AAS Server: $AASServer"
   Write-Output "Configuration Path for Deployment: $ConfigurationsPath"
   Write-Output "----------------------------------------End Of parameters-----------------------------------------------------"


  $FindstringforServerName = "(asazure:)\/\/(northeurope\.asazure\.windows\.net)\/[a-z0-9]+"
  $FindstringforDBName = "(Petra)\s(PI)\s(Cube)[-a-zA-Z0-9_]+"

  $endMarkets = Get-childitem $RootFolderPath -Recurse -Depth 0 -Directory

  foreach($endMarket in $endMarkets)

  {
    Write-Host "Updating the $endMarket PowerBI Files"
    $endMarketDir = $endMarket.FullName
    $configs = $CubeDetails.$endMarket
    $CubeDBName = $configs.CubeName
    $workspaceName = $configs.PowerBIWorkspace
    ReplaceStringInPowerBIReport -folderPath $endMarketDir -FindStringforServerName $FindstringforServerName -ReplaceStringforServerName $AASServer -FindStringforDBName $FindstringforDBName -ReplaceStringforDBName $CubeDBName

    Write-Host "********************Deployment  Parameters**************************************"
    Write-Host "Deploying the PowerBI Report for -- $endMarket "
    Write-host "Root folder path:" $endMarketDir -ForegroundColor Yellow
    Write-Host "ServerName :" $AASServer -ForegroundColor Yellow
    Write-Host "DBName :" $CubeDBName -ForegroundColor Yellow
    Write-Host "WorkSpaceName : " $workspaceName -ForegroundColor Yellow

    $User = "janardhanreddy_v@bat.com"
    $PWord = ConvertTo-SecureString -String "Innovate@`$2019" -AsPlainText -Force
    $Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User, $PWord
    $creds=Get-Credential -Credential $Credential
    $tokens = Get-PBIAuthToken -credential $creds
    $workspace = Get-PBIGroup -authToken $tokens -name $WorkSpaceName
    $pbiReports = Get-ChildItem -Path $endMarketDir -file

       $i =1
     foreach($report in $pbiReports)
     { 
        Write-Host "$i. Deploying "$report.Name
        $pbix= $report.FullName

        $reportexists = Get-PBIReport -authToken $tokens -name $report.BaseName -groupId $workspace.id
        if($reportexists.Id)
         {
           $import = Import-PBIFile -authToken $tokens -groupId $workspace.id -file $pbix -nameConflict Overwrite
           if($?)
            {
              Write-Host "Existing Report $report has been replaced"
            }
         }
         else{
             $import = Import-PBIFile -authToken $tokens -groupId $workspace.id -file $pbix
             if($?)
              {   
                Write-Host "New Report $report is deployed."
              }
          }

          $i++
      }

  }
}
