﻿######################################DeployADFConfig##############################################################################################
#NAME: DeployADFConfig.ps1
#AUTHOR: NileshKumar Rawal
#DATE: 30/05/2018
#ModifiedBy: NileshKumar Rawal on 9th April 2019 for PI-Dev Activities 
#DESCRIPTION: This script deploys the json scripts(Linked service, DataSet and Pipeline) to the azure data factory service specified in 
#deployment configuration.
#ARGUMENTS: $configurationFilePath
#######################################DeployADFConfig##############################################################################################

Param(
  
 [Parameter(Mandatory=$True)]
 [string]
 $configurationFilePath = "PIAzureDeploymentConfiguration.json",

 [Parameter(Mandatory=$True)]
 [string]
 $DeploymentFolderPath

)

$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"

Write-Verbose "Validating the Deployment Config file path"
If(Test-Path $ConfigurationFilePath)
{
   Write-Output "---------------------------------------Getting Deployment configuration-------------------------------------"
   $configurationContext = Get-Content -Path $ConfigurationFilePath | Out-String | ConvertFrom-Json
   Write-Verbose "Initializing the input variabales and parameters"
   $DeploymentEnv = $configurationContext.Environment 
   $subscriptionId = $configurationContext.SubscrptionID
   $resourceGroupName = $configurationContext.ResourceGroupName
   $adfScripts = $configurationContext.ADF_Scripts
   #$deploymentFolderPath = $configurationContext.DeploymentFolderPath
   $RootFolderName = $configurationContext.ADF_Scripts.RootFolderName
   $RootFolderPath = (Get-ChildItem -Path $DeploymentFolderPath -Include $RootFolderName -Directory -Recurse).FullName  
   $packageNumber = Split-Path $deploymentFolderPath -Leaf
  
   Write-Output "----------------------------------Deployment Configuration parameter----------------------------------------- "
   Write-Output "Enviroment Name : $DeploymentEnv"
   Write-Output "SubscriptionID: $subscriptionId"
   Write-Output "Resource Group Name: $resourceGroupName"
   Write-Output "Artifacts Version: $packageNumber"
   Write-Output "ADF Configs Root Folder Path: $RootFolderPath"
   Write-Output "----------------------------------------End Of parameters-----------------------------------------------------"

   # select subscription
   Write-Output "Selecting subscription '$subscriptionId'";
   $subscriptionContext = Select-AzureRmSubscription -SubscriptionID $subscriptionId;
   Write-Output "Selected Subcription Name: " 
   Write-Output $subscriptionContext
   $dataFactories = Get-childitem $RootFolderPath -Directory -Depth 0
 
  foreach($dataFactory in $dataFactories)     
  {
     $DataFactoryName = $adfScripts.DataFactoryName.($dataFactory.Name)
     Write-Host "Data Factory Config folder - $DataFactory  :: Data Factory Name  - $DataFactoryName"
     Write-Output "Data Factory Config folder - $DataFactory  :: Data Factory Name  - $DataFactoryName"
  
     #Check for existing resource group
     Write-Verbose "Validating the Resource Group and Target Deployment Service" 

     $resourceNameExist = (Get-AzureRmResource -ResourceName "$DataFactoryName" -ResourceGroupName $resourceGroupName).Name
     if($resourceNameExist)
      {
        $DFContext=Get-AzureRmDataFactory -Name $DataFactoryName -ResourceGroupName $ResourceGroupName
        $Folders = Get-ChildItem -dir -Path $dataFactory.FullName
         foreach($Folder in $Folders)
          {     
          $temp = $folders[0]
          $folders[0] = $folders[1]
          $folders[1]= $temp
        }
        Write-Output "ADF config deployment order:" $Folders

        Foreach($Folder in $Folders)
          {
            if($Folder.Name -like 'Linked*')
              {  
                              
                Write-Output "---------------------------------------------Deploying linked services to data factory------------------------------------------------------"
                $Files = Get-ChildItem -Path $Folder.FullName -Filter *.json
                $FileCount = $Files.Count
                Write-Output "Number Of Linked Services config files: $FileCount"
                Write-Verbose "Number Of Linked Services config files: $FileCount"
                Write-Verbose "Deploying Linked Service scripts to data factory"

               foreach($File in $Files)
                {
                  $LinkedServiceFileName = $File.Name
                  $LinkedServiceFilePath = $File.FullName
                  $LinkedServiceName = [System.IO.Path]::GetFileNameWithoutExtension($File.Name)
                 
                   If ($LinkedServiceFilePath -and $LinkedServiceName)
                     {
                       Write-Output "LinkedService File Path : " $LinkedServiceFilePath
                       Write-Output "LinkedService Name : " $LinkedServiceName
                       New-AzureRmDataFactoryLinkedService $DFContext -Name "$LinkedServiceName" -File "$LinkedServiceFilePath" -Force
                     }
                 }
              }

            if($folder.Name -like '*Pipeline*')
              {
              Write-Output "-----------------------------------------------Deploying Pipelines to data factory-----------------------------------------------------------"
              $Files = Get-ChildItem -Path $Folder.FullName -Filter *.json
              $FileCount =  $Files.Count
              Write-Verbose "Deploying Pipeline scripts to data factory"
              Write-Verbose "Number Of Pipelines config files: $FileCount"
              Write-Output "Number Of Pipelines config files: $FileCount"
              

             foreach( $File in $Files)
               {
                  $PipelineFileName = $File.Name
                  $PipelineFilePath = $File.FullName
                  $PipelineName = [System.IO.Path]::GetFileNameWithoutExtension($File.Name)
                  If ($PipelineFilePath -and $PipelineName)
                      {
                          
                          Write-Output "Pipeline Name : " $PipelineName 
                          Write-Output "Pipeline File Path : " $PipelineFilePath
                          $output = New-AzureRmDataFactoryPipeline $DFContext -Name "$PipelineName" -File "$PipelineFilePath" -Force -ErrorAction SilentlyContinue -ErrorVariable errVariable
                          Write-Output $output

                          if($errVariable)
                          {
                            Write-Host "`nError in Pipeline Deployment - $PipelineName"
                            Write-Host "Error Details - $errVariable"
                            Write-Output "`nError in Pipeline Deployment - $PipelineName"
                            Write-Output "Error Details - $errVariable"
                          }
                       }
                }
          }
            if($folder.Name -like '*dataset*')
             {
                    
                    Write-Output "-----------------------------------------Deploying DataSets to data factory-----------------------------------------------------------"              
                    $Files = Get-ChildItem -Path $Folder.FullName -Filter *.json
                    $FileCount =  $Files.Count
                    Write-Output "Number Of DataSets config files:  $FileCount"
                    Write-Verbose "Deploying Datasets scripts to data factory"
                    Write-Verbose "Number Of DataSets config files: $FileCount"
                    

                     foreach($File in $Files)
                     {
                        $DataSetFileName = $File.Name                      
                        $DataSetFilePath = $File.FullName
                        $DataSetName = [System.IO.Path]::GetFileNameWithoutExtension($File.Name)
                         If ($DataSetFilePath -and $DataSetName)
                           {
                              Write-Output "`nDataSet Name : " $DataSetName
                              Write-Output "DataSet File Path : " $DataSetFilePath                              
                              $datasetOutput= New-AzureRmDataFactoryDataset $DFContext -Name $DataSetName -File $DataSetFilePath -Force -ErrorAction SilentlyContinue -ErrorVariable datasetErr 
                              Write-Output $datasetOutput
                              if($datasetErr)
                               {
                                 Write-Host "Error in DataSet Deployment - $DataSetFileName"
                                 Write-Host "Error Details - $datasetErr"
                                 Write-Output "`nError in DataSet Deployment - $DataSetFileName"
                                 Write-Output "Error Details - $datasetErr"
                              }     
                           }
                      }
                }
          }
     }
     Else
        {        
            Write-Error "The provided data factory name did not get found.Exiting from deployment..Please check the log for more details"     
         }

   }
}