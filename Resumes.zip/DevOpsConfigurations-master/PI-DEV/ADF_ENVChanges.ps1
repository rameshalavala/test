﻿######################################DeployADFConfig##############################################################################################
#NAME: ADF_ENVChanges.ps1
#AUTHOR: NileshKumar Rawal
#DATE: 30/05/2018
#ModifiedBy: NileshKumar Rawal on 9th April 2019 for PI-Dev actvities 
#DESCRIPTION: This script update  the ADF json scripts(Linked service, DataSet and Pipeline) with Target envconfiguration specified in deployment configuration.
#ARGUMENTS: $configurationFilePath,DeploymentFolderPath
#######################################DeployADFConfig##############################################################################################

Param(
  
 [Parameter(Mandatory=$True)]
 [string]
 $configurationFilePath = "PIAzureDeploymentConfiguration.json",

 [Parameter(Mandatory=$True)]
 [string]
 $DeploymentFolderPath

)

Function ReplaceStringInFile
{
param(
 [Parameter(Mandatory=$True)]
 [string]
 $folderPath,

 [Parameter(Mandatory=$True)]
 [string]
 $findString,

 [Parameter(Mandatory=$True)]
 [string]
 $replaceString

)

Write-Host "-------------------------Input Paramerters---------------------------"
Write-Host "Root Folder Path:" $folderPath -ForegroundColor Yellow
Write-Host "Find String:" $findString -ForegroundColor Yellow
Write-Host "Replace String:" $replaceString -ForegroundColor Yellow

$files = Get-ChildItem $folderPath| Select-Object Name, FullName
$findstrings = $findString.Split(';')

Foreach($string in -split $findStrings)
 {
    Foreach($file in $files)
       {     
         $fileName= $file.Name
         $filePath =  $file.FullName
         $fileContent = Get-Content $filePath         
         #Write-Host "File name : $fileName" -ForegroundColor Green
         #Write-host  "Find string : $string"
         $fileContent -replace "$string", "$replaceString" | Set-Content $filePath -Force
      }
 } 
}


$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"

Write-Verbose "PreParing the artifacts to deploy in Requested environment"
Write-Verbose "Validating the Deployment Config file path"
If(Test-Path $ConfigurationFilePath)
{
   Write-Output "-------------------------------Pre-Deployment Activity----------------------------------------------"
   $configurationContext = Get-Content -Path $ConfigurationFilePath | Out-String | ConvertFrom-Json
   Write-Verbose "Initializing the input variabales and parameters"
   $DeploymentEnv = $configurationContext.Environment 
   $subscriptionId = $configurationContext.SubscrptionID
   $resourceGroupName = $configurationContext.ResourceGroupName
   $adfScripts = $configurationContext.ADF_Scripts
   $RootFolderPath = (Get-ChildItem -Path $DeploymentFolderPath -Include $configurationContext.ADF_Scripts.RootFolderName -Directory -Recurse).FullName
   $LinkedServiceHive = $configurationContext.ADF_Scripts.LinkedService_Changes.HDInsightHiveLinkedService
   $LinkedServiceSpark = $configurationContext.ADF_Scripts.LinkedService_Changes.HDInsightLinkedService
   $LinkedServiceADLS = $configurationContext.ADF_Scripts.LinkedService_Changes.AzureDataLakeStoreLinkedService
   $LinkedServiceStorage = $configurationContext.ADF_Scripts.LinkedService_Changes.AzureStorageLinkedService
   $PipeLineChanges =  $configurationContext.ADF_Scripts.Pipeline_Changes

   Write-Output "----------------------------------ENV Changes parameter----------------------------------------- "
   Write-Output "Enviroment Name : $DeploymentEnv"
   Write-Output "SubscriptionID: $subscriptionId"
   Write-Output "Resource Group Name: $resourceGroupName"
   Write-Output "ADF Configs Root Folder Path: $RootFolderPath"
   Write-Output "Linked Service Hive:  $LinkedServiceHive"
   Write-Output "Linked Service Spark:  $LinkedServiceSpark"
   Write-Output "Linked Service ADLS:  $LinkedServiceADLS"
   Write-Output "Linked Service Storage:  $LinkedServiceStorage"
   Write-Output "PipeLineChanges:  $PipeLineChanges"
   Write-Output "----------------------------------------End Of parameters-----------------------------------------------------"
   

   $dataFactories = Get-childitem $RootFolderPath -Directory -Depth 0
 
 foreach($dataFactory in $dataFactories)     
 {   
      $DataFactoryName = $adfScripts.DataFactoryName.($dataFactory.Name)
      Write-Host "Data Factory Config folder - $DataFactory  :: Data Factory Name  - $DataFactoryName"
      Write-Output "Data Factory Config folder - $DataFactory  :: Data Factory Name  - $DataFactoryName"

      $LinkedServiceFiles = Get-ChildItem -Path $dataFactory.FullName -Recurse -File | Where-Object { $_.DirectoryName -like '*Linked*' }
      $hubName = "$DataFactoryName" + "_hub"

     # Write-Host "HubName- $hubName"

      
   Write-Output "----------------------------------ENV Changes in Linked services config files----------------------------------------"
    If(!$LinkedServiceFiles)
     {
       Write-Warning "Did not find any linked service config files in artifacts package.."
     }
     else
     {
       Foreach( $LinkedServiceFile in $LinkedServiceFiles)
        {
         #Write-Host $LinkedServiceFile.        
         #$hubReplacewithTag = "HubNameReplace" + "_" + "$adfType"
         #$hubNameReplace = $PipeLineChanges.$hubReplacewithTag
         $filePath = $LinkedServiceFile.FullName
         $LinkedServiceContent = Get-Content -Path "$filePath" -raw | ConvertFrom-Json
         $existingHubName = $LinkedServiceContent.properties.hubName
         if($existingHubName)
          {
            $fileContent = Get-Content -Path $filepath
            $fileContent -replace "$existingHubName", "$hubName"  | Set-Content -Path "$filePath" -Force
          } 
               
         If($LinkedServiceFile.Name -like 'HDInsightHiveLinkedService*')
          {
            $filePath = $LinkedServiceFile.FullName
            $LinkedServiceHiveContent = Get-Content -Path "$filePath" -raw | ConvertFrom-Json
            #$LinkedServiceHiveContent.properties.hubName = $hubName
            $LinkedServiceHiveContent.properties.'typeProperties'.clusterUri = $LinkedServiceHive.ClusterUri
            $LinkedServiceHiveContent.properties.'typeProperties'.userName = $LinkedServiceHive.ClusterLoginUserName
            $LinkedServiceHiveContent.properties.'typeProperties'.password = $LinkedServiceHive.ClusterLoginPassword

            $LinkedServiceHiveContent | ConvertTo-Json | Set-Content $LinkedServiceFile.FullName       
          }

          If($LinkedServiceFile.Name -like 'HDInsightLinkedService*')
          {
       
            $filePath = $LinkedServiceFile.FullName
            $LinkedServiceSparkContent = Get-Content -Path "$filePath" -raw | ConvertFrom-Json
            #$LinkedServiceHiveContent.properties.hubName = $hubName
            $LinkedServiceSparkContent.properties.'typeProperties'.clusterUri = $LinkedServiceSpark.ClusterUri
            $LinkedServiceSparkContent.properties.'typeProperties'.userName = $LinkedServiceSpark.ClusterLoginUserName
            $LinkedServiceSparkContent.properties.'typeProperties'.password = $LinkedServiceSpark.ClusterLoginPassword

            $LinkedServiceSparkContent | ConvertTo-Json | Set-Content $LinkedServiceFile.FullName       
          }
          
          If($LinkedServiceFile.Name -like 'AzureStorageLinkedService*')
           {
             $filePath = $LinkedServiceFile.FullName
             $LinkedServiceStorageContent = Get-Content -Path $LinkedServiceFile.FullName | Out-String | ConvertFrom-Json
             #$LinkedServiceHiveContent.properties.hubName = $hubName
             $LinkedServiceStorageContent.properties.'typeProperties'.connectionString = $LinkedServiceStorage.connectionString;
             $LinkedServiceStorageContent | ConvertTo-Json | Set-Content $LinkedServiceFile.FullName       
           } 

          If($LinkedServiceFile.Name -like 'AzureDataLakeStoreLinkedService*')
           {
             $filePath = $LinkedServiceFile.FullName
             $LinkedServiceADLSContent = Get-Content -Path "$filePath" | Out-String | ConvertFrom-Json
             #$LinkedServiceHiveContent.properties.hubName = $hubName
             $LinkedServiceADLSContent.properties.'typeProperties'.dataLakeStoreUri = $LinkedServiceADLS.dataLakeStoreUri;
             $LinkedServiceADLSContent.properties.'typeProperties'.accountName = $LinkedServiceADLS.accountName;
             $LinkedServiceADLSContent.properties.'typeProperties'.servicePrincipalId = $LinkedServiceADLS.servicePrincipalId
             $LinkedServiceADLSContent.properties.'typeProperties'.servicePrincipalKey = $LinkedServiceADLS.servicePrincipalKey
             $LinkedServiceADLSContent.properties.'typeProperties'.resourceGroupName = $resourceGroupName
             $LinkedServiceADLSContent.properties.'typeProperties'.subscriptionId = $subscriptionId
             $LinkedServiceADLSContent | ConvertTo-Json | Set-Content $LinkedServiceFile.FullName       
           }     
       }
   }

   Write-Output "----------------------------------------ENV Changes in Pipeline config files-----------------------------------------"
   $PipelineFiles = Get-ChildItem -Path $dataFactroy.FullName -Recurse -File | Where-Object { $_.DirectoryName -like '*Pipeline*' } 

   If(!$PipelineFiles)
  {
     Write-Warning "Did not find any Pipeline config filesin artifacts package.."
  }
  Else{
   
    $PipelineFolderPath = $dataFactory.FullName + "\Pipelines"
    #$hubFindwithTag = "HubNameFind" + "_" + "$adfType"
    #$hubReplacewithTag = "HubNameReplace" + "_" + "$adfType"
    $FindStringforAdlS = $configurationContext.FindStringADLS
    $ReplaceStringForAdls = $configurationContext.ReplaceStringADLS
    $FindStringforBlobStorage = $configurationContext.FindStringBlobStorage
    $ReplaceStringForBlobStorage = $configurationContext.ReplaceStringBlobStorage
    #$hubNameFind = $PipeLineChanges.$hubFindwithTag
    #$hubNameReplace = $PipeLineChanges.$hubReplacewithTag

    ReplaceStringInFile -folderPath $PipelineFolderPath -findString $FindStringforAdlS -replaceString $ReplaceStringForAdls
    ReplaceStringInFile -folderPath $PipelineFolderPath -findString $FindStringforBlobStorage -replaceString $ReplaceStringForBlobStorage
    Foreach( $PipelineFile in $PipelineFiles)
     {
       $filePath = $PipelineFile.FullName
       $PipelineContent = Get-Content -Path "$filePath" | Out-String | ConvertFrom-Json
       $existingHubName = $PipelineContent.properties.hubName
       if($existingHubName)
        {
         $fileContent = Get-Content -Path $filepath
         $fileContent -replace "$existingHubName", "$hubName"  | Set-Content -Path "$filePath" -Force
        }
    
    }

  }

 }
}
Write-Output "--------------------------------------------End of Pre-Deployment Activity-------------------------------------------------------"