﻿######################################DeployDDLScripts###########################################################################################
#NAME: DeployDDLScripts.ps1
#AUTHOR: NileshKumar Rawal
#DATE: 27/09/2018
#DESCRIPTION: This script does the ENV changes in DDL scripts and deploys the hive DDL scripts to hive HDInsight cluster service 
#to create the database and tables.
#ARGUMENTS: $configurationFilePath
#######################################DeployDDLScripts##########################################################################################

Param(
  
 [Parameter(Mandatory=$True)]
 [string]
 $configurationFilePath = "PIAzureDeploymentConfiguration.json",

 [Parameter(Mandatory=$True)]
 [string]
 $DeploymentFolderPath

)

Function ReplaceStringInFile
{
param(
 [Parameter(Mandatory=$True)]
 [string]
 $folderPath,

 [Parameter(Mandatory=$True)]
 [string]
 $findString,

 [Parameter(Mandatory=$True)]
 [string]
 $replaceString

)

Write-Host "-------------------------Input Paramerters---------------------------"
Write-Host "Root Folder Path:" $folderPath -ForegroundColor Yellow
Write-Host "Find String:" $findString -ForegroundColor Yellow
Write-Host "Replace String:" $replaceString -ForegroundColor Yellow

$files = Get-ChildItem $folderPath -File -Recurse | Select-Object Name, FullName

$findstrings = $findString.Split(';')

Foreach($string in -split $findStrings)
 {
    Foreach($file in $files)
       {     
         $fileName= $file.Name
         $filePath =  $file.FullName
         $fileContent = Get-Content $filePath         
         #Write-Host "File name : $fileName" -ForegroundColor Green
         #Write-host  "Find string : $string"
         $fileContent -replace "$string", "$replaceString" | Set-Content -Path $filePath
      }
  } 
}

function DeployHiveQuery{

param (

[Parameter(Mandatory=$True)]
[string]$clusterName,

[Parameter(Mandatory=$True)]
[string]$resourceGroupName,

[Parameter(Mandatory=$True)]
[string]$hiveQueryFilePath,

[Parameter(Mandatory=$True)]
[string]
$clusterLoginUserName,

[Parameter(Mandatory=$True)]
[string]
$clusterLoginUserPassword,

[Parameter(Mandatory=$False)]
[int] $fileNumber
)

$clusterLoginPassword = ConvertTo-SecureString "$clusterLoginUserPassword" -AsPlainText -Force

$httpLoginCredentials = New-Object System.Management.Automation.PSCredential ($clusterLoginUserName, $clusterLoginPassword);

$queryFileName = [System.IO.Path]::GetFileNameWithoutExtension($hiveQueryFilePath)

Write-Output "Deploy the $hiveQueryFilePath"
$hiveQuery = [string] (Get-Content $hiveQueryFilePath)

#Create an HDInsight Hive job definition
$hiveJobDefinition = New-AzureRmHDInsightHiveJobDefinition -Query $hiveQuery -JobName $queryfileName
#$hiveJobDefinition = New-AzureRmHDInsightHiveJobDefinition -File $hiveQueryFilePath -JobName $fileName
Write-Output "Creating Hive Job Definition"
$hiveJobDefinition 

#Submit the job to the cluster
Write-Output "Start the Hive job..."

$hiveJob = Start-AzureRmHDInsightJob -ResourceGroupName $resourceGroupName -ClusterName $clusterName -JobDefinition $hiveJobDefinition -ClusterCredential $httpLoginCredentials -Verbose 
Write-Output "Hive Job"
$hiveJob

#Wait for the Hive job to complete
Write-Output "Wait for the job to complete..."
if($fileNumber%1 -eq 0)
{
    
    Wait-AzureRmHDInsightJob -ResourceGroupName $resourceGroupName -ClusterName $clusterName -JobId $hiveJob.JobId -ClusterCredential $httpLoginCredentials
}
# Print the output
#Write-Output "Display the standard output..." -ForegroundColor Green
<#Get-AzureRmHDInsightJobOutput `
    -Clustername $clusterName `
    -ResourceGroupName $resourceGroupName `
    -JobId $hiveJob.JobId `
    -HttpCredential $httpLoginCredentials
#>

<#
$hiveJobStatus = Get-AzureRmHDInsightJob -ClusterName $clusterName -HttpCredential $httpLoginCredentials -JobId $hiveJob.JobId 

 if(($hiveJobStatus.Completed -eq "done") -and ($hiveJobStatus.State -eq "SUCCEEDED"))    
     {
        Write-Host "Deployment status of $fileName ddl script has been" $hiveJobStatus.State -ForegroundColor Green
     }
else{

        Write-Host "Deployment status of $fileName ddl script has been" $hiveJobStatus.State -ForegroundColor Red
    }
#>
}

$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"

Write-Verbose "Validating the Deployment Config file path"
If(Test-Path $ConfigurationFilePath)
{
   Write-Output "---------------------------------------Getting Deployment configuration-------------------------------------"
   $configurationContext = Get-Content -Path $ConfigurationFilePath | Out-String | ConvertFrom-Json
   Write-Verbose "Initializing the input variabales and parameters"
   $DeploymentEnv = $configurationContext.Environment 
   $subscriptionId = $configurationContext.SubscrptionID
   $resourceGroupName = $configurationContext.ResourceGroupName
   #$deploymentFolderPath = $configurationContext.DeploymentFolderPath
   $RootFolderName = $configurationContext.HQL_DDLScripts.RootFolderName
   $RootFolderPath = (Get-ChildItem -Path $DeploymentFolderPath -Include $RootFolderName -Directory -Recurse).FullName
   $SubFolderName = $configurationContext.HQL_DDLScripts.SubFolderName
   $clusterName = $configurationContext.HQL_DDLScripts.HiveClusterName
   $clusterLoginUserName = $configurationContext.HQL_DDLScripts.clusterLoginUserName
   $clusterLoginPassword = $configurationContext.HQL_DDLScripts.clusterLoginPassword
   $FindString = $configurationContext.FindStringADLS
   $ReplaceString = $configurationContext.ReplaceStringADLS
   $packageNumber = Split-Path $deploymentFolderPath -Leaf
  
   Write-Output "----------------------------------Deployment Configuration parameter----------------------------------------- "
   Write-Output "Enviroment Name : $DeploymentEnv"
   Write-Output "SubscriptionID:  $subscriptionId"
   Write-Output "Resource Group Name: $resourceGroupName"
   Write-Output "Artifacts Version: $packageNumber"
   Write-Output "Root Folder Path: $RootFolderPath"
   Write-Output "Sub Folder Name: $SubFolderName"
   Write-Output "Cluster Name: $clusterName"
   Write-Output "Login User Name: $clusterLoginUserName"
   Write-Output "Login Password: SecureString"
   Write-Output "ENv Changes - Find string: $FindString"
   Write-Output "ENV Changes - Replace String: $ReplaceString"
   Write-Output "----------------------------------------End Of parameters-----------------------------------------------------"

   # select subscription
   Write-Output "Selecting subscription '$subscriptionId'";
   $subscriptionContext = Select-AzureRmSubscription -SubscriptionID $subscriptionId;
   Write-Output "Selected Subcription Name: " 
   Write-Output $subscriptionContext
   
   $DBScriptPath = "$RootFolderPath"+ '\' + "DDL"
   
   ReplaceStringInFile -folderPath $DBScriptPath -findString $FindString -replaceString $ReplaceString

  

   Write-Verbose "Creating Databases if not exist"
   if(!(Test-Path $DBScriptPath\CreateDB.hql))
   {
     $createDBFilePath = (New-Item -Path $DBScriptPath -Name "CreateDB.hql" -ItemType File -Value "CREATE DATABASE IF NOT EXISTS integratestagingdb;CREATE DATABASE IF NOT EXISTS prodoperationaldb;CREATE DATABASE IF NOT EXISTS stagingdb;" -Force).FullName
   }
    $createDBFilePath = $DBScriptPath + "\CreateDB.hql"
    DeployHiveQuery -clusterName $clusterName -resourceGroupName $resourceGroupName -clusterLoginUserName $clusterLoginUserName -clusterLoginUserPassword $clusterLoginPassword -hiveQueryFilePath $createDBFilePath -fileNumber 1
   
    $dbFolders = Get-ChildItem -Path $DBScriptPath -Directory
   $fileNumber = 0

   foreach($dbFolder in $dbFolders)
   {
     
    
        $fileNumber++;
        Write-Output "DB Folder Path: $dbFolder"
        Write-Verbose "Deploying the DDL hive scripts from  $dbFolder"

        $hivequeriesFolderPath = $dbFolder.FullName
        Write-Output "DB Folder Path : $hivequeriesFolderPath"
        $hiveQueryFileList = Get-ChildItem -Path "$hivequeriesFolderPath" -Filter "*.hql" -Recurse -File
        $hiveQueryFileListCount = $hiveQueryFileList.Count
        Write-Verbose "Number of DDL hive scripts: $hiveQueryFileListCount " 
        foreach($hiveQueryfile in $hiveQueryFileList)
       {
         Write-Output "-----------------------------------------Deploy HQL files---------------------------------------------------------------------"
          Write-Output "$fileNumber HQL File Name : " $hiveQueryfile.Name
          Write-Output "HQL file Path: " $hiveQueryfile.FullName

          DeployHiveQuery -clusterName $clusterName -resourceGroupName $resourceGroupName -clusterLoginUserName $clusterLoginUserName -clusterLoginUserPassword $clusterLoginPassword -hiveQueryFilePath $hiveQueryfile.FullName -fileNumber $fileNumber
   
        }
     
   }
}