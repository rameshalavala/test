﻿######################################DeployHQL_DMLScripts##############################################################################################
#NAME: DeployHQL_DMLScripts.ps1
#AUTHOR: NileshKumar Rawal
#ModifiedBy: NileshKumar Rawal
#DATE: 27/03/2019
#DESCRIPTION: This script does the ENV changes in configs scripts mentioned in the configuration file and deploys the hive DML scripts 
#to azure Storage Account.  
#and deploys the aas cube to target azure analysis service.
#ARGUMENTS: $configurationFilePath
#######################################DeployHQL_DMLScripts##############################################################################################


Param (
  
 [Parameter(Mandatory=$True)]
 [string]
 $configurationFilePath = "PIAzureDeploymentConfiguration.json",

 [Parameter(Mandatory=$True)]
 [string]
 $DeploymentFolderPath

)

Function ReplaceStringInFile
{

param(
 [Parameter(Mandatory=$True)]
 [string]
 $folderPath,

 [Parameter(Mandatory=$True)]
 [string]
 $findString,

 [Parameter(Mandatory=$True)]
 [string]
 $replaceString

)

Write-Host "-------------------------Input Paramerters---------------------------"
Write-Host "Root Folder Path:" $folderPath -ForegroundColor Yellow
Write-Host "Find String:" $findString -ForegroundColor Yellow
Write-Host "Replace String:" $replaceString -ForegroundColor Yellow

$files = Get-ChildItem $folderPath -File -Recurse | Select-Object Name, FullName
$findstrings = $findString.Split(';')

Foreach($string in -split $findStrings)
 {
    Foreach($file in $files)
       {     
         $fileName= $file.Name
         $filePath= $file.FullName
         $fileContent = Get-Content $filePath         
         #Write-Host "File name : $fileName" -ForegroundColor Green
         #Write-host  "Find string : $string"
         $fileContent -replace "$string", "$replaceString" | Set-Content $filePath
      }
} 

}

$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"

#Clear-Variable -Name Folders,configurationContext,RootFolderPath,RootFolderName,SubFolderName,StorageAccountName,ContainerName,FindString,ReplaceString,packageNumber,FolderPath

Write-Verbose "PreParing the artifacts to deploy in Requested environment"
Write-Verbose "Validating the Deployment Config file path"
If(Test-Path $ConfigurationFilePath)
{
   Write-Host "-------------------------------Pre-Deployment Activity----------------------------------------------"
   $configurationContext = Get-Content -Path $ConfigurationFilePath | Out-String | ConvertFrom-Json
   Write-Verbose "Initializing the input variabales and parameters"
   $DeploymentEnv = $configurationContext.Environment 
   $subscriptionId = $configurationContext.SubscrptionID
   $resourceGroupName = $configurationContext.ResourceGroupName
   #$deploymentFolderPath = $configurationContext.DeploymentFolderPath
   $RootFolderName = $configurationContext.HQL_DMLScripts.RootFolderName
   $RootFolderPath = (Get-ChildItem -Path $deploymentFolderPath -Include $RootFolderName -Directory -Recurse).FullName
   $SubFolderName = $configurationContext.HQL_DMLScripts.SubFolderName
   $StorageAccountName = $configurationContext.HQL_DMLScripts.StorageAccountName
   $ContainerName = $configurationContext.HQL_DMLScripts.ContainerName
   $FindString = $configurationContext.FindStringADLS
   $ReplaceString = $configurationContext.ReplaceStringADLS
   $packageNumber = Split-Path $deploymentFolderPath -Leaf
   Write-Output "----------------------------------Deployment Configuration parameter----------------------------------------- "
   Write-Output "Enviroment Name : $DeploymentEnv"
   Write-Output "SubscriptionID: $subscriptionId"
   Write-Output "Resource Group Name: $resourceGroupName"
   Write-Output "Artifacts Version: $packageNumber"
   Write-Output "RootFolderPath: $RootFolderPath"
   Write-Output "Storage Account Name:  $StorageAccountName"
   Write-Output "container Name:  $ContainerName"
   Write-Output "Sub FOlders: $SubFolderName"
   Write-Output "ENv Changes - Find string: $FindString"
   Write-Output "ENV Changes - Replace String: $ReplaceString"
   Write-Output "----------------------------------------End Of parameters-----------------------------------------------------"
   
   # select subscription
   Write-Output "Selecting subscription '$subscriptionId'";
   $subscriptionContext = Select-AzureRmSubscription -SubscriptionID $subscriptionId;
   Write-Output "Selected Subcription Name: " 
   Write-Output $subscriptionContext
 
   
      If(Test-Path $RootFolderPath)
       {
          #$FolderPath = "$RootFolderPath" + "\" + "$folder"  
          #$leafFolder = Split-Path $FolderPath -Leaf
          #$parentPath = Split-Path $FolderPath
          #$parentFolder = Split-Path $parentPath -Leaf
          #$lastTwoFolder = Join-Path $parentFolder $LeafFolder
          #Write-Output "Folder Path in Blob Storage: $lastTwoFolder"
          $FileCount = Get-childitem $RootFolderPath -Recurse -Depth 0 -Directory -Exclude "" | %{@{$_.Name = (Get-ChildItem $_.FullName -File -Recurse|  Where-Object {$_.PSParentPath -notlike "*DDL*" -and !$_.PSISContainer}).count}} | Format-Table @{L=’DML Configs’;E={$_.Name}}, @{L=’Count’;E={$_.Value}}
          $FileCount
             
          Write-Verbose ($FileCount | Out-String)
          Write-Verbose "Updating the ENV configuration with Target ENV configuration" 

          ReplaceStringInFile -folderPath $RootFolderPath -findString $FindString -replaceString $ReplaceString        

          #Check for existing resource group
          Write-Verbose "Validating the Target deploymment resource"
          #Create or check for target resource 
          $resourceNameExist = (Get-AzureRmResource -ResourceName "$StorageAccountName" -ResourceGroupName $resourceGroupName).Name
          if(!$resourceNameExist)
          { 
            Write-Error "Resource name '$resourceNameExist' does not exist.Exiting from current deployment";
          }
          Else{
                Write-Verbose "Getting storage account..."
                Write-Output "Getting storage account..."
                $StorageAccount = Get-AzureRmStorageAccount -ResourceGroupName $resourceGroupName -Name $StorageAccountName;
                $storageAccountContext = $StorageAccount.Context      
                $container = Get-AzureStorageContainer -Name $containerName -Context $storageAccountContext -ErrorAction SilentlyContinue
                $fileList =  Get-ChildItem -Path $RootFolderPath -Include "*.hql" -File -Recurse | Where-Object {$_.PSParentPath -notlike "*DDL*" -and !$_.PSISContainer}
                If(!$container)
                  {
                     Write-Warning "Blob Container '$ContainerName' does not exist, Creating the New container";
                     Write-Output "Creating blob container '$ContainerName' in storage account" $StorrageAccount.StorageAccountName;
                     $container= New-AzureStorageContainer -Name $ContainerName -Context $storageAccountContext -Permission Container
                  }
                Else
                  {
                     Write-Output "Using existing blob container $ContainerName";
                   }
             
                If($container -and $fileList)
                 {

               Write-Verbose "Deployin the DML hive scripts to blob conatiner";
               foreach ($file in $fileList)
                  {
                     Write-Output "Uploading blob to '$containerName' conatiner";
                     $parentDirectory = ""
                       if($file.FullName.Contains("Extract"))
                       { 
                         $parentDirectory = "TempExtractsToAAS"                        
                       }
                       else{
                         $parentDirectory = "MergeAndInsertScripts"
                       }
                       $fileDirectory = $file.Directory.Name
                       #$fileExtension = $file.Extension
                       #$fileBaseName = $file.BaseName
                       $fileName = $file.Name
                       $filePath = $file.FullName
                       #$fileNameWithExtension = "$fileBaseName" + "$fileExtension"
                       $blobPath = "$parentDirectory" + "\" + "$fileDirectory" + "\" + "$fileName"
                       Write-Verbose "Source File -- $fileName `n Destination blob Path -- $blobPath "

                       $deploymentContext = Set-AzureStorageBlobContent -File $filePath -Container $ContainerName -Blob "$blobPath" -Context $storageAccountContext -Force 
                      
                       Write-Output "-------------------------------------Deployment Context------------------------------------------------------" 
                       $deploymentContext 
                   }
               }
                 Else
                 {
                   Write-Error "Did not find the artifacts.....Exiting from the current deployment";
                  } 
             }
       }
      
     }
     Else{    
    Write-Error "The  current deployment has failed due to configuration file is not available. Please check the log for more details"

    }
