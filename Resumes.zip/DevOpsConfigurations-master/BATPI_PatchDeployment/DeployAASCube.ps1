﻿######################################DeployAASCube##############################################################################################
#NAME: DeployAASCube.ps1
#AUTHOR: NileshKumar Rawal
#DATE: 22/11/2018
#DESCRIPTION: This script does the ENV changes like target ENV server name, database name, data lake store name and cube processing option etc 
#and deploys the aas cube to target azure analysis service.
#ARGUMENTS: $configurationFilePath
#######################################DeployAASCube##############################################################################################

Param(

   [Parameter(Mandatory=$True)]
   [string]
   $configurationFilePath = "PIAzureDeploymentConfiguration.json",

   [Parameter(Mandatory=$True)]
   [string]
   $DeploymentFolderPath,

   
   [Parameter(Mandatory=$false)]
   [string]$sSMSToolLocation = "C:\Program Files (x86)\Microsoft SQL Server\140\Tools\Binn\ManagementStudio",


   [Parameter(Mandatory=$false)]
   [string]
   $tempPath = "C:\cubeScripts"

)


$VerbosePreference = "SilentlyContinue"
Import-Module -Name "C:\Program Files\WindowsPowerShell\Modules\SqlServer"


$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"

$azureSPLoginId = "b96effb1-26ff-4d72-ab79-78b482ac6494"
$Key = "8UpkI7s3qTwckGpf9t:q?AdHWKVzGV[/"

$azureLoginPassword = ConvertTo-SecureString -String $Key -AsPlainText -Force


$azureLoginCreds = New-Object -TypeName System.Management.Automation.PSCredential($azureSPLoginId ,$azureLoginPassword)
 Write-Verbose "Logging in...";
 $azureLoginContext = Login-AzureRmAccount -ServicePrincipal -Credential $azureLoginCreds -TenantId "ff9c7474-421d-4957-8d47-c4b64dec87b5";
 $azureSubcription = $azureLoginContext.Context.Subscription

Write-Verbose "Preparing the artifacts to deploy in Requested environment"
Write-Verbose "Validating the Deployment Config file path"
If(Test-Path $ConfigurationFilePath)
{
   Write-Output "-------------------------------------------Pre-Deployment Activity-----------------------------------------------------"
   $configurationContext = Get-Content -Path $ConfigurationFilePath | Out-String | ConvertFrom-Json
   Write-Verbose "Initializing the input variabales and parameters"
   $DeploymentEnv = $configurationContext.Environment 
   $subscriptionId = $configurationContext.SubscrptionID
   $resourceGroupName = $configurationContext.ResourceGroupName
   #$deploymentFolderPath = $configurationContext.DeploymentFolderPath
   $RootFolderName = $configurationContext.AAS_Cube.RootFolderName
   $RootFolderPath = (Get-ChildItem -Path $deploymentFolderPath -Include $RootFolderName -Directory -Recurse).FullName
   $ServerName = $configurationContext.AAS_Cube.ServerName
   $DatabaseName = $configurationContext.AAS_Cube.DatabaseName
   $FindDatabaseName = $configurationContext.AAS_Cube.FindDatabaseName
   $ConnectionString = $configurationContext.AAS_Cube.ConnectionString
   $ProcessingOption = $configurationContext.AAS_Cube.ProcessingOption
   $FindStringforAdls = $configurationContext.AAS_Cube.FindStringforAdls
   $ReplaceStringForAdls = $configurationContext.AAS_Cube.ReplaceStringForAdls
   $analysisServicesServerName =$configurationContext.AAS_Cube.AAS_ServerName
   $packageNumber = Split-Path $deploymentFolderPath -Leaf

   Write-Output "----------------------------------Deployment Configuration parameter---------------------------------------------------- "
   Write-Output "Enviroment Name : $DeploymentEnv"
   Write-Output "SubscriptionID: $subscriptionId"
   Write-Output "Resource Group Name: $resourceGroupName"
   Write-Output "Artifacts Version: $packageNumber"
   Write-Output "RootFolderPath: $RootFolderPath"
   Write-Output "Analysis Service Server Name:  $ServerName"
   Write-Output "Database Name:  $DatabaseName"
   Write-Output "AAS server Connection String:  $ConnectionString"
   Write-Output "DataBase Processing Option :  $ProcessingOption"
   Write-Output "ENV Changess- Find database Name:  $FindDatabaseName"
   Write-Output "ENV Changes- Find ADLS string :  $FindStringforAdls"
   Write-Output "ENV Changes- Replace ADLS string :  $ReplaceStringForAdls"
   Write-Output "----------------------------------------End Of parameters-----------------------------------------------------"

   # select subscription
   Write-Output "Selecting subscription '$subscriptionId'";
   $subscriptionContext = Select-AzureRmSubscription -SubscriptionID $subscriptionId;
   Write-Output "Selected Subcription Name: " 
   Write-Output $subscriptionContext
  
   Write-Output "Updating the AAS cube deployment scripts with Env details"
   
   $analysisServiceFiles = Get-ChildItem -Path "$RootFolderPath\$DatabaseName" -Recurse -File
  
  If($analysisServiceFiles)
     {
  
       Foreach($analysisServiceFile in $analysisServiceFiles)
         {
           if ($analysisServiceFile.Name -eq "Model.asdatabase")
            {            
                Write-Output "AAS cube File Name: " $analysisServiceFile.FullName
                $filePath = $analysisServiceFile.FullName
                $asDataBaseFile = Get-Content -Path "$filePath"
                $asDataBaseFile -replace "$FindDatabaseName" , "$DatabaseName" | Set-Content -Path "$filePath" -Force

                #$asDataBaseFile -replace "$FindStringforAdls" , "$ReplaceStringForAdls" | Set-Content -Path "$filePath" -Force

                $findstrings = $FindStringforAdls.Split(';')

                Foreach($string in -split $findStrings)
                   {
                         $asDataBaseFile = Get-Content -Path "$filePath"                                         
                         $asDataBaseFile -replace "$string", "$ReplaceStringForAdls" | Set-Content $filePath      
                    }
             }

          if ($analysisServiceFile.Name -eq "Model.deploymentoptions")
            {
              Write-Output "AAS cube File Name: " $analysisServiceFile.FullName
              $filePath = $analysisServiceFile.FullName
              $Xml = New-Object XML
              $Xml.Load($filePath)              
              $Xml.DeploymentOptions.ProcessingOption = "$ProcessingOption"
              $xml.Save($filePath)
            }

          if ($analysisServiceFile.Name -eq "Model.deploymenttargets")
            {
              Write-Output "AAS cube File Name: " $analysisServiceFile.FullName
              $filePath = $analysisServiceFile.FullName
              $Xml = New-Object XML
              $Xml.Load($filePath)

              $node = $Xml.DeploymentTarget
              
              $Xml.DeploymentTarget.Database = "$DatabaseName"
              $Xml.DeploymentTarget.ConnectionString = "$ConnectionString"
              $Xml.DeploymentTarget.Server = "$ServerName" 
              $xml.Save($filePath)            
            }
  
        }

     }

     

if (Test-Path -Path "$tempPath\*")
{
  Remove-Item -Path "$tempPath\*" -Force
}


Get-ChildItem -Path "$RootFolderPath\$DatabaseName" -Recurse -file | Copy-Item -Destination "$tempPath\" -force

    If(Test-Path $sSMSToolLocation)
    {
            cd $sSMSToolLocation
            #$asDataBaseFilePath = (Get-ChildItem -Path $RootFolderPath -file -Include "Model.asdatabase" -Recurse).FullName
            $asDataBaseFilePath = (Get-ChildItem -Path "C:\cubeScripts" -file -Include "Model.asdatabase" -Recurse).FullName
          if(Test-Path $asDataBaseFilePath)
           { 
             #$asDataBaseFilePath = $File.FullName 
             $aasDeploymentFileName = "aasDeployment.xmla"
             $aasDeploymentFilePath =  "$tempPath\$aasDeploymentFileName"
             $logPath = "$tempPath\aasDeploy.log" 
             Write-Verbose "Generating the deployment script"
             Write-Output "Generating the deployment script : $aasDeploymentFilePath"
             .\Microsoft.AnalysisServices.Deployment.exe  "$asDataBaseFilePath" /s:"$logPath" /o:"$aasDeploymentFilePath" /d | Out-Default

              if(Test-Path $aasDeploymentFilePath)
               {
                   Write-Verbose "Deploying the AAS cube"
                   Write-Output  "Deploying the AAS cube to $ServerName server"
                   $VerbosePreference = "SilentlyContinue"
                   $deploymentOutput = Invoke-ASCmd –InputFile "$aasDeploymentFilePath" -Server $ServerName -Credential $azureLoginCreds
                   Write-Output "-----------------------------------AAS Cube Deployment Output-------------------------------------------------"
                   Write-Output $deploymentOutput
               }
               Else{

                  Write-Error "Did not find the deployment script.Exiting from current deployment"
               }                
            }
            Else
            {
                Write-Error "Did not find asadatabase file in current directory.Exiting from deployment"
            }
          
    }

   
}




