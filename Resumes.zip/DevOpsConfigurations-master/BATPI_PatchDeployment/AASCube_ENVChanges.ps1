﻿Param(
  
 [Parameter(Mandatory=$True)]
 [string]
 $configurationFilePath = "PIAzureDeploymentConfiguration.json",

 [Parameter(Mandatory=$True)]
 [string]
 $DeploymentFolderPath

)

$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"

Write-Verbose "Preparing the artifacts to deploy in Requested environment"
Write-Verbose "Validating the Deployment Config file path"
If(Test-Path $ConfigurationFilePath)
{
   Write-Host "-------------------------------Pre-Deployment Activity----------------------------------------------"
   $configurationContext = Get-Content -Path $ConfigurationFilePath | Out-String | ConvertFrom-Json
   Write-Verbose "Initializing the input variabales and parameters"
   $DeploymentEnv = $configurationContext.Environment 
   $subscriptionId = $configurationContext.SubscrptionID
   $resourceGroupName = $configurationContext.ResourceGroupName

   $RootFolderPath = (Get-ChildItem -Path $DeploymentFolderPath -Include $configurationContext.AAS_Cube.RootFolderName -Directory -Recurse).FullName
   $ServerName = $configurationContext.AAS_Cube.ServerName
   $DatabaseName = $configurationContext.AAS_Cube.DatabaseName
   $FindDatabaseName = $configurationContext.AAS_Cube.DatabaseName.FindDatabaseName
   $ConnectionString = $configurationContext.AAS_Cube.ConnectionString
   $ProcessingOption = $configurationContext.AAS_Cube.ProcessingOption
   $FindStringforAdls = $configurationContext.AAS_Cube.FindStringforAdls
   $ReplaceStringForAdls = $configurationContext.AAS_Cube.ReplaceStringForAdls
   $analysisServicesServerName =$configurationContext.AAS_Cube.AAS_ServerName
  
   Write-Host "Updating the AAS cube deployment scripts with Env details"

   
   $analysisServiceFiles = Get-ChildItem -Path $RootFolderPath -Recurse -File
  
    If($analysisServiceFiles)
     {
  
       Foreach($analysisServiceFile in $analysisServiceFiles)
         {
           if ($analysisServiceFile.Name -eq "Model.asdatabase")
            {            
              Write-Host "AAS cube File Name: " $analysisServiceFile.FullName
              $filePath = $analysisServiceFile.FullName
              $asDataBaseFile = Get-Content -Path "$filePath"

              $asDataBaseFile -replace "$FindDatabaseName", "$DatabaseName" | Set-Content -Path "$filePath" -Force

              $asDataBaseFile -replace "$FindStringforAdls" , "$ReplaceStringForAdls" | Set-Content -Path "$filePath" -Force
  
            }

          if ($analysisServiceFile.Name -eq "Model.deploymentoptions")
            {
              Write-Host "AAS cube File Name: " $analysisServiceFile.FullName
              $filePath = $analysisServiceFile.FullName
              $Xml = New-Object XML
              $Xml.Load($filePath)              
              $Xml.DeploymentOptions.ProcessingOption = "$ProcessingOption"
              $xml.Save($filePath)
            }

          if ($analysisServiceFile.Name -eq "Model.deploymenttargets")
            {
              Write-Host "AAS cube File Name: " $analysisServiceFile.FullName
              $filePath = $analysisServiceFile.FullName
              $Xml = New-Object XML
              $Xml.Load($filePath)

              $node = $Xml.DeploymentTarget
              
              $Xml.DeploymentTarget.Database = "$DatabaseName"
              $Xml.DeploymentTarget.ConnectionString = "$ConnectionString"
              $Xml.DeploymentTarget.Server = "$ServerName" 
              $xml.Save($filePath)            
            }
  
        }

     }
}
