param(

 [Parameter(Mandatory=$True)]
 [string]
 $templateFilePath = "template.json",

 [Parameter(Mandatory=$True)]
 [string]
 $configurationFilePath = "PIAzureServicesConfiguration.json"
 
)


#Registers RPs

Function RegisterRP {
    Param(
        [string]$ResourceProviderNamespace
    )

    Write-Host "Registering resource provider '$ResourceProviderNamespace'";
    Register-AzureRmResourceProvider -ProviderNamespace $ResourceProviderNamespace;
}


$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"



Write-Verbose "Validating the Service Config and ARM template file paths"
#Validating input files path 
If((Test-Path $templateFilePath) -and (Test-Path $ConfigurationFilePath))
{

   #setting up the input variables
   Write-Output "Getting Analysis Service configuration"
   $configurationContext = Get-Content -Path $ConfigurationFilePath | Out-String | ConvertFrom-Json

   Write-Verbose "Initializing the input variabales and parameters"
   $provisioningEnv = $configurationContext.Environment 
   $subscriptionId = $configurationContext.SubscriptionID
   $resourceGroupName = $configurationContext.ResourceGroupName
   $deploymentName = $configurationContext.deploymentName
   $resourceName = $configurationContext.SQLDatabase.ResourceName
   $resourceLocation = $configurationContext.SQLDatabase.ResourceLocation
   $collation = $configurationContext.SQLDatabase.collation
   $skuName = $configurationContext.SQLDatabase.skuName
   $skuTier = $configurationContext.SQLDatabase.skuTier
   $SQLServerName = $configurationContext.SQLDatabase.SQLServerName
 
   $deploymentName = $deploymentName + "_SQLDatabaser"
   $resourceTag = $configurationContext.ResourceTag


   Write-Output "--------------------------------------------Configuration parameter--------------------------------------------------- "
   Write-Output "Enviroment Name :  $provisioningEnv"
   Write-Output "SubscriptionID:  $subscriptionId"
   Write-Output "Resource Group Name: $resourceGroupName"
   Write-Output "Deployment Name:  $deploymentName"
   Write-Output "Resource Name: $resourceName"
   Write-Output "ResourceLocation: $resourceLocation"
   Write-Output "collation:  $collation"
   Write-Output "SKU Name: $skuName"
   Write-Output "SKU Tier: $skuTier"
   Write-Output "SQL Server Name : $SQLServerName"
   

  Write-Output "-------------------------------------------End Of parameters------------------------------------------------------------"

     # select subscription
    Write-Output "Selecting subscription '$subscriptionId'";
    $subscriptionContext = Select-AzureRmSubscription -SubscriptionID $subscriptionId;
    Write-Output $subscriptionContext
<#
# Register RPs
$resourceProviders = @("microsoft.sql");
if($resourceProviders.length) {
    Write-Host "Registering resource providers"
    foreach($resourceProvider in $resourceProviders) {
        RegisterRP($resourceProvider);
    }
}

#>

#Create or check for existing resource group
    Write-Verbose "Validating the Resource Group"
    $resourceGroupExist = Get-AzureRmResourceGroup -Name $resourceGroupName -ErrorAction SilentlyContinue
    if(!$resourceGroupExist)
     {
       Write-Error "Resource group '$resourceGroupName' does not exist.Exiting from current deployment";    
     }
     else{
              Write-Output "Using existing resource group '$resourceGroupName'";           
             $resourceNameExist = (Get-AzureRmResource -ResourceName "$resourceName" -ResourceGroupName $resourceGroupName).Name      
             #Create or check for existing resource group
             Write-Verbose "Validating the Resource"
             if(!$resourceNameExist)
              {
                Write-Host "Starting deployment...";
                $SqlDatabaseContext= New-AzureRmResourceGroupDeployment -ResourceGroupName $resourceGroupName -TemplateFile $templateFilePath -databaseName $resourceName -serverName $SQLServerName -databaseLocation $resourceLocation -collation $collation -edition $skuTier -requestedServiceObjectiveName $skuName;
              }
             else {

                  Write-Error "The SQL Database provisioning has failed due to resource name is not available. Please check the log for more details"
                }
                if($SqlDatabaseContext.ProvisioningState -eq "Succeeded")
               {
                  Write-Verbose "The SQL database has been provisioned successfully"
                  Write-Output "The SQL database $resourceName provisioned successfully!!!"
                  Write-Output "Azure SQL database Provisioning Context --" 
                  $SqlDatabaseContext
               }
         }

         
}

else { 
        Write-Error "The SQL database provisioning has failed due to configuration file or ARM template file path is not valid. Please check the log for more details" 
      }
    

