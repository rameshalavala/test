######################################ProvisionBlobStorageAccoun##############################################################################################
#NAME: ProvisionBlobStorageAccount.ps1
#AUTHOR: NileshKumar Rawal
#DATE: 28/03/2018
#DESCRIPTION: This script takes the storage account configuration from input configuration file and provisions the storage account using ARM template.
#ARGUMENTS: $templateFilePath,$configurationFilePath
#######################################ProvisionBlobStorageAccoun##############################################################################################
###lenght of the resource name should be in between 3 to 24 characters

param(

 [Parameter(Mandatory=$True)]
 [string]
 $templateFilePath = "template.json",

 [Parameter(Mandatory=$True)]
 [string]
 $configurationFilePath = "PIAzureServicesConfiguration.json"

)

$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"
#Validate the input files path
Write-Verbose "Validating the Service Config and ARM template file paths"
If((Test-Path $templateFilePath) -and (Test-Path $ConfigurationFilePath))
{
  #setting up the input variables
  Write-Output "Getting Storage Account configuration"
  $configurationContext = Get-Content -Path $ConfigurationFilePath | Out-String | ConvertFrom-Json

  Write-Verbose "Initializing the input variabales and parameters"
  $provisioningEnv = $configurationContext.Environment 
  $subscriptionId = $configurationContext.SubscriptionID
  $resourceGroupName = $configurationContext.ResourceGroupName
  $deploymentName = $configurationContext.deploymentName
  $resourceName = $configurationContext.StorageAccount.ResourceName
  $resourceLocation = $configurationContext.StorageAccount.ResourceLocation
  $resourceTag = $configurationContext.ResourceTag
  
  $deploymentName = $deploymentName + "_StorageAccount"
  
  Write-Output "----------------------------------Configuration parameter----------------------------------------- "
  Write-Output "Enviroment Name : $provisioningEnv"
  Write-Output "SubscriptionID: " $subscriptionId
  Write-Output "Resource Group Name: " $resourceGroupName
  Write-Output "Deployment Name: " $deploymentName
  Write-Output "Resource Name: " $resourceName
  Write-Output "ResourceLocation: " $resourceLocation
  Write-Output "----------------------------- -------End Of parameters----------------------------------------------"

  # select subscription
  Write-Output "Selecting subscription '$subscriptionId'";
  $subscriptionContext = Select-AzureRmSubscription -SubscriptionID $subscriptionId;
  Write-Output "Selected Subcription Name: " 
  Write-Output $subscriptionContext

  #Check for existing resource group
  Write-Verbose "Validating the Resource Group"
  $resourceGroupExist = Get-AzureRmResourceGroup -Name $resourceGroupName -ErrorAction SilentlyContinue
  if(!$resourceGroupExist)
     {
       Write-Error "Resource group '$resourceGroupName' does not exist.Exiting from current deployment";
   
     }
  else{

        Write-Output "Using existing resource group '$resourceGroupName'";
        Write-Verbose "Validating the Resource Name"
        $resourceNameExist = (Get-AzureRmResource -ResourceName "$resourceName" -ResourceGroupName $resourceGroupName).Name;
        # Start the deployment    
        if(!$resourceNameExist) 
          {
             $CreatedBy = $resourceTag.CreatedBy
             $MARKET = $resourceTag.MARKET
             $CONTACT = $resourceTag.CONTACT
             $ENV = $resourceTag.ENV
             $SCHEDULE = $resourceTag.SCHEDULE
            Write-Verbose "Starting the ARM template Deployment...";
            Write-Output "Starting the ARM template Deployment...";
            $storageAccountContext = New-AzureRmResourceGroupDeployment -Name $deploymentName -ResourceGroupName $resourceGroupName -TemplateFile $templateFilePath -ResourceName $resourceName -ResourceLocation $resourceLocation -CreatedBy_Tag $CreatedBy -MARKET_Tag $MARKET -CONTACT_Tag $CONTACT -ENV_Tag $ENV -SCHEDULE_Tag $SCHEDULE ;
      
             If($storageAccountContext.ProvisioningState -eq "Succeeded") 
               {
                  Write-Verbose "The Storage Account has been provisioned successfully"
                  Write-Output "The Storage Account $resourceName has been provisioned successfully!!!" 
                  Write-Output "Storage Account Provisioning Context --" 
                  $storageAccountContext        
                }
            }
         else{
             Write-Error "The storage account provisioning has failed due to resource name is not available.Please check the log for more details"
            }
     
       }
 }
 else{

 Write-Error "The storage account provisioning has failed due to ARM template file path is not valid or could not find the configuration file"
 
}

