﻿param(

 [Parameter(Mandatory=$True)]
 [string]
 $templateFilePath = "template.json",


 [Parameter(Mandatory=$True)]
 [string]
 $configurationFilePath = "PIAzureServicesConfiguration.json"
 
)


#Registers RPs

Function RegisterRP {
    Param(
        [string]$ResourceProviderNamespace
    )

    Write-Host "Registering resource provider '$ResourceProviderNamespace'";
    Register-AzureRmResourceProvider -ProviderNamespace $ResourceProviderNamespace;
}


$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"

Write-Verbose "Validating the Service Config and ARM template file paths"
#Validating input files path 
If((Test-Path $templateFilePath) -and (Test-Path $ConfigurationFilePath))
{

   #setting up the input variables
   Write-Output "Getting Analysis Service configuration"
   $configurationContext = Get-Content -Path $ConfigurationFilePath | Out-String | ConvertFrom-Json

   Write-Verbose "Initializing the input variabales and parameters"
   $provisioningEnv = $configurationContext.Environment 
   $subscriptionId = $configurationContext.SubscriptionID
   $resourceGroupName = $configurationContext.ResourceGroupName
   $deploymentName = $configurationContext.deploymentName
   $resourceName = $configurationContext.SQLServer.ResourceName
   $resourceLocation = $configurationContext.SQLServer.ResourceLocation
   $adminLoginName = $configurationContext.SQLServer.adminLoginName
   $adminLoginPassword = ConvertTo-SecureString $configurationContext.SQLServer.adminLoginPassword -AsPlainText -Force
 
   $deploymentName = $deploymentName + "_SqlServer"
   $resourceTag = $configurationContext.ResourceTag


   Write-Output "--------------------------------------------Configuration parameter--------------------------------------------------- "
   Write-Output "Enviroment Name :  $provisioningEnv"
   Write-Output "SubscriptionID:  $subscriptionId"
   Write-Output "Resource Group Name: $resourceGroupName"
   Write-Output "Deployment Name:  $deploymentName"
   Write-Output "Resource Name: $resourceName"
   Write-Output "ResourceLocation: $resourceLocation"
   Write-Output "Admin User Name:  $adminLoginName"
   Write-Output "Admin Password: [Securestring]"

  Write-Output "-------------------------------------------End Of parameters------------------------------------------------------------"

     # select subscription
    Write-Output "Selecting subscription '$subscriptionId'";
    $subscriptionContext = Select-AzureRmSubscription -SubscriptionID $subscriptionId;
    Write-Output $subscriptionContext
<#
# Register RPs
$resourceProviders = @("microsoft.sql");
if($resourceProviders.length) {
    Write-Host "Registering resource providers"
    foreach($resourceProvider in $resourceProviders) {
        RegisterRP($resourceProvider);
    }
}
#>

#Create or check for existing resource group
    Write-Verbose "Validating the Resource Group"
    $resourceGroupExist = Get-AzureRmResourceGroup -Name $resourceGroupName -ErrorAction SilentlyContinue
    if(!$resourceGroupExist)
     {
       Write-Error "Resource group '$resourceGroupName' does not exist.Exiting from current deployment";    
     }
     else{

              Write-Output "Using existing resource group '$resourceGroupName'";
           
             $resourceNameExist = (Get-AzureRmResource -ResourceName "$resourceName" -ResourceGroupName $resourceGroupName).Name
       
             #Create or check for existing resource group
             Write-Verbose "Validating the Resource"
             if(!$resourceNameExist)
              {
               Write-Host "Starting deployment...";
               $SqlServerContext = New-AzureRmResourceGroupDeployment -ResourceGroupName $resourceGroupName -TemplateFile $templateFilePath -resourceServerName $resourceName -ResourceLocation $resourceLocation -administratorLoginUserName $adminLoginName -administratorLoginPassword $adminLoginPassword;
             }
            else {

                  Write-Error "The SQL server provisioning has failed due to resource name is not available. Please check the log for more details"
                }
                
           if($SqlServerContext.ProvisioningState -eq "Succeeded")
               {
                  Write-Verbose "The SQL server has been provisioned successfully"
                  Write-Output "The SQL Server $resourceName provisioned successfully!!!"
                  Write-Output "Azure SQL Server Provisioning Context --" 
                  $SqlServerContext
               }
    }
}
else { 
        Write-Error "The SQL Server provisioning has failed due to configuration file or ARM template file path is not valid. Please check the log for more details" 
     }

    


