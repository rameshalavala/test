﻿$subscriptionId="62139dec-4b9a-4661-8448-b84bf8cc354b"
$tenantid="ff9c7474-421d-4957-8d47-c4b64dec87b5"
$ResourceGroupName="RG-PD-NE-PetraAnalytics-sit-02"
$ServerName="bataspdnepetrasit03"
$AutomationAccountName = "aa-pd-ne-sit02"
$AutomationRunbookName =  "batrb-pd-ne-petra-sit02_stopAAS"
$AutomationScheduleName = "Stop_AAS"
$CredentialName = "SP_AutomationAccount"
 
Write-Output "Getting Credential `"$CredentialName`" from stored Automation-Credential ..." 
$Credential = Get-AutomationPSCredential -Name $CredentialName 
if ($Credential -eq $null) 
{ 
    throw "Could not retrieve '$CredentialName' credential asset. Check that it exists in the Automation service!" 
}

Add-AzureRmAccount -TenantId $tenantid -ServicePrincipal -SubscriptionId $subscriptionId -Credential $Credential
Write-output "Starting the AAS Server instance Stop runbook"
$AAS = Get-AzureRmResource -ResourceName $ServerName -ResourceGroupName $ResourceGroupName

Write-output "AAS server - " $AAS

if($AAS)
{

   Write-output "Stopping AAS server - $ServerName"
   Suspend-AzureRmAnalysisServicesServer -ResourceGroupName $ResourceGroupName -name $ServerName 
    
   Write-output "Checking Schedule tag value with current stop AAS runbook schedule time"
   $schedule = $AAS.Tags.SCHEDULE

   Write-output "Tag Schdeule Value - " $schedule

   $schedule = $schedule -replace ";", ","
   $schedule = $schedule -replace '“', "'"
   $schedule = $schedule -replace '”', "'"
   $scheduleObject = $schedule | ConvertFrom-Json

   $shutDownHour = (($scheduleObject.Shutdown).Split(',')[1])
   $shutDownhour= [int]$shutDownHour.Substring(0,2)

   $currentStartTime = Get-AzureRmAutomationSchedule -Name $AutomationScheduleName -AutomationAccountName $AutomationAccountName -ResourceGroupName $ResourceGroupName

   If($currentStartTime)
   {
        if($shutDownHour -ne ($currentStartTime.StartTime).Hour)
        {       
          Write-output " Current Shutdown Time in Runbook and Schedule Tag Shutdown Value are not matching, Creating the new schedule"

           $format = [string]$shutDownHour + ":00:00"
                    
           $startDate =  ([DateTime] (Get-Date "$format" -Format r)).AddHours(24).ToUniversalTime()           
           $EndDate = ([DateTime]$startDate).AddYears(1)
           [System.DayOfWeek[]]$WeekDays = @([System.DayOfWeek]::Monday..[System.DayOfWeek]::Friday)
           
           $removeSchdeule = Remove-AzureRmAutomationSchedule -Name $AutomationScheduleName -AutomationAccountName $AutomationAccountName -ResourceGroupName $ResourceGroupName -Force
           
           $runbookSchedule = Get-AzureRmAutomationSchedule -Name $AutomationScheduleName -ResourceGroupName $ResourceGroupName -AutomationAccountName $AutomationAccountName -ErrorAction SilentlyContinue          
           
           if(!$runbookSchedule)
           {
               Write-output "Creating new schedule"
               $newSchedule = New-AzureRmAutomationSchedule -Name $AutomationScheduleName -AutomationAccountName $AutomationAccountName -ResourceGroupName $ResourceGroupName -WeekInterval 1 -DaysOfWeek $WeekDays -StartTime $startDate -ExpiryTime $EndDate -TimeZone "America/Danmarkshavn"          
           }

           Write-output "new schedule - " $newSchedule
           if($NewSchedule)
           {
             Write-output "Assigning new schedule to runbook"
             $runbookscheduled =  Register-AzureRmAutomationScheduledRunbook -AutomationAccountName $AutomationAccountName -Name $AutomationRunbookName -ScheduleName $NewSchedule.Name -ResourceGroupName $ResourceGroupName
             
           }

        }

        else{
        
          Write-Output "Stop Analysis Server instance runbook's schedule is according to Schedule tag shutdown value and it is $shutDownHour hour GMT"
        }
   
   }

}
 