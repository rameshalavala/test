######################################ProvisionDataFactory##############################################################################################
#NAME: ProvisionDataFactory.ps1
#AUTHOR: NileshKumar Rawal
#DATE: 17/04/2018
#DESCRIPTION: This script takes the data factory configuration from input configuration file and provisions the Data factory using ARM template.
#ARGUMENTS: $templateFilePath,$configurationFilePath, $clusterTag
#######################################ProvisionDataFactory##############################################################################################
param(

 [Parameter(Mandatory=$True)]
 [string]
 $templateFilePath = "C:\ARMTemplate\DataFactory-batdf-pd-ne-petra-sit-01\template_ADF.json",

 [Parameter(Mandatory=$True)]
 [string]
 $configurationFilePath = "PIAzureServicesConfiguration.json",

 [Parameter(Mandatory=$True)]
 [string]
 $adfTag

)


$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"
Write-Verbose "Validating the Service Config and ARM template file paths"
#validating the input files path
If((Test-Path $templateFilePath) -and (Test-Path $ConfigurationFilePath))
{
  #setting up the input variables 
  Write-Output "Getting Data Factory configuration"
  $configurationContext = Get-Content -Path $ConfigurationFilePath | Out-String | ConvertFrom-Json

  Write-Verbose "Initializing the input variabales and parameters"
  $provisioningEnv = $configurationContext.Environment 
  $subscriptionId = $configurationContext.SubscriptionID
  $resourceGroupName = $configurationContext.ResourceGroupName
  $deploymentName = $configurationContext.deploymentName
  $resourceName = $configurationContext.DataFactory.adfType.$adfTag
  $resourceLocation = $configurationContext.DataFactory.ResourceLocation
  $apiVersion="2015-01-01-preview"
  $resourceTag = $configurationContext.ResourceTag
  
  $deploymentName = $deploymentName + "_DataFactory"
  
  Write-Output "----------------------------------Configuration parameter----------------------------------------- "
  Write-Output "Enviroment Name : $provisioningEnv"
  Write-Output "SubscriptionID: " $subscriptionId
  Write-Output "Resource Group Name: " $resourceGroupName
  Write-Output "Deployment Name: " $deploymentName
  Write-Output "Resource Name: " $resourceName
  Write-Output "ResourceLocation: " $resourceLocation
  Write-Output "API Version: " $apiVersion
  Write-Output "----------------------------- -------End Of parameters----------------------------------------------"

  # select subscription
  Write-Output "Selecting subscription '$subscriptionId'";
  $subscriptionContext = Select-AzureRmSubscription -SubscriptionID $subscriptionId;
  Write-Output "Selected Subcription Name: " 
  Write-Output $subscriptionContext

  #Check for existing resource group
  Write-Verbose "Validating the Resource Group"
  #Create or check for existing resource group
  $resourceGroupExist = Get-AzureRmResourceGroup -Name $resourceGroupName -ErrorAction SilentlyContinue
  if(!$resourceGroupExist)
    {
        Write-Error "Resource group '$resourceGroupName' does not exist.Exiting from current deployment";
    
    }
    else
    {
    
       Write-Output "Using existing resource group '$resourceGroupName'";
       Write-Verbose "Validating the Resource"
       #Check for existing resource
       $resourceNameExist = (Get-AzureRmResource -ResourceName "$resourceName" -ResourceGroupName $resourceGroupName).Name
       
       if(!$resourceNameExist) 
        {
           # Start the deployment
          Write-Verbose "Starting the ARM template Deployment...";
          Write-Output "Starting ARM template deployment...";
          $CreatedBy = $resourceTag.CreatedBy
          $MARKET = $resourceTag.MARKET
          $CONTACT = $resourceTag.CONTACT
          $ENV = $resourceTag.ENV
          $SCHEDULE = $resourceTag.SCHEDULE

          $dfContext = New-AzureRmResourceGroupDeployment -Name $deploymentName -ResourceGroupName $resourceGroupName -TemplateFile $templateFilePath -ResourceName $resourceName -ResourceLocation $resourceLocation -ApiVersion $apiVersion -CreatedBy_Tag $CreatedBy -MARKET_Tag $MARKET -CONTACT_Tag $CONTACT -ENV_Tag $ENV -SCHEDULE_Tag $SCHEDULE

            If($dfcontext.ProvisioningState -eq "Succeeded") 
             {
               Write-Verbose "The Data Factory has been provisioned successfully!!!"
               Write-Output "The Data Factory $resourceName has been provisioned successfully!!!" 
               Write-Output "Data Factory Provisioning Context --" 
               $dfContext                       
             }    

             Else {
                    Write-Error "The Data Factory provisioning has failed.Please check the log for more details"        
                 }
         }
         Else{
           Write-Error "The Data Factory provisioning has failed due to resource is already exist or not available"
      }
      }
}
Else{
 Write-Error "The Data Factory provisioning has failed due to resource name is not available or ARM template file path is not valid. Please check the log for more details"

}

 