######################################ProvisionHDInsightCluster##############################################################################################
#NAME: ProvisionHDInsightCluster.ps1
#AUTHOR: NileshKumar Rawal
#DATE: 23/04/2018
#ModifiedBy: NileshKumar Rawal
#Modified: Updated on 29/03/2019 to accomodate the external hive meta store.
#DESCRIPTION: This script takes the cluster configuration from input configuration file and provisions the HDINsight cluster using ARM template.
#ARGUMENTS: $templateFilePath,$configurationFilePath, $clusterTag
#######################################ProvisionHDInsightCluster##############################################################################################

param(

 [Parameter(Mandatory=$True)]
 [string]
 $templateFilePath = "template.json",

 [Parameter(Mandatory=$True)]
 [string]
 $configurationFilePath = "PIAzureServicesConfiguration.json",

 [Parameter(Mandatory=$True)]
 [string]
 $clusterTag

)


#Set the Adls access for the cluster
Function Set-AdlsAccess
{

param(
 [Parameter(Mandatory=$True)]
 [string]
 $dataLakeStoreName,

 [Parameter(Mandatory=$True)]
 [string]
 $certificateFilePath,

 [Parameter(Mandatory=$True)]
 [securestring]
 $certificatePassword,

 [Parameter(Mandatory=$True)]
 [string]
 $servicePrincipalName,

 [Parameter(Mandatory=$True)]
 [string]
 $clusterRootPath

 )

 if (Test-AzureRmDataLakeStoreAccount -Name $dataLakeStoreName)
  {

   If(!(Test-AzureRmDataLakeStoreItem -AccountName $dataLakeStoreName -Path $clusterRootPath))
   {
     #$clusterRootPath = "/clusters/hdi023"
     Write-Host "Creating the cluster folder path" : $clusterRootPath
     New-AzureRmDataLakeStoreItem -Folder -AccountName $dataLakeStoreName -Path $clusterRootPath -Force
    }
    else{
      Write-Output "Using the existing cluster folder path" : $clusterRootPath
    }

    # ADLS Service Principal and Certificate
    Write-Output "Getting Certificate PFX "
    $certificatePFX = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($certificateFilePath, $certificatePassword)
 
    # Service Principal which is set to have access to ADLS
    $servicePrincipalContext = Get-AzureRmADServicePrincipal -SearchString $servicePrincipalName
    $servicePrincipalobjectId = $servicePrincipalContext.Id
    $servicePrincipalApplicationId = $servicePrincipalContext.ApplicationId
    Write-Output "service principal Application Id: " $servicePrincipalApplicationId
    Write-Output "service principal object Id: " $servicePrincipalobjectId
 
   # Grant the Service Prinicipal permissions to the following 3 folders in ADLS
   Set-AzureRmDataLakeStoreItemAclEntry -AccountName $dataLakeStoreName -Path "/" -AceType User -Id $servicePrincipalobjectId -Permissions All
   Set-AzureRmDataLakeStoreItemAclEntry -AccountName $dataLakeStoreName -Path "/" -AceType User -Id $servicePrincipalobjectId -Permissions All -Default
   Set-AzureRmDataLakeStoreItemAclEntry -AccountName $dataLakeStoreName -Path "/clusters" -AceType User -Id $servicePrincipalobjectId -Permissions All
   Set-AzureRmDataLakeStoreItemAclEntry -AccountName $dataLakeStoreName -Path $clusterRootPath -AceType User -Id $servicePrincipalobjectId -Permissions All

    Write-Output "Provided the Adls access using service principal" $servicePrincipalName
 }

 return $servicePrincipalContext;

}

$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"
Write-Verbose "Validating the Service Config and ARM template file paths"
#Validating the input files path
If((Test-Path $templateFilePath) -and (Test-Path $ConfigurationFilePath))
{
  #Setting up input variables 
  Write-Output "Getting HDInsight $clusterTag cluster configuration"
  $configurationContext = Get-Content -Path $ConfigurationFilePath | Out-String | ConvertFrom-Json

  Write-Verbose "Initializing the input variabales and parameters"
  $provisioningEnv = $configurationContext.Environment
  $aadTenantID =  $configurationContext.TenantID
  $subscriptionId = $configurationContext.SubscriptionID
  $resourceGroupName = $configurationContext.ResourceGroupName
  $deploymentName = $configurationContext.deploymentName
  $clusterName = $configurationContext.HDInsightCluster.clusterName.$clusterTag
  $clusterLocation = $configurationContext.HDInsightCluster.clusterLocation
  $clusterKind = $configurationContext.HDInsightCluster.clusterKind.$clusterTag
  $clusterVersion = $configurationContext.HDInsightCluster.clusterVersion
  $headNodeSize = $configurationContext.HDInsightCluster.headNodeSize
  $workerNodeSize = $configurationContext.HDInsightCluster.workerNodeSize
  $clusterAutoScale_MinNode = $configurationContext.HDInsightCluster.clusterAutoScaleMinNode
  $clusterAutoScale_MaxNode = $configurationContext.HDInsightCluster.clusterAutoScaleMaxNode
  $clusterLoginUserName = $configurationContext.HDInsightCluster.clusterLoginUserName
  $clusterLoginUserPassword = $configurationContext.HDInsightCluster.clusterLoginPassword 
  $sshUserName = $configurationContext.HDInsightCluster.sshUserName
  $sshUserPassword = $configurationContext.HDInsightCluster.sshUserPassword
  $clusterWorkerNodeCount = $configurationContext.HDInsightCluster.clusterWorkerNodeCount
  $identityCertificateFilePath = $configurationContext.HDInsightCluster.ServicePrincipalCertFilePath
  $identityCertPassword = $configurationContext.HDInsightCluster.ServicePrincipalCertPassword
  $servicePrincipalName = $configurationContext.HDInsightCluster.servicePrincipalName
  $dataLakeStoreName = $configurationContext.HDInsightCluster.dataLakeStoreName
  $blobStorageAccountName = $configurationContext.HDInsightCluster.blobStorageAccountName
  $hivemetastoreSqlServer = $configurationContext.HDInsightCluster.hivemetastoreSqlServer
  $hivemetastoreSqlDBName = $configurationContext.HDInsightCluster.hivemetastoreSqlDBName
  $hivemetastoreUserName = $configurationContext.HDInsightCluster.hivemetastoreUserName
  $hivemetastorePassword = $configurationContext.HDInsightCluster.hivemetastorePassword
  $resourceTag = $configurationContext.ResourceTag
  
  $deploymentName = $deploymentName + "_" + "$clusterTag" + "Cluster" + "$(get-date -f MM-dd-yyyy_HH_mm_ss)"
 

  
  Write-Output "---------------------------------------------------Configuration parameter--------------------------------------------------------- "
  Write-Output "Enviroment Name : $provisioningEnv"
  Write-Output "Subscription ID:  $subscriptionId"
  Write-Output "Resource Group Name: $resourceGroupName"
  Write-Output "Deployment Name: $deploymentName"
  Write-Output "Cluster Name: $clusterName"
  Write-Output "Cluster Location:  $clusterLocation"
  Write-Output "Cluster Kind: $clusterKind"
  Write-Output "Cluster Version:  $clusterVersion"
  Write-Output "cluster Login User Name:  $clusterLoginUserName"
  Write-Output "cluster Login User Password:  $clusterLoginUserPassword"
  Write-Output "ssh User Name:  $sshUserName"
  Write-Output "ssh User Password:  $sshUserPassword"
  Write-Output "Cluster head Node Size:  $headNodeSize"
  Write-Output "Cluster worker Node Size:  $workerNodeSize"
  Write-Output "Cluster Worker Node Count:  $clusterWorkerNodeCount"
  Write-Output "Identity Certificate Path:  $identityCertificateFilePath"
  Write-Output "Identity Certificate Password:  $identityCertPassword"
  Write-Output "AD Service Principal Name:  $servicePrincipalName"
  Write-Output "Data Lake Store Name: $dataLakeStoreName"
  Write-Output "Storage Account Name: $blobStorageAccountName"
  Write-Output "Hive Meta Store SQL Server: $hivemetastoreSqlServer"
  Write-Output "Hive Meta Store SQL database: $hivemetastoreSqlDBName"
  Write-Output "Hive Meta user: $hivemetastoreUserName"
  Write-Output "Hive Meta Password: [SecureString]"

  Write-Output "------------------------------------------------------------End Of parameters------------------------------------------------------"

  # select subscription
  Write-Output "Selecting subscription '$subscriptionId'";
  $subscriptionContext = Select-AzureRmSubscription -SubscriptionID $subscriptionId;
  Write-Output "Selected Subcription Name "
  Write-Output $subscriptionContext

$clusterLoginPassword = ConvertTo-SecureString "$clusterLoginUserPassword" -AsPlainText -Force
$sshPassword = ConvertTo-SecureString "$sshUserPassword" -AsPlainText -Force
$identityCertificatePassword = ConvertTo-SecureString "$identityCertPassword" -AsPlainText -Force
$hivePassword = ConvertTo-SecureString "$hivemetastorePassword" -AsPlainText -Force 

$adlsRootDir = "/"
$clusterRootPath = $adlsRootDir+"clusters/$clusterName"

Write-Output "Setting up Data Lake Store Access"
Write-Output "Calling custom Set-adlsAccess function"
$servicePrincipalContext = Set-AdlsAccess -dataLakeStoreName $dataLakeStoreName -certificateFilePath $identityCertificateFilePath -certificatePassword $identityCertificatePassword -servicePrincipalName $servicePrincipalName -clusterRootPath $clusterRootPath
$servicePrincipalobjectId = $servicePrincipalContext.Id
$servicePrincipalApplicationId = $servicePrincipalContext.ApplicationId
Write-output "service principal Application Id: " $servicePrincipalApplicationId
Write-Output "service principal object Id: " $servicePrincipalobjectId

$identityCertificateContents = [System.Convert]::ToBase64String((Get-Content $identityCertificateFilePath -Encoding Byte)) | ConvertTo-SecureString -AsPlainText -Force

Write-Output "Getting storage account key"
$storageAccountKeys = Get-AzureRmStorageAccountKey -ResourceGroupName "$resourceGroupName" -Name "$blobStorageAccountName"
$azureBlobStorageAccountKey = $storageAccountKeys.Value[0]


    #Check for existing resource group
    Write-Verbose "Validating the Resource Group"
    $resourceGroupExist = Get-AzureRmResourceGroup -Name $resourceGroupName -ErrorAction SilentlyContinue
     if(!$resourceGroupExist -and $azureBlobStorageAccountKey)
        {
          Write-Error "Resource group '$resourceGroupName' does not exist.Exiting from current deployment";
          #exit 1
        }
      else
         {
            Write-Output "Using existing resource group '$resourceGroupName'";
            $resourceNameExist = (Get-AzureRmResource -ResourceName "$clusterName" -ResourceGroupName $resourceGroupName).Name;
            Write-Verbose "Validating the Resource Name"
            #Check for existing resource name    
           if(!$resourceNameExist) 
             {
                  $CreatedBy = $resourceTag.CreatedBy
                  $MARKET = $resourceTag.MARKET
                  $CONTACT = $resourceTag.CONTACT
                  $ENV = $resourceTag.ENV
                  $SCHEDULE = $configurationContext.HDInsightCluster.SCHEDULETag

              Write-Verbose "Starting ARM Template deployment...";
              Write-Output "Starting ARM Template deployment...";

              # Start the deployment
              $armDeployment = New-AzureRmResourceGroupDeployment `
              -Name $deploymentName `
              -ResourceGroupName $resourceGroupName `
              -TemplateFile $templateFilePath `
              -clusterName $clusterName `
              -clusterLocation $clusterLocation `
              -clusterVersion $clusterVersion `
              -clusterLoginUserName $clusterLoginUserName `
              -clusterLoginPassword $clusterLoginPassword `
              -clusterWorkerNodeCount $clusterWorkerNodeCount `
              -clusterAutoScale_MinNode $clusterAutoScale_MinNode `
              -clusterAutoScale_MaxNode $clusterAutoScale_MaxNode `
              -clusterKind $clusterKind `
              -headNodeSize $headNodeSize `
              -workerNodeSize $workerNodeSize `
              -sshUserName $sshUserName `
              -sshPassword $sshPassword `
              -identityCertificatePassword $identityCertificatePassword `
              -identityCertificateContents $identityCertificateContents `
              -aadTenantId $aadTenantID `
              -servicePrincipalObjectId $servicePrincipalobjectId `
              -servicePrincipalApplicationId $servicePrincipalApplicationId `
              -hiveSQLDatabaseName $hivemetastoreSqlDBName `
              -hiveSqlServerName $hivemetastoreSqlServer `
              -hiveSQLServerUserName $hivemetastoreUserName `
              -hiveSQLServerPassword $hivePassword `
              -azureDataLakeStoreName $dataLakeStoreName `
              -clusterRootPath $clusterRootPath `
              -azureBlobStorageAccountName $blobStorageAccountName `
              -azureBlobStorageAccountKey $azureBlobStorageAccountKey `
              -CreatedBy_Tag $CreatedBy `
              -MARKET_Tag $MARKET `
              -CONTACT_Tag $CONTACT `
              -ENV_Tag $ENV `
              -SCHEDULE_Tag $SCHEDULE

            if ($armDeployment.ProvisioningState -eq "Succeeded")
              {
                Write-Verbose "The HDInsight cluster has been provisioned successfully!!! "
                Write-Output "The HDInsight cluster $clusterName has been provisioned successfully!!! "
                $armDeployment
          
              }

       }
            else{
               Write-Error "The HDInsight cluster provisioning has failed sue to the resource Name is already exist... exiting from deployment"
             #exit 1
            }
          }
  }
 else{
        Write-Error "The HDInsight cluster's Arm Template or configuration file is not valid....Exiting from deployment"
             #exit 1
      }
