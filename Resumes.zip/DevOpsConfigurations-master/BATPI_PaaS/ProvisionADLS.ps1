﻿######################################ProvisionADLS##############################################################################################
#NAME: ProvisionADLS.ps1
#AUTHOR: NileshKumar Rawal
#DATE: 03/04/2018
#DESCRIPTION: This script takes the Data lake store configuration from input configuration file and provisions the data lake store using ARM template.
#ARGUMENTS: $templateFilePath,$configurationFilePath
#######################################ProvisionADLS##############################################################################################
###lenght of the resource name should be in between 3 to 24 characters
param(

 [Parameter(Mandatory=$True)]
 [string]
 $templateFilePath = "C:\ARMTemplate\ExportedTemplate-Microsoft.AzureDataLakeStore\template_ADLS.json",

 [Parameter(Mandatory=$True)]
 [string]
 $configurationFilePath = "PIAzureServicesConfiguration.json"

)


$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"
#Validate the input files path
Write-Verbose "Validating the Service Config and ARM template file paths"
If((Test-Path $templateFilePath) -and (Test-Path $ConfigurationFilePath))
{
  #setting up the input variables 
  Write-Output "Getting Data Lake Store Account configuration"
  $configurationContext = Get-Content -Path $ConfigurationFilePath | Out-String | ConvertFrom-Json

  Write-Verbose "Initializing the input variabales and parameters"
  $provisioningEnv = $configurationContext.Environment 
  $subscriptionId = $configurationContext.SubscriptionID
  $resourceGroupName = $configurationContext.ResourceGroupName
  $deploymentName = $configurationContext.deploymentName
  $resourceName = $configurationContext.DataLakeStore.ResourceName
  $resourceLocation = $configurationContext.DataLakeStore.ResourceLocation
  $adlsDefaultFolder = $configurationContext.DataLakeStore.adlsDefaultFolder
  $defaultUserList = $configurationContext.DataLakeStore.defaultUserList
  $deploymentName = $deploymentName + "_DataLakeStore"
  $fullADLSName = "$resourceName" + ".azuredatalakestore.net"
  $resourceTag = $configurationContext.ResourceTag
  Write-Output "----------------------------------Configuration parameter----------------------------------------- "
  Write-Output "Enviroment Name : " $provisioningEnv
  Write-Output "SubscriptionID: " $subscriptionId
  Write-Output "Resource Group Name: " $resourceGroupName
  Write-Output "Deployment Name: " $deploymentName
  Write-Output "Resource Name: " $resourceName
  Write-Output "ResourceLocation: " $resourceLocation
  Write-Output "ADLS Default Folder Name: " $adlsDefaultFolder
  Write-Output "ADLS User List Path: " $defaultUserList

  Write-Output "----------------------------- -------End Of parameters----------------------------------------------"

  # select subscription
  Write-Output "Selecting subscription '$subscriptionId'";
  $subscriptionContext = Select-AzureRmSubscription -SubscriptionID $subscriptionId;
  Write-Output "Selected Subscription Name: " 
  Write-Output $subscriptionContext


  #Check for existing resource group
  Write-Verbose "Validating the Resource Group"
  $resourceGroupExist = Get-AzureRmResourceGroup -Name $resourceGroupName -ErrorAction SilentlyContinue
  if(!$resourceGroupExist)
   {
     Write-Error "Resource group '$resourceGroupName' does not exist.Exiting from current deployment";    
    
   }
   else{

        Write-Output "Using existing resource group '$resourceGroupName'";
        Write-Verbose "Validating the Resource Name"
        $resourceNameExist = (Get-AzureRmResource -ResourceName "$resourceName" -ResourceGroupName $resourceGroupName).Name;
        #Check for existing resource group
        # Start the deployment    
        if(!$resourceNameExist)  
         {
             $CreatedBy = $resourceTag.CreatedBy
             $MARKET = $resourceTag.MARKET
             $CONTACT = $resourceTag.CONTACT
             $ENV = $resourceTag.ENV
             $SCHEDULE = $resourceTag.SCHEDULE
             # Start the deployment
            Write-Verbose "Starting the ARM template Deployment...";
            Write-Output "Starting the ARM template Deployment...";

           $adlsContext = New-AzureRmResourceGroupDeployment -Name $deploymentName -ResourceGroupName $resourceGroupName -TemplateFile $templateFilePath -ResourceName $resourceName -ResourceLocation $resourceLocation -CreatedBy_Tag $CreatedBy -MARKET_Tag $MARKET -CONTACT_Tag $CONTACT -ENV_Tag $ENV -SCHEDULE_Tag $SCHEDULE ;
         }
         else{
            Write-Error "The data lake store account provisioning has failed due to resource name is not available. Please check the log for more details"
           }
       }

   if($adlsContext.ProvisioningState -eq "Succeeded")
     {
   
       Write-Verbose "The Data Lake Store has been provisioned successfully"
       Write-Output "The Data lake store $resourceName provisioned successfully!!!" -ForegroundColor Green

       Write-Verbose "Creating the default folder structure"
       Write-Output "Creating the default folder structure" : $adlsDefaultFolder

       New-AzureRmDataLakeStoreItem -Folder -AccountName $fullADLSName -Path "/$adlsDefaultFolder" -Force

       Write-Verbose "Assigning the read and execute access permissions for default userlist"
       Write-Output "Assigning the read and execute access permissions for default userlist"
<#
       $userlist = Get-Content $defaultUserList
       $i = 0

       foreach($user in $userlist)
        {
          $i++
          Write-Output "User ID $i " $user
          Set-AzureRmDataLakeStoreItemAclEntry -AccountName $fullADLSName -Path "/" -AceType User -Id $(Get-AzureRmADUser -Mail $user ).Id -Permissions ReadExecute
          Set-AzureRmDataLakeStoreItemAclEntry -AccountName $fullADLSName -Path "/" -AceType User -Id $(Get-AzureRmADUser -Mail $user ).Id -Permissions ReadExecute -Default
        }  #>
   }
}
else{
        Write-Error "The data lake store account provisioning has failed due to resource name is not available or ARM template file path is not valid. Please check the log for more details"
    }