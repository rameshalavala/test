######################################ProvisionAnalysisService##############################################################################################
#NAME: ProvisionAnalysisService.ps1
#AUTHOR: NileshKumar Rawal
#DATE: 10/04/2018
#DESCRIPTION: This script takes the Analysis Service configuration from input configuration file and provisions the Analysis Service using ARM template.
#ARGUMENTS: $templateFilePath,$configurationFilePath
#######################################ProvisionAnalysisService##############################################################################################
param( 
  

 [Parameter(Mandatory=$True)]
 [string]
 $templateFilePath = "template.json",


 [Parameter(Mandatory=$True)]
 [string]
 $configurationFilePath = "PIAzureServicesConfiguration.json"

)

#Get Blob Container URI for backup of cubes 
Function Get-BlobContainerUri
{
Param(
        [string]$resourceGroupName,
        [string]$storageAccountName,
        [string]$containerName
    )

##Adding 99 years. Please note that if we dont specify any expiry time, it will by
##default take one hour. After one hour you might not be able to take the backup.
$starttime = Get-Date
$endtime= $starttime.AddYears(99);

Write-Verbose "Getting storage account..."
$StorrageAccount = Get-AzureRmStorageAccount -ResourceGroupName $resourceGroupName -Name $storageAccountName;

$ctx = $StorrageAccount.Context

$container = Get-AzureStorageContainer -Name $containerName -Context $ctx -ErrorAction SilentlyContinue

If(!$container)
{
  Write-Verbose "Blob Container '$containerName' does not exist";
  Write-Verbose "Creating blob container '$containerName'";
  $container= New-AzureStorageContainer -Name $containerName -Context $ctx -Permission Off
}

Else
{
  Write-Verbose "Using existing blob container $containerName";
}

Write-Verbose "Getting Blob Container SAS URI... "

#$BlobContainerUri = $container.CloudBlobContainer.StorageUri.PrimaryUri.AbsoluteUri
$containerSASURI = New-AzureStorageContainerSASToken -Name $containerName -Permission rwl -FullUri -Context $ctx -StartTime $starttime -ExpiryTime $endtime
#$BlobContainerUri
return $containerSASURI;

}



$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"

Write-Verbose "Validating the Service Config and ARM template file paths"
#Validating input files path 
If((Test-Path $templateFilePath) -and (Test-Path $ConfigurationFilePath))
{
   #setting up the input variables
  Write-Output "Getting Analysis Service configuration"
  $configurationContext = Get-Content -Path $ConfigurationFilePath | Out-String | ConvertFrom-Json

  Write-Verbose "Initializing the input variabales and parameters"
  $provisioningEnv = $configurationContext.Environment 
  $subscriptionId = $configurationContext.SubscriptionID
  $resourceGroupName = $configurationContext.ResourceGroupName
  $deploymentName = $configurationContext.deploymentName
  $resourceName = $configurationContext.AnalysisService.ResourceName
  $resourceLocation = $configurationContext.AnalysisService.ResourceLocation
  $AAS_SKU = $configurationContext.AnalysisService.AAS_SKU
  $AAS_Admin = $configurationContext.AnalysisService.AAS_Admin
  $storageAccountName = $configurationContext.AnalysisService.storageAccountName.Value
  $containerName = $configurationContext.AnalysisService.storageAccountName.containerName
  $AAS_managedMode = 1
  $deploymentName = $deploymentName + "_AnalysisService"
  $resourceTag = $configurationContext.ResourceTag
  

  
  Write-Output "--------------------------------------------Configuration parameter--------------------------------------------------- "
  Write-Output "Enviroment Name :  $provisioningEnv"
  Write-Output "SubscriptionID:  $subscriptionId"
  Write-Output "Resource Group Name: $resourceGroupName"
  Write-Output "Deployment Name:  $deploymentName"
  Write-Output "Resource Name: $resourceName"
  Write-Output "ResourceLocation: $resourceLocation"
  Write-Output "Analysis service SKU:  $AAS_SKU"
  Write-Output "Analysis Service Admin: $AAS_Admin"
  Write-Output "Managed Mode $AAS_managedMode"
  Write-Output "For Backup, Storage Account and blonb Container Name : $storageAccountName $containerName"

  Write-Output "-------------------------------------------End Of parameters------------------------------------------------------------"

   
  

    # select subscription
    Write-Output "Selecting subscription '$subscriptionId'";
    $subscriptionContext = Select-AzureRmSubscription -SubscriptionID $subscriptionId;
    Write-Output $subscriptionContext

    #Getting Blob container URI and SAS token for setting up Backup for AAS
    Write-Output "Getting Blob Container Url...."
    $AAS_backupBlobContainerUri= Get-BlobContainerUri -storageAccountName $storageAccountName -containerName $containerName -resourceGroupName $resourceGroupName;
    Write-Output "Blob Conatiner Url- $AAS_backupBlobContainerUri"

    #Create or check for existing resource group
    Write-Verbose "Validating the Resource Group"
    $resourceGroupExist = Get-AzureRmResourceGroup -Name $resourceGroupName -ErrorAction SilentlyContinue
    if(!$resourceGroupExist)
     {
       Write-Error "Resource group '$resourceGroupName' does not exist.Exiting from current deployment";    
     }
     else{
           Write-Output "Using existing resource group '$resourceGroupName'";
           
           $resourceNameExist = (Get-AzureRmResource -ResourceName "$resourceName" -ResourceGroupName $resourceGroupName).Name
       
            #Create or check for existing resource group
            Write-Verbose "Validating the Resource"
           if(!$resourceNameExist -and $AAS_backupBlobContainerUri)
              {
                  $CreatedBy = $resourceTag.CreatedBy
                  $MARKET = $resourceTag.MARKET
                  $CONTACT = $resourceTag.CONTACT
                  $ENV = $resourceTag.ENV
                  $SCHEDULE = $configurationContext.AnalysisService.SCHEDULETag
                  # Start the deployment
                  Write-Verbose "Starting the ARM template Deployment...";
                  Write-Output "Starting the ARM template Deployment...";
                  $aasContext = New-AzureRmResourceGroupDeployment -Name $deploymentName -ResourceGroupName $resourceGroupName -TemplateFile $templateFilePath -ResourceName $resourceName -ResourceLocation $resourceLocation -sku $AAS_SKU -admin $AAS_Admin -backupBlobContainerUri $AAS_backupBlobContainerUri -managedMode $AAS_managedMode -CreatedBy_Tag $CreatedBy -MARKET_Tag $MARKET -CONTACT_Tag $CONTACT -ENV_Tag $ENV -SCHEDULE_Tag $SCHEDULE ;
               } 

           else {
                  Write-Error "The AAS server provisioning has failed due to resource name is not available or could not find blob storage container. Please check the log for more details"
                }

           if($aasContext.ProvisioningState -eq "Succeeded")
               {
                  Write-Verbose "The Ananlysis Service has been provisioned successfully"
                  Write-Output "The AAS Server $resourceName provisioned successfully!!!"
                  Write-Output "Azure Analysis Services Provisioning Context --" 
                  $aasContext
               }
            }
}
else {
        Write-Error "The AAS server provisioning has failed due to resource name is not available or ARM template file path is not valid or could not find blob storage container. Please check the log for more details" 
     }
