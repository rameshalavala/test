﻿$BlobName = $env:BlobName
$localTargetDirectory = $env:localTargetDirectory
$ContainerName = $env:ContainerName
$connection_string = $env:connection_string

write-host test value $env:connection_string
$ctx = New-AzureStorageContext -ConnectionString $connection_string
Get-AzureStorageBlobContent -Blob $BlobName -Container $ContainerName -Destination $localTargetDirectory -Context $ctx
if($?){

 Write-Host $BlobName has been downloaded
 }
 else
 {
 Write-Host $BlobName has been failed to download
 }