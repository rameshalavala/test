Import-Module -Name SqlServer
                                                                                                                                                                                                                                                               
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices")
$ServerName = "asazure://northeurope.asazure.windows.net/bataspdnepetrauat01"

$Dt = Get-Date -f dd.MM.yyyy
$AASname = $ServerName -replace 'asazure://northeurope.asazure.windows.net/',''
# Make sure that the backup folder exist.


$Server = New-Object Microsoft.AnalysisServices.Server
$Server.Connect($ServerName)

# Loop thru each database within the SSAS server.
foreach ($Database in $Server.Databases)
{
$Databasefile = $Database -replace '\s',''
$BackupFile  = "aasdbbackup/$AASname/$Dt/$DatabaseFile.abf"

Write-Host "Starting to backup $Database ..." -ForegroundColor Yellow
Backup-ASDatabase -Server $ServerName -BackupFile $BackupFile -Name $Database -ApplyCompression -ErrorAction Stop -AllowOverwrite
Write-Host "$Database has been backed up successfully." -ForegroundColor Green
}
$Server.Disconnect($ServerName)