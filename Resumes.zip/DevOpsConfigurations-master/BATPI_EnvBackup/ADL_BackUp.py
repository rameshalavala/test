from azure.common.credentials import ServicePrincipalCredentials
from azure.datalake.store import core, lib, multithread
import sys

import os

import json
#client_id_password = print (base64.b64encode(os.environ['client_id']))
token = lib.auth(tenant_id = os.environ['tenant_id'], \
client_secret = os.environ['client_secret'], \
client_id = os.environ['client_id'])

adlsFileSystemClient = core.AzureDLFileSystem(token, store_name=os.environ['adlsAccountName'])
path_list = json.loads(os.environ['Remote_Path'])
print(path_list)
try:
    for r_path in path_list:
        multithread.ADLDownloader(adlsFileSystemClient, lpath=os.environ['LocalPath'], rpath= r_path, \
        nthreads=64, overwrite=True, chunksize=1000000, buffersize=1000000, blocksize=1000000, \
        client=None, run=True,verbose=True)
except Exception as e:
    print ("Some Error: " + str(e))
##to create the directory in ADL
#adlsFileSystemClient.mkdir('/mysampledirectory')

#os.environ['Remote_Path']