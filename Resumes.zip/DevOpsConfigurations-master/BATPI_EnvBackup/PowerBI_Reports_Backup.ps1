

$workspace = $env:workspace
$localpath = $env:localpath
$User = "janardhanreddy_v@bat.com"
$PWord = ConvertTo-SecureString -String "DevOpsBat@15" -AsPlainText -Force
$UserCredential = New-Object -TypeName "System.Management.Automation.PSCredential" -ArgumentList $User, $PWord
Login-PowerBI -Credential $UserCredential

$workspaceName = Get-PowerBIWorkspace -Name $workspace

$reports = Get-PowerBIReport -Workspace $workspaceName

foreach($report in $reports){

$name = $report.Name
Export-PowerBIReport -WorkspaceId $workspaceName.Id -Id $report.Id -OutFile "$localpath\$name.pbix"

if($?){
Write-Host $name report has been downloaded.
}
else
{
Write-Host $name report download failed.
}
}

