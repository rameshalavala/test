$User = "85011001@bat.com"
$PWord = ConvertTo-SecureString -String "Jan@1234" -AsPlainText -Force
$UserCredential = New-Object -TypeName "System.Management.Automation.PSCredential" -ArgumentList $User, $PWord                                                                                                                                                                                                                                                               
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices")
$ServerName = "asazure://northeurope.asazure.windows.net/bataspdnepetrauat03"

$Dt = Get-Date -f dd.MM.yyyy

# Make sure that the backup folder exist.


$Server = New-Object Microsoft.AnalysisServices.Server
$Server.Connect($ServerName)

# Loop thru each database within the SSAS server.
foreach ($Database in $Server.Databases)
{
$Databasefile = $Database -replace '\s',''
$BackupFile  = "aasdbbackup/$Dt/$DatabaseFile.abf"

Write-Host "Starting to backup $DatabaseName ..." -ForegroundColor Green
Backup-ASDatabase -Server $ServerName -BackupFile $BackupFile -Name $Database -ApplyCompression -ErrorAction Stop -AllowOverwrite
Write-Host "$DatabaseName has been backed up successfully." -ForegroundColor Green
}
$Server.Disconnect($ServerName)