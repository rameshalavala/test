export dbn=prodoperationaldb;
b=`hive -e "set hive.cli.print.header=false;use $dbn;show tables"`
for tabnm in $b
do
echo `hive -e "show create table $dbn.$tabnm"` >> /DDL_BackUp/Prod_DB/$dbn.$tabnm.hql
zip -r /DDL_BackUp/Prod_DB/
done
