﻿$workspace = $env:workspace
$User = "janardhanreddy_v@bat.com"
$PWord = ConvertTo-SecureString -String "DevOpsBat@15" -AsPlainText -Force
$UserCredential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User,$PWord
$cre=Get-Credential -Credential $UserCredential
$token = Get-PBIAuthToken -credential $cre

 New-PBIGroup -name $workspace -authToken $token

 if($?){

 Write-Host $workspace has been created
 }
 else
 {
 Write-Host $workspace has been failed
 }


