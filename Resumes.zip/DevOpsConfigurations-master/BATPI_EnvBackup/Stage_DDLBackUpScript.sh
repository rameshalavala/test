export dbn=integratestagingdb;
b=`hive -e "set hive.cli.print.header=false;use $dbn;show tables"`
for tabnm in $b
do
echo `hive -e "set hive.cli.print.header=false;show create table $dbn.$tabnm"` >> /DDL_BackUp/Stage_DB/$dbn.$tabnm.hql
zip -r /DDL_BackUp/Stage_DB/
done