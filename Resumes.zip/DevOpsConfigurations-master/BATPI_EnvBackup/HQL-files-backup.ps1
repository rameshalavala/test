﻿$container_name = $env:container_name
$destination_path = $env:destination_path
$connection_string = $env:connection_string
$Container_path = $env:Container_path
$storage_account = New-AzureStorageContext -ConnectionString $connection_string

$blobs = Get-AzureStorageBlob -Container $container_name -Context $storage_account -Blob $Container_path

foreach ($blob in $blobs)
    {
		New-Item -ItemType Directory -Force -Path $destination_path
  
        Get-AzureStorageBlobContent -Container $container_name -Blob $blob.Name -Destination $destination_path -Context $storage_account -Force
      
    }
       
if($?){

 Write-Host $blobs has been downloaded
 }
 else
 {
 Write-Host $blobs has been downloaded
 }
