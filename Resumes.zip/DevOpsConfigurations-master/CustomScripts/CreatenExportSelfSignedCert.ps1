﻿param(

 [Parameter(Mandatory=$True)]
 [string]
 $selfSignedCertName,


 [Parameter(Mandatory=$True)]
 [Securestring]
 $selfSignedCertPassword,


 [Parameter(Mandatory=$True)]
 [string]
 $selfSignedCertExportPath

)

# Define certificate start and end dates

$currentDate = Get-Date

$endDate = $currentDate.AddYears(2)

$notAfter = $endDate.AddYears(1)

# Generate new self-signed certificate from "Run as Administrator" PowerShell session

$certStore = "Cert:\LocalMachine\My"

Write-Host "Self-Signed Certificate Name:" $selfSignedCertName
Write-Host "Export Path for Self-Signed Certificate pfx file:" $selfSignedCertExportPath

$certThumbprint =
(New-SelfSignedCertificateEx -Subject "CN=$selfSignedCertName" `
-StoreLocation "LocalMachine" `
-Provider "Microsoft Enhanced RSA and AES Cryptographic Provider" `
-NotAfter $notAfter).Thumbprint

# Export password-protected pfx file
Write-Host "Exporting the Self-Signed Certificate "
$selfSignedCertExportPFXPath = $selfSignedCertExportPath + "\$selfSignedCertName.pfx"
Export-PfxCertificate -Cert "$($certStore)\$($certThumbprint)" -FilePath $selfSignedCertExportPFXPath -Password $selfSignedCertPassword