﻿param( 
 [Parameter(Mandatory=$True)] 
 [string] $Folderpath, 
 [Parameter(Mandatory=$True)] 
 [string]$StorageAccountName,
 [Parameter(Mandatory=$True)] 
 [string]$StorageAccountKey,
 [Parameter(Mandatory=$True)] 
 [string]$ContainerName,
 [Parameter(Mandatory=$True)] 
 [string]$subscriptionId
 
)

"`n"

$BlobName = Get-ChildItem $Folderpath | Where-Object{$_.Extension -eq ".jar"}

$User = "enter username"
$PWord = ConvertTo-SecureString -String "enter password" -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User, $PWord
$output=Login-AzureRmAccount -Credential $Credential
$output=Select-AzureRmSubscription -SubscriptionID $subscriptionId;
$Ctx = New-AzureStorageContext -StorageAccountName $StorageAccountName -StorageAccountKey $StorageAccountKey 
$blob = Get-AzureStorageBlob -Context $Ctx -Container $ContainerName -Blob $BlobName 

if($blob -ne $null)
{
$snap = $blob.ICloudBlob.CreateSnapshot()

write-host ("exiting file {0} has been taken SnapShot" -f $BlobName.Name) -ForegroundColor Green
"`n `n"
$output=Set-AzureStorageBlobContent -File $BlobName.FullName -Container $ContainerName -Blob $BlobName -Context $Ctx -Force -BlobType Block
Write-Host ("{0} has been overwrite by new file " -f $BlobName.Name) -ForegroundColor Yellow

}
else
{
$output=Set-AzureStorageBlobContent -File $BlobName.FullName -Container $ContainerName -Blob $BlobName -Context $Ctx -BlobType Block

Write-Host ("you can see the error above becouse {0} file is deployed first time" -f $BlobName.Name) -ForegroundColor Green
}



