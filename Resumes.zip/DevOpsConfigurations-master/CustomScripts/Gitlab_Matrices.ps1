######################################ProvisionHDInsightCluster##############################################################################################
#NAME: Get-GitlabCommits_MergeRequests.ps1
#AUTHOR: NileshKumar Rawal
#DATE: 05/03/2019
#DESCRIPTION: This script takes the inputs like working directory and since days from which the data is requried and exports the commits and merge data into csv file
#ARGUMENTS: $PAT, $uriWithApi, $workingDirectoryPath, $sinceDays 
#######################################ProvisionHDInsightCluster##############################################################################################

Param (
  
 [Parameter(Mandatory=$False)]
 [string]
 $PAT = "X8tC2yhT5FxbM35-mdVX",

 [Parameter(Mandatory=$False)]
 [string]
 $uriWithApi = "https://code.itx-tools.bat.net/api/v4",

 [Parameter(Mandatory=$True)]
 [string]
 $workingDirectoryPath = "C:\Git\Dec2020",

 [Parameter(Mandatory=$True)]
 [int]
 $sinceDays = 35
 )

$Browser = New-Object System.Net.WebClient
$Browser.Proxy.Credentials =[System.Net.CredentialCache]::DefaultNetworkCredentials
$nl = [Environment]::NewLine

if(Test-Path -Path $workingDirectoryPath)
{
      Write-Host "Cleaning up old files in NewMatrices directory"
      Remove-Item -Path $workingDirectoryPath -Recurse -Force      
   }
   Else
   {
      Write-Host "NewtMatrices directory doest not exist, creating new directory"
      New-Item -Path $workingDirectoryPath -ItemType Directory -Force

   }

#$uriWithApi = "https://code.itx-tools.bat.net/api/v4"
#$PAT = "WDJ-aMP_Ar8Vn6YsQXgg"
$numberofProject = ''
$sinceDate = (Get-Date).AddDays(-$sinceDays) | Get-Date -Format "yyyy-MM-dd"
$afterDate = (Get-Date).AddDays(-($sinceDays+1)) | Get-Date -Format "yyyy-MM-dd"
$gitlabProject_FilePath = "$workingDirectoryPath\Gitlab_Project_List_$sinceDate.csv"
$gitlabProjectBranch_FilePath = "$workingDirectoryPath\Gitlab_Project_Branch_List_$sinceDate.csv"
$gitlabProjectBranchCommits_FilePath = "$workingDirectoryPath\Gitlab_Project_Branch_CommitsList_$sinceDate.csv"
$gitlabMerge_FilePath = "$workingDirectoryPath\Gitlab_Project_Branch_MergeList_$sinceDate.csv"

Write-Host "Since date for Gitlab Data exportation is :  $sinceDate"

Write-Host "************************************Exporting Project List from Gitlab*********************************************"
$projects = Invoke-RestMethod -Method Get " $uriWithApi/projects?private_token=$PAT&per_page=1000"
$numberofProject = $projects.Count

Write-Host "Number of project in gitlab - $numberofProject"

if($projects)
{
  Write-Host "Writing gitlab project data into csv file : " $gitlabProject_FilePath
 $projects | Select-Object -Property @{Name= 'ProjectID';Expression={$_.id}},
                                                @{Name= 'Project_Name';Expression={$_.name}},
                                                @{Name= 'Product';Expression={$_.tag_list}},
                                                @{Name= 'Porject_Created';Expression={$_.created_at}},
                                                @{Name ='DefaultBranch_Name';Expression ={$_.default_branch}} | Export-Csv "$gitlabProject_FilePath" -NoTypeInformation -Append

#id, name, created_at, default_branch | Export-Csv "$gitlabProject_FilePath" -NoTypeInformation
#Format-Table -Property id, name, created_at, default_branch -AutoSize | Out-File -FilePath "D:\BATPetra\GitlabStat\Gitlab_Project_List.csv" -NoTypeInformation
}

Write-Host "************************************Exporting Branch list from gitlab*****************************************"

$projectlists= Import-csv -Path "$gitlabProject_FilePath"

$i = 1
foreach($project in $projectlists)
{
  $projectName= $project.Project_Name
  $projectID = $project.ProjectID
  $Product = $project.Product
  #Write-Host "Project Name:" $project.name,"ID:" $project.id

  $projectbranchlists = Invoke-RestMethod -uri "$uriWithApi/projects/$projectID/repository/branches?private_token=$PAT"

   Write-Host " $i `tProject Name: $projectName"
   $numberOfBranch = $projectbranchlists.name.Count
   Write-Host "Number of branches :" $numberOfBranch
  $projectbranchlists | Select-Object -Property @{Name= 'ProjectID';Expression={$projectID}},
                                                @{Name= 'Project_Name';Expression={$projectName}},
                                                @{Name= 'Product';Expression={$Product}},
                                                @{Name= 'Branch_Name';Expression ={$_.name}} | Export-Csv "$gitlabProjectBranch_FilePath" -NoTypeInformation -Append
$i++;
}

$project_branchlists = import-csv -Path "$gitlabProjectBranch_FilePath"
Write-Host "*************************************Exporting the commit list from Gitlab******************************************"
$i=1
foreach($project_branch in $project_branchlists)
{  
   $numberOfCommits = '' 
   $projectID_branch = $project_branch.ProjectID
   $projectName_branch = $project_branch.Project_Name
   $project_branchName = $project_branch.Branch_Name
   $Product_branch = $project_branch.Product

   #$allProject_Branch_Commits = Invoke-RestMethod -uri "$uriWithApi/projects/$projectID_branch/repository/commits?ref_name=$project_branchName&private_token=$PAT&per_page=5000&since=$sinceDate"
  $allProject_Branch_Commits = Invoke-RestMethod -uri "$uriWithApi/projects/$projectID_branch/repository/commits?ref_name=$project_branchName&private_token=$PAT&per_page=5000&since=$sinceDate&until=2020-12-31"
   
   if($allProject_Branch_Commits)
   {
       $numberOfCommits = $allProject_Branch_Commits.Count
       Write-Host " $i `tProject Name: $projectName_branch `t`t`t`t Branch Name: $project_branchName " -ForegroundColor Blue
       Write-Host "Number of commits : "$numberOfCommits
       foreach($Commits in $allProject_Branch_Commits)
         {
             $id = $Commits.id
             $uniqueID = "$id-" + "$projectID_branch-" + "$project_branchName" 
       
             $date =[DateTime] (($Commits.committed_date).Split('T'))[0]
             $monthName = (Get-Culture).DateTimeFormat.GetMonthName($date.Month)
             $dateformat =  ($date| Get-Date -Format "yyyy-MM-dd").ToString()
             $emptyCommentFlag = ""
             if($Commits.message){
             $emptyCommentFlag = "No"    
             }
             else{
               $emptyCommentFlag = "Yes"
             } 
          
             if($Commits.message.Length -gt 250)
              {
                $message = $Commits.message.Substring(0,250)          
              }
             Else{
                 $message = $Commits.message
              }   
    
             # Write-Host "Writing commits to the file " -ForegroundColor Yellow
             $Commits | Select-Object -Property @{Name= 'Commit_ID';Expression={$_.id}},
                                                @{Name= 'Commit_shortID';Expression={$_.short_id}},
                                                @{Name= 'UniqueID';Expression={$uniqueID}},
                                                @{Name= 'Project_ID';Expression={$projectID_branch}},
                                                @{Name= 'Project_Name';Expression={$projectName_branch}},
                                                @{Name= 'Product';Expression={$Product_branch}},
                                                @{Name ='Branch_Name';Expression ={$project_branchName}},
                                                @{Name= 'Commit_Message';Expression={"$message`t"}},
                                                @{Name= 'Author_Name';Expression={$_.author_name}},
                                                @{Name= 'Commit_Date';Expression={$_.committed_date}},
                                                @{Name= 'Date';Expression={"`t$dateformat`t"}},
                                                @{Name= 'Month';Expression={"`t$monthName"}},
                                                @{Name= 'EmptyComments';Expression={$emptyCommentFlag}} | Export-Csv -Append "$gitlabProjectBranchCommits_FilePath" -NoTypeInformation -Force
          }
    }
 $i++
}




$projectListMerge= Import-csv -Path "$gitlabProject_FilePath"

Write-Host "************************************Exporting the Merge request from Gitlab*******************************************"
$i = 1
foreach($projectMerge in $projectListMerge)
 {
     $projectName_Merge = $projectMerge.Project_Name
     $projectID_Merge = $projectMerge.ProjectID
     $Product_Merge = $projectMerge.Product  
     Write-Host "$i Project Name:" $projectName_Merge

      $projectBranchMergeList = Invoke-RestMethod -uri "$uriWithApi/projects/$projectID_Merge/merge_requests?private_token=$PAT&per_page=2000&created_after=$afterDate&created_before=2021-01-01"
     #$projectBranchMergeList = Invoke-RestMethod -uri "$uriWithApi/projects/$projectID_Merge/merge_requests?private_token=$PAT&per_page=2000&created_after=$afterDate&created_before=2020-06-01"
     
     if($projectBranchMergeList)
     {
       $numberofMerge = $projectBranchMergeList.Count
       Write-Host "Number of merge request: " $numberofMerge

       foreach($merge in $projectBranchMergeList)
        {
           $merge | Select-Object -Property @{Name= 'Merge_ID';Expression={$_.id}},
                                            @{Name= 'Project_Name';Expression={$projectName_Merge}},                                               
                                            @{Name= 'ProjectID';Expression={$projectID_Merge}},
                                            @{Name= 'Product';Expression={$Product_Merge}},
                                            @{Name= 'Merge_Title';Expression={$_.title}},
                                            @{Name ='Merge_Description';Expression ={$_.description}},
                                            @{Name= 'state';Expression={$_.state}},
                                            @{Name ='Merge_created_at';Expression ={$_.created_at}},
                                            @{Name= 'Merge_updated_at';Expression={$_.updated_at}},
                                            @{Name ='Merge_target_branch';Expression ={$_.target_branch}},
                                            @{Name ='Merge_source_branch';Expression ={$_.source_branch}},
                                            @{Name ='Merge_Author';Expression ={ $_.author.username}} | Export-Csv "$gitlabMerge_FilePath" -NoTypeInformation -Append
                                              
        }
     }
    $i++;
}

