﻿param(

[Parameter(Mandatory=$True)]
 [string]
 $tenantId,

 [Parameter(Mandatory=$True)]
 [string]
 $applicationId,

 [Parameter(Mandatory=$True)]
 [string]
 $pfxCertificatePath,

 [Parameter(Mandatory=$True)]
 [string]
 $pfxCertifcatePasswordFilePath

)

#sign in
Write-Host "Logging in...";
if ((Test-Path $pfxCertificatePath) -and (Test-Path $pfxCertifcatePasswordFilePath))
{

$pfxCertifcatePassword = Get-Content -Path "C:\PIAutomation\AzureAutoLoginPFXCertPassword.txt" | ConvertTo-SecureString


 $pFXCert = New-Object -TypeName System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList @($pfxCertificatePath, $pfxCertifcatePassword) 
 $certThumbprint = $PFXCert.Thumbprint


 $azureLoginContext = Login-AzureRmAccount -ServicePrincipal -TenantId $tenantId -ApplicationId $applicationId -CertificateThumbprint $certThumbprint
 $azureSubcription = $azureLoginContext.Context.Subscription

 if($azureSubcription)
 {

  Write-Host "Logged-In Successfully..!!!!" -ForegroundColor Green
  
 }
 Else{
 
 Write-Host "Azure Login failed..!!!!" -ForegroundColor Red
 }

 }