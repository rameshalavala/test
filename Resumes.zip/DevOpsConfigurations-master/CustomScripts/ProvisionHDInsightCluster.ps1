﻿param(
 [Parameter(Mandatory=$True)]
 [string]
 $subscriptionId,

 [Parameter(Mandatory=$True)]
 [string]
 $resourceGroupName,

 [Parameter(Mandatory=$True)]
 [string]
 $clusterName,

 [Parameter(Mandatory=$True)]
 [string]
 $clusterLocation,

 [Parameter(Mandatory=$True)]
 [string]
 $clusterLoginUserName,

 [Parameter(Mandatory=$True)]
 [Securestring]
 $clusterLoginPassword,

 [Parameter(Mandatory=$True)]
 [string]
 $sshUserName,

 [Parameter(Mandatory=$True)]
 [securestring]
 $sshPassword,

 [Parameter(Mandatory=$True)]
 [string]
 $clusterKind,

 [Parameter(Mandatory=$True)]
 [int]
 $clusterVersion = 3.6,

 [Parameter(Mandatory=$false)]
 [string]
 $clusterOSType = "Linux",

 [Parameter(Mandatory=$True)]
 [int]
 $clusterWorkerNodeCount,

 [Parameter(Mandatory=$false)]
 [string]
 $headNodeSize = "Standard_D12_V2",

 [Parameter(Mandatory=$false)]
 [string]
 $workerNodeSize = "Standard_D12_V2",

 [Parameter(Mandatory=$True)]
 [string]
 $identityCertificateFilePath,

 [Parameter(Mandatory=$True)]
 [string]
 $identityCertificatePassword,

 [Parameter(Mandatory=$True)]
 [string]
 $servicePrincipalName,

 [Parameter(Mandatory=$True)]
 [string]
 $dataLakeStoreName,

 [Parameter(Mandatory=$True)]
 [string]
 $blobStorageAccountName,

 [Parameter(Mandatory=$True)]
 [string]
 $azureBlobStorageAccountKey,

 [Parameter(Mandatory=$True)]
 [string]
 $hivemetastoreSqlAzureServerName,

 [Parameter(Mandatory=$True)]
 [string]
 $hivemetastoreDBName,

 [Parameter(Mandatory=$True)]
 [string]
 $hivemetastoreDBUsername,

 [Parameter(Mandatory=$True)]
 [securestring]
 $hivemetastoreDBPassword

)

#Set the Adls access for the cluster
Function Set-AdlsAccess
{

param(
 [Parameter(Mandatory=$True)]
 [string]
 $dataLakeStoreName,

 [Parameter(Mandatory=$True)]
 [string]
 $certificateFilePath,

 [Parameter(Mandatory=$True)]
 [securestring]
 $certificatePassword,

 [Parameter(Mandatory=$True)]
 [string]
 $servicePrincipalName,

 [Parameter(Mandatory=$True)]
 [string]
 $clusterRootPath

 )


 if (Test-AzureRmDataLakeStoreAccount -Name $dataLakeStoreName)
  {

   If(!(Test-AzureRmDataLakeStoreItem -AccountName $dataLakeStoreName -Path $clusterRootPath))
   {
     #$clusterRootPath = "/clusters/hdi023"
     Write-Host "Creating the cluster folder path" : $clusterRootPath
     New-AzureRmDataLakeStoreItem -Folder -AccountName $dataLakeStoreName -Path $clusterRootPath -Force
    }
    else{
      Write-Host "Using the existing cluster folder path" : $clusterRootPath
    }

    # ADLS Service Principal and Certificate
    Write-Host "Getting Certificate PFX "
    $certificatePFX = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($certificateFilePath, $certificatePassword)
 
    # Service Principal which is set to have access to ADLS
    $servicePrincipal = Get-AzureRmADServicePrincipal -SearchString $servicePrincipalName
    $servicePrincipalobjectId = $servicePrincipal.Id
    $servicePrincipalApplicationId = $servicePrincipal.ApplicationId
    write-host "service principal Application Id: " $servicePrincipalApplicationId
    write-host "service principal object Id: " $servicePrincipalobjectId
 
   # Grant the Service Prinicipal permissions to the following 3 folders in ADLS
   Set-AzureRmDataLakeStoreItemAclEntry -AccountName $dataLakeStoreName -Path "/" -AceType User -Id $servicePrincipalobjectId -Permissions All
   Set-AzureRmDataLakeStoreItemAclEntry -AccountName $dataLakeStoreName -Path "/clusters" -AceType User -Id $servicePrincipalobjectId -Permissions All
   Set-AzureRmDataLakeStoreItemAclEntry -AccountName $dataLakeStoreName -Path $clusterRootPath -AceType User -Id $servicePrincipalobjectId -Permissions All

    Write-Host "Provided the Adls access"
<#
   $ActEntry = (Get-AzureRmDataLakeStoreItemAclEntry -AccountName $dataLakeStoreName -Path $clusterRootPath).Id

   If ($AclEntry -contains $servicePrincipalobjectId)
   {
     Write-Host "Provided the Adls access"
   
   }
   #>
 }

 return $servicePrincipalobjectId;

}

# Sign in to your Azure account
Login-AzureRmAccount
# List all the subscriptions associated to your account
Get-AzureRmSubscription
# Select a subscription
Set-AzureRmContext -SubscriptionId $subscriptionId

$adlsRootDir = "/"
$clusterRootPath = $adlsRootDir+"clusters/$clusterName"

$httpLoginCredentials = New-Object System.Management.Automation.PSCredential ($clusterLoginUserName, $clusterLoginPassword);
$sshUserCredentials = New-Object System.Management.Automation.PSCredential ($sshUserName, $sshPassword);
$hivemetastoreSqldbCredentials = New-Object System.Management.Automation.PSCredential ($hivemetastoreDBUsername, $hivemetastoreDBPassword);

#Setting up data lake store access for Hdinsight cluster
Write-Host "Setting up data lake store access for cluster"
$servicePrincipalobject = Set-AdlsAccess -dataLakeStoreName $dataLakeStoreName -certificateFilePath $identityCertificateFilePath -certificatePassword $identityCertificatePassword -servicePrincipalName $servicePrincipalName -clusterRootPath $clusterRootPath

Write-Host "Service Principal Name" $servicePrincipalName
Write-Host "Service Principal object Id" $servicePrincipalobject.Guid

$resourceGroup = Get-AzureRmResourceGroup -Name $resourceGroupName -ErrorAction SilentlyContinue
if(!$resourceGroup)
{
    Write-Host "Resource group '$resourceGroupName' does not exist.Exiting from current deployment";
}
else{
      Write-Host "Using existing resource group '$resourceGroupName'";

       $tenantID = (Get-AzureRmContext).Tenant.TenantId
       $blobStorageAccountName = "$blobStorageAccountName" + ".blob.core.windows.net"
       $servicePrincipalobjectId = $servicePrincipalobject.Guid

       $certificatepassword = "devops"

       Write-Host "Setting up the HDInsight cluster config"
       # Setup configuration to existing Hive Metastore Azure SQL DB and HDInsight cluster Identity
       $azureHDInsightConfig = New-AzureRMHDInsightClusterConfig -debug -ErrorVariable $errorVar `
                               -ClusterType $clusterKind `
                               | Add-AzureRMHDInsightMetastore `
                               -SqlAzureServerName $hivemetastoreSqlAzureServerName `
                               -DatabaseName $hivemetastoreDBName `
                               -Credential $hivemetastoreSqldbCredentials `
                               -MetastoreType HiveMetastore `
                               | Add-AzureRmHDInsightClusterIdentity `
                               -AadTenantId $tenantId `
                               -ObjectId $servicePrincipalobjectId `
                               -CertificateFilePath $identityCertificateFilePath `
                               -CertificatePassword $certificatepassword
                               
      Add-AzureRmHDInsightStorage -Config $azureHDInsightConfig -StorageAccountName $blobStorageAccountName -StorageAccountKey $azureBlobStorageAccountKey

     # output any error
     Write-Output $errorVar

     $clusterVersion = 3.6
     #$certificatepassword = "devops"

     # Create new HDInsight cluster with config object
     Write-Host "Starting the configuration of HDInsight cluster"
     New-AzureRmHDInsightCluster `
     -ClusterName $clusterName `
     -Location $clusterLocation `
     -ResourceGroupName $resourceGroupName `
     -HttpCredential $httpLoginCredentials `
     -SshCredential $sshuserCredentials `
     -ClusterType $clusterType `
     -OSType $clusterOSType `
     -Version $clusterVersion `
     -DefaultStorageAccountType AzureDataLakeStore `
     -DefaultStorageAccountName "$dataLakeStoreName.azuredatalakestore.net" `
     -DefaultStorageRootPath $clusterRootPath `
     -AadTenantId $tenantId `
     -ObjectId $servicePrincipalobjectId `
     -ClusterSizeInNodes $clusterWorkerNodeCount `
     -ClusterTier Standard `
     -HeadNodeSize $headNodeSize `
     -WorkerNodeSize $workerNodeSize `
     -Config $azureHDInsightConfig `
     -debug `
     -ErrorVariable $errorVar
     

    # -AdditionalStorageAccounts $storage `
 
# output any error
 if ($errorVar)
  {   
   Write-Host "Provisioning of HDInsight cluster is failed" -ForegroundColor Red
   Write-Output $errorVar
  }

  else
  {
  Write-Host "Provisioning of HDInsight Cluster is done successfully!!!" -ForegroundColor Green
  }
}
      