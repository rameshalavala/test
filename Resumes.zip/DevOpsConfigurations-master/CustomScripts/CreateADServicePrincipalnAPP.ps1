﻿param(

[Parameter(Mandatory=$True)]
[string]
 $subscriptionId,

 [Parameter(Mandatory=$True)]
 [string]
 $adServicePrincipalName,

 [Parameter(Mandatory=$True)]
 [securestring]
 $adServicePrincipalPFXCertPassword,

 [Parameter(Mandatory=$True)]
 [string]
 $adServicePrincipalCertPFXFileExportPath,

 [Parameter(Mandatory=$True)]
 [string]
 $adAppName

)
Import-Module -Name AzureRM.Resources
function CreateSelfSignedCertfiacteandExport()
{

param(

 [Parameter(Mandatory=$True)]
 [string]
 $selfSignedCertName,


 [Parameter(Mandatory=$True)]
 [Securestring]
 $selfSignedCertPassword,


 [Parameter(Mandatory=$True)]
 [string]
 $selfSignedCertExportPath

)
Import-Module "C:\CustomPSModule\New-SelfSignedCertificateEx.ps1"

# Define certificate start and end dates

$currentDate = Get-Date

$endDate = $currentDate.AddYears(2)

$notAfter = $endDate.AddYears(1)

# Generate new self-signed certificate from "Run as Administrator" PowerShell session

$certStore = "Cert:\LocalMachine\My"

Write-Host "Self-Signed Certificate Name:" $selfSignedCertName
Write-Host "Export Path for Self-Signed Certificate pfx file:" $selfSignedCertExportPath

$certThumbprint =
(New-SelfSignedCertificateEx -Subject "CN=$selfSignedCertName" `
-StoreLocation "LocalMachine" `
-Provider "Microsoft Enhanced RSA and AES Cryptographic Provider" `
-NotAfter $notAfter).Thumbprint

# Export password-protected pfx file
Write-Host "Exporting the Self-Signed Certificate "
$selfSignedCertExportPFXPath = $selfSignedCertExportPath + "\$selfSignedCertName.pfx"
Export-PfxCertificate -Cert "$($certStore)\$($certThumbprint)" -FilePath $selfSignedCertExportPFXPath -Password $selfSignedCertPassword

if($selfSignedCertExportPFXPath)
 {
   Write-Host "Exported the PFX file:" $selfSignedCertExportPFXPath
   return $selfSignedCertExportPFXPath;
 }
 else{
 
 Write-Host "PFX file did not get exported"
 }

#end of function
}


$ErrorActionPreference = "Stop"

# sign in
$azureLoginCreds = Get-Credential -Message "Provide the Azure UserName and Password"
Write-Host "Logging in...";
Login-AzureRmAccount -Credential $azureLoginCreds;

# select subscription
Write-Host "Selecting subscription '$subscriptionId'";
Select-AzureRmSubscription -SubscriptionID $subscriptionId;

$pfxCertFilePath = CreateSelfSignedCertfiacteandExport -selfSignedCertName $adServicePrincipalName -selfSignedCertPassword $adServicePrincipalPFXCertPassword -selfSignedCertExportPath $adServicePrincipalCertPFXFileExportPath;
 
 $pfxCertFilePath = "C:\ExportedCerts\BATPIDevOpsAutomation.pfx"
if($pfxCertFilePath)
{
 
  # Create Key Credential Object
  $cert = New-Object -TypeName System.Security.Cryptography.X509Certificates.X509Certificate -ArgumentList @($pfxCertFilePath, $adServicePrincipalPFXCertPassword)

  $keyValue = [System.Convert]::ToBase64String($cert.GetRawCertData())  

  #$keyCredential = New-Object -TypeName Microsoft.Azure.Commands.Resources.Models.ActiveDirectory.PSADKeyCredential
  $keyCredential= New-Object Microsoft.Azure.Graph.RBAC.Version1_6.ActiveDirectory.PSADKeyCredential

  # Define properties of Key Credential object

  $keyCredential.StartDate = $currentDate

  $keyCredential.EndDate = $endDate

  $keyCredential.CertValue = $keyValue

  # Define Azure AD Application Properties
  $adAppHomePage = "https://" + "$adAppName" + ".com"
  $adAppIdentifierUri = "$adAppHomePage" + "/AutoLogin01"

  # Create new Azure AD Application

  $adApp = New-AzureRmADApplication `
  -DisplayName $adAppName `
  -HomePage $adAppHomePage `
  -IdentifierUris $adAppIdentifierUri `
  -KeyCredentials $keyCredential

Write-Output "New Azure AD App Id: $($adApp.ApplicationId)"

# Create Azure AD Service Principal

New-AzureRmADServicePrincipal -ApplicationId $adApp.ApplicationId

# Assign Owner permissions to the Service Principal for the selected subscription

$resourceGroups = (Get-AzureRmResourceGroup).ResourceGroupName
foreach($resourceGroupName in $resourceGroups)
{
  New-AzureRmRoleAssignment -RoleDefinitionName Contributor -ServicePrincipalName $adApp.ApplicationId -ResourceGroupName $resourceGroupName

}

}