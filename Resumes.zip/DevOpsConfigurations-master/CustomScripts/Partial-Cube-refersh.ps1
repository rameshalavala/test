﻿param( 
 [Parameter(Mandatory=$True)] 
 [string] 
 $ServerName, 
 [Parameter(Mandatory=$True)] 
 [string] 
 $DBName,
 [Parameter(Mandatory=$True)] 
 [string] 
 $TableNames
 
) 

Write-Output "Environment details are below "
Write-Output "SererName:"  $ServerName
Write-Output "DBName:"  $DBName

#Login
$User = "enter username"
$PWord = ConvertTo-SecureString -String "enter password" -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User, $PWord

$arry=$TableNames.Split(',')
$args = @($arry)
foreach($Value in $args)
{

$output = Invoke-ProcessTable -TableName $Value -Database $DBName -RefreshType Full -Server $ServerName -Credential $Credential
if($?)
{
   Write-Output ("CubeName: {0} ____has been Processsed Successfully " -f $table.Name)
   Write-Output ("{0} 
                     |
                "-f $emptyspace )
  }
else
{


Write-Output ("CubeName: {0}____Process Failed------???____See Error Details above"  -f $table.Name)
Write-Output ("{0} 
                     |
                     |
                "-f $emptyspace )
   
}

}


#Petra PI Cube-R2_PL
#Petra PI Cube-R2_ANZ
#asazure://northeurope.asazure.windows.net/bataspdnepetrasit02
#asazure://northeurope.asazure.windows.net/bataspdnepetrauat03


