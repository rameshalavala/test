﻿param(
[parameter(mandatory=$true)][string]$sourceADLSpath,
[parameter(mandatory=$true)][string]$DestADLSpath,
[parameter(mandatory=$true)][string]$sourceADLSName,
[parameter(mandatory=$true)][string]$DestADLSName
)

$localpath = D:\localpath\


$azureAccountName ="be8c4f76-8e9f-4499-b810-c1fce86bbb5a"
$azurePassword = ConvertTo-SecureString -String "fDG/I1MR3u0zzXVJ3v34TIqaaYi9bIdCWnifVfcsbgo=" -AsPlainText -Force
$psCred = New-Object System.Management.Automation.PSCredential($azureAccountName, $azurePassword)
Connect-AzureRmAccount -Credential $psCred -TenantId ff9c7474-421d-4957-8d47-c4b64dec87b5 -ServicePrincipal

Export-AdlStoreItem -Account $sourceADLSName -Path $sourceADLSpath -Destination $localpath
Import-AdlStoreItem -Account $DestADLSName -Path $localpath -Destination $DestADLSpath -Force

Remove-Item $localpath -Force -Recurse


