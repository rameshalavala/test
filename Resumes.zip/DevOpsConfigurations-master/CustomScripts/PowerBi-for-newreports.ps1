﻿param(
[parameter(mandatory=$true)]
[string]$Folderpath,
[Parameter(Mandatory=$True)]        
[string]$ServerName,
[Parameter(Mandatory=$True)]        
[string]$DBName,
[parameter(mandatory=$true)]
[string]$WorkSpaceName
)

[Reflection.Assembly]::LoadWithPartialName( "System.IO.Compression.FileSystem" )
$pbixfiles= Get-ChildItem $Folderpath;
foreach($file in $pbixfiles){
$filename = $file.Basename + ".zip"
Rename-Item $file.FullName $filename
$dir=$file.BaseName + "unzip"

$emptydir=New-Item "$Folderpath\$dir" -ItemType Directory

function unzip{
param([string]$zipfile ,[string]$path)
[System.IO.Compression.ZipFile]::ExtractToDirectory($zipfile, $path)
}
unzip "$Folderpath\$filename" $emptydir

$FindstringforServerName = "(asazure:)\/\/(northeurope\.asazure\.windows\.net)\/[a-z0-9]+"
$FindstringforDBName = "(Petra)\s(PI)\s(Cube)[-a-zA-Z0-9_]+"
(Get-Content "$emptydir\Connections") | ForEach-Object{
$_ -replace $FindstringforServerName,$ServerName `
   -replace $FindstringforDBName,$DBName
 
} | Set-Content "$emptydir\Connections"

[string]$zipFN = "$Folderpath\$filename"
[string]$fileToZip = "$emptydir\Connections"
[System.IO.Compression.ZipArchive]$ZipFile = [System.IO.Compression.ZipFile]::Open($zipFN, ([System.IO.Compression.ZipArchiveMode]::Update))
$Entry=$ZipFile.GetEntry("Connections")
    if ($Entry)
    {
        $Entry.Delete()
    }
$result=[System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($ZipFile, $fileToZip, (Split-Path $fileToZip -Leaf))
$ZipFile.Dispose()
Remove-Item $emptydir -Force -Recurse

}
$allfiles=Get-ChildItem $Folderpath
foreach($file in $allfiles){
$finalpbix=$file.BaseName + ".pbix"
Rename-Item $file.FullName $finalpbix
}

Write-Host ".......Input Parameters........"
write-host "Root folder path:" $folderpath -ForegroundColor Yellow
Write-Host "ServerName :" $ServerName -ForegroundColor Yellow
Write-Host "DBName :" $DBName -ForegroundColor Yellow
Write-Host "WorkSpaceName : " $WorkSpaceName -ForegroundColor Yellow

$User = "enter username"
$PWord = ConvertTo-SecureString -String "enter password" -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User, $PWord
$tokens = Get-PBIAuthToken -credential $Credential
$workspace = Get-PBIGroup -authToken $tokens -name $WorkSpaceName
$files = Get-ChildItem $FolderPath

foreach($file in $files)
{ 
$pbix= $file.FullName
Import-PBIFile -authToken $tokens -groupId $workspace.id -file $pbix
}

