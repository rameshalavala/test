
$PAT = "X8tC2yhT5FxbM35-mdVX"

$uriWithApi = "https://code.itx-tools.bat.net/api/v4"

#Change PATH
$workingDirectoryPath = "D:\BATPetra\GitlabStat"


$totalPages = [int](Invoke-WebRequest -uri "$uriWithApi/users?&private_token=$PAT&per_page=2000").Headers.'X-Total-Pages'

$date = Get-Date -Format "yyyy-MM-dd"
Write-Host "Nuber of Pages : $totalPages"

for($page=1;$page -le $totalPages ; $page++)
{
 Write-Host "Page Number - $page"

 $Users = Invoke-RestMethod -uri "$uriWithApi/users?&private_token=$PAT&page=$page&per_page=2000"

 Write-Host "Number of Users :" $Users.Count
foreach($user in $Users)

{
   If(!($user.current_sign_in_at))
   {  
    $currentSignIn = "Never"

   }
   Else{
     $currentSignIn = $user.current_sign_in_at
   }
  
  If(!($user.last_activity_on))
   {  
    $currentSignIn = "Never"

   }
   Else{
     $lastActivityOn = $user.last_activity_on
   }

   If(!($user.last_sign_in_at))
   {  
    $last_sign_in_at = "Never"

   }
   Else{
     $last_sign_in_at = $user.last_sign_in_at
   }
  
  

  if($user.is_admin -eq "True")
  
  {
     $userRole = "Admin" 
  
  }  
  Else{
        $userRole = "User"
    }
     

      $user | Select-Object -Property @{Name= 'UserID';Expression={$_.id}},
                                        @{Name= 'Name';Expression={$_.name}},
                                        @{Name= 'UserName';Expression={$_.username}},
                                        @{Name= 'State';Expression={$_.state}},
                                        @{Name= 'CurrentSign';Expression={"$currentSignIn`t"}},
                                        @{Name= 'LastActivity';Expression={"$lastActivityOn`t"}},
                                        @{Name= 'LastSignIn';Expression={"$last_sign_in_at`t"}},
                                        @{Name= 'UserRole';Expression={"$userRole`t"}},
                                        @{Name= 'EmailID';Expression={$_.email}} | Export-Csv -Append "$workingDirectoryPath\GiltabUserList_$date.csv" -NoTypeInformation -Force
    
    
    
}

}

