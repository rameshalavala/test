﻿######################################Send-Email##############################################################################################
#NAME: Send-Email.ps1
#AUTHOR: NileshKumar Rawal
#DATE: 31/1/2019
#DESCRIPTION: This script send email notification to exported gitlab user list.
#######################################Send-Email##############################################################################################

$mailFrom= "Gitlab Administrator <Gitlab@bat.com>"
$mailSubject = "[Imp] - Gitlab Inactive Account Expiration";
$mailBody = '<p><font color = #1E457E face = "Calibri" size = "3"><i>Dear GitLab User,<br/><br/>It has been observed that you have not logged in to GitLab for more than 6 weeks.<b><font color=Red>Your GitLab access would be deactivated in next two days.</b></font><br/><br/>For any clarifications, pl reach out to <b><font color = #0563C1> BATPetra.DevOpsPI@itcinfotech.com</font></b>. This is an automated message, pl do not reply to it.<br/><br/>Regards,<br/>BAT PeTra DevOps Team<br/>BATPetra.DevOpsPI@itcinfotech.com</i></font></p>'
$smtpServer = 10.16.132.4
$SmtpServerPort = 25   
$Date = (Get-Date).AddDays(-62) | Get-Date -Format "yyyy-MM-dd"      

 $UserList = import-csv -Path "D:\BATPETRA\GitlabStat\New\GiltabUserList-2019-01-30.csv"  
 $UserList.Count  
 
 foreach($user in $UserList)
 
 {
   $gitlabUserName = $user.UserName 
   $lastActivity = [DateTime]$user.LastActivity
   $userEmailID = $user.EmailID

   if($lastActivity -lt $Date){
     
     $gitlabUserName | Out-File "D:\BATPETRA\GitlabStat\New\InactiveUser.txt" -Append

   }

 
 }