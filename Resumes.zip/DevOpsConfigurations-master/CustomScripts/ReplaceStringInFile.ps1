﻿
param(
 [Parameter(Mandatory=$True)]
 [string]
 $folderPath,

 [Parameter(Mandatory=$True)]
 [string]
 $findString,

 [Parameter(Mandatory=$True)]
 [string]
 $replaceString

)

Write-Host "-------------------------Input Paramerters---------------------------"
Write-Host "Root Folder Path:" $folderPath -ForegroundColor Yellow
Write-Host "Find String:" $findString -ForegroundColor Yellow
Write-Host "Replace String:" $replaceString -ForegroundColor Yellow

$files = Get-ChildItem $folderPath| Select-Object Name
$findstrings = $findString.Split(';')

Foreach($string in -split $findStrings)
 {
    Foreach($file in $files)
       {     
         $fileName= $file.Name
         $fileContent = Get-Content $folderPath'\'$fileName         
         #Write-Host "File name : $fileName" -ForegroundColor Green
         #Write-host  "Find string : $string"
         $fileContent -replace "$string", "$replaceString" | Set-Content $folderPath'\'$fileName
      }
} 

