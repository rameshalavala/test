﻿param( 
 [Parameter(Mandatory=$True)] 
 [string] 
 $ServerName, 
 [Parameter(Mandatory=$True)] 
 [string] 
 $DBName,
 [Parameter(Mandatory=$True)] 
 [string] 
 $ProcessPartition,
 [Parameter(Mandatory=$True)] 
 [string] 
 $RequiredPartitionName,
 [Parameter(Mandatory=$True)] 
 [string] 
 $NotRequiredPartitionName
) 

#Login
$User = "enter username"
$PWord = ConvertTo-SecureString -String "enter password" -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User, $PWord

 [Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices")
$loadInfo = [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices")
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices.Tabular");

$server = New-Object Microsoft.AnalysisServices.Server
#$server.Connect($ServerName)
$server.Connect("Data Source= $ServerName; Password=Petra@Bat3; User ID=85021163@bat.com")

Write-Output "Environment details are below "
Write-Output "SererName:"  $ServerName
Write-Output "DBName:"  $DBName

$DB = $server.Databases.FindByName($DBName)

foreach($table in $DB.Model.Tables)
{

if($ProcessPartition -eq "Yes")
{

foreach($part in $table.Partitions)
{

$text = $part.Name

if($text.EndsWith($RequiredPartitionName))

{
#Write-Output ("C.N: {0};   P.N: {1}" -f $table.Name, $part.Name)
$output=Invoke-ProcessPartition -PartitionName $text -TableName $table.Name -Database $DBName -RefreshType Full -Server $ServerName -Credential $Credential
if($?)
{
   Write-Output ("C.N: {0};____P.N: {1} ____has been Processsed Successfully" -f $table.Name, $text)
    Write-Output ("{0} 
                     |
                "-f $emptyspace )
  }
else
{
Write-Output ("C.N: {0};____P.N: {1} ____Process Failed------???____See Error Details above" -f $table.Name, $part.Name)
#Write-Output ("Error Details: {0}" -f $output)
Write-Output ("{0} 
                     |
                     |
                "-f $emptyspace )
   
}

}
else
{

if($text.EndsWith($NotRequiredPartitionName))

{
#Break

}
else
{
#Write-Output ("C.N: {0};   P.N: {1}" -f $table.Name, $part.Name)
$output=Invoke-ProcessPartition -PartitionName $text -TableName $table.Name -Database $DBName -RefreshType Full -Server $ServerName -Credential $Credential
if($?)
{
   Write-Output ("C.N: {0};____P.N: {1}____has been Processsed Successfully" -f $table.Name, $text)
    Write-Output ("{0} 
                     |
                "-f $emptyspace )
  }
else
{
Write-Output ("C.N: {0};____P.N: {1}____Process Failed------???____See Error Details above" -f $table.Name, $part.Name)
#Write-Output ("Error Details: {0}" -f $output)
Write-Output ("{0} 
                     |
                     |
                "-f $emptyspace )
   
}

}

} ##if-else 

}## foreach- partitian

}## if - processpartian
else
{

foreach($part in $table.Partitions)
{

$text = $part.Name
#Write-Output ("C.N: {0}" -f $table.Name)
$output = Invoke-ProcessPartition -PartitionName $text -TableName $table.Name -Database $DBName -RefreshType Full -Server $ServerName -Credential $Credential
if($?)
{
   Write-Output ("CubeName: {0} ____has been Processsed Successfully " -f $table.Name)
   Write-Output ("{0} 
                     |
                "-f $emptyspace )
  }
else
{


Write-Output ("CubeName: {0}____Process Failed------???____See Error Details above"  -f $table.Name)
Write-Output ("{0} 
                     |
                     |
                "-f $emptyspace )
   
}

}

}## else- processpartitian
}## foreach- table
#Petra PI Cube-R2_PL
#Petra PI Cube-R2_ANZ
#asazure://northeurope.asazure.windows.net/bataspdnepetrasit02
#asazure://northeurope.asazure.windows.net/bataspdnepetrauat03


 Write-Output ("{0} 
                     @@@
                "-f $emptyspace )
$output=Invoke-ProcessASDatabase -DatabaseName $DBName -Server $ServerName -RefreshType Calculate -Credential $Credential

if($?)
{
   Write-Output ("DBName: {0} ____ProcessRecalc has been done Successfully " -f $DBName)
   Write-Output ("{0} 
                     @@@
                "-f $emptyspace )
  }
else
{


Write-Output ("DBName: {0}____ProcessRecalc Failes------???____See Error Details above"  -f $DBName)
Write-Output ("{0} 
                     @@@
                "-f $emptyspace )

}