$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName Microsoft.Office.Interop.Excel
Function Fill-EmColumn
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)][String]$Folder
    )
    $ExcelFiles = Get-ChildItem -Path $Folder -Filter *.xlsx -Recurse

 

    $excelApp = New-Object -ComObject Excel.Application
    $excelApp.DisplayAlerts = $false

 

    $ExcelFiles | ForEach-Object {
        
        $filename = [system.IO.path]::GetFileNameWithoutExtension($_)
        $BR = "BR"
        $BRretrofit = "BR-Retrofit"
        Write-Host $filename
        $LastTwo = $filename.Substring($filename.get_Length()-2)
        
        if ($LastTwo -eq $BR)
            {
                $EM = $BRretrofit
            }
        else {
                $EM = $LastTwo
                }
        Write-Host $EM

        $workbook = $excelApp.Workbooks.Open($_.FullName)
        $ws = $workbook.worksheets.Item(1)
        $($ws.UsedRange.Rows)| Select -Skip 1 | ForEach{ $_.Cells.Item(10).Value2 = $EM }
        #$workbook.SaveAs($FolderPath + "\" + $file.Name)
        $workbook.Save()
        $workbook.Close()
    }

 

    # Release Excel Com Object resource
    $excelApp.Workbooks.Close()
    $excelApp.Visible = $true
    Start-Sleep 5
    $excelApp.Quit()
    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($excelApp) | Out-Null
}

 

#
# 0. Prepare the folder path which contains all excel files
$FolderPath = "D:\POWERBI MATRICES\TEST\test\"

 

Fill-EmColumn -Folder $FolderPath
