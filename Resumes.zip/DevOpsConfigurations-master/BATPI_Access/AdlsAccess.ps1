﻿################################adlsAccess###############################################################################################
#NAME: adlsAccess.ps1
#AUTHOR: NileshKumar Rawal
#DATE: 08/06/2018
#DESCRIPTION: This scripts deploys provides adls access to users.
#ARGUMENTS: $configurationFilePath
################################adlsAccess###############################################################################################

Param(

 [Parameter(Mandatory=$True)]
 [string]
 $configurationFilePath = "PIAzureDeploymentConfiguration.json"

)

$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"

Write-Verbose "Validating the Deployment Config file path"
If(Test-Path $ConfigurationFilePath)
{
   Write-Output "Getting Deployment configuration"
   $configurationContext = Get-Content -Path $ConfigurationFilePath | Out-String | ConvertFrom-Json
   Write-Verbose "Initializing the input variabales and parameters"
   $DeploymentEnv = $configurationContext.Environment 
   $subscriptionId = $configurationContext.SubscrptionID
   $resourceGroupName = $configurationContext.ResourceGroupName
   $AdlsName = $configurationContext.ADLS_Accountname
   $readerUsers = $configurationContext.Reader.UserList
   $contributorUser = $configurationContext.Contributor.Userlist

   if($readerUsers)
   {
     $userpermission = $configurationContext.Reader.Permssion
     foreach($user in $readerUsers)
       {
         $userID = $user.ID
          Write-Verbose "Providing $userpermission user access on ADLS service"
          Write-Verbose "Access Permission" 
          Write-verbose "User ID : $userID "
          Set-AzureRmDataLakeStoreItemAclEntry -AccountName $AdlsName -Path "/" -AceType User -Id $(Get-AzureRmADUser -Mail $userID ).Id -Permissions $userpermission
          Set-AzureRmDataLakeStoreItemAclEntry -AccountName $AdlsName -Path "/" -AceType User -Id $(Get-AzureRmADUser -Mail $userID ).Id -Permissions $userpermission -Default

       }
   
   }

   if($contributorUser)
   {
     $userpermission = $configurationContext.Contributor.Permssion
     foreach($user in $contributorUser)
       {
        
          $userID = $user.ID
          Write-Verbose "Providing $userpermission user access on ADLS service"
          Write-Verbose "Access Permission" 
          Write-verbose "User ID : $userID "
          Set-AzureRmDataLakeStoreItemAclEntry -AccountName $AdlsName -Path "/" -AceType User -Id $(Get-AzureRmADUser -Mail $userID ).Id -Permissions $userpermission
          Set-AzureRmDataLakeStoreItemAclEntry -AccountName $AdlsName -Path "/" -AceType User -Id $(Get-AzureRmADUser -Mail $userID ).Id -Permissions $userpermission -Default

       }
   
   }
}