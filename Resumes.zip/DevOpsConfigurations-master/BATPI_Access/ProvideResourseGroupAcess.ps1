﻿prama(
[parameter(Mandatory=$true)]
    [String]$UserBat_id,
    [String]$UserRole,
    [String]$ResourceGroupName
)

#provide acess to resource group level
New-AzureRmRoleAssignment -SignInName $UserBat_id -RoleDefinitionName $UserRole -ResourceGroupName $ResourceGroupName
