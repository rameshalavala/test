﻿prama(
[parameter(Mandatory=$true)]
    [String]$UserBat_id,
    [String]$UserRole,
    [String]$ResourceGroupName
)

#remove acess from resource group 
Remove-AzureRmRoleAssignment -SignInName $UserBat_id -ResourceGroupName $ResourceGroupName -RoleDefinitionName $UserRole
