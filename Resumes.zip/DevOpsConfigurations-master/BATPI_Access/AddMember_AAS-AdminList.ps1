﻿######################################AddMember_AAS-AdminLis###############################################################################################
#NAME: AddMember_AAS-AdminList.ps1
#AUTHOR: NileshKumar Rawal
#DATE: 30/10/2018
#DESCRIPTION: This script takes user[s] and adds to AAS analysis service admin list.
#ARGUMENTS: $subscriptionId, $resourceGroupName, $dataFactoryName, $analysisServiceName, $adminUserNameORList
######################################AddMember_AAS-AdminLis###############################################################################################
Param(

 [Parameter(Mandatory=$True)]
 [string]
 $subscriptionID,

 [Parameter(Mandatory=$True)]
 [string]
 $resourceGroupName,

 [Parameter(Mandatory=$True)]
 [string]
 $analysisServiceName,

 [Parameter(Mandatory=$True)]
 [string]
 $adminUserNameORList

)


$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"

# select subscription
Write-Output "Selecting subscription '$subscriptionId'";
$subscriptionContext = Select-AzureRmSubscription -SubscriptionID $subscriptionId;
Write-Output $subscriptionContext

#Getting Blob container URI and SAS token for setting up Backup for AAS
Write-Verbose "Getting Analysis service context...."
$aas_Context = Get-AzureRmAnalysisServicesServer -ResourceGroupName $resourceGroupName -Name $analysisServiceName -ErrorAction SilentlyContinue

if($aas_Context)
{

  Write-Verbose "Getting admin list of AAS server"

  $exitstingAdminList =  $aas_Context.AsAdministrators

    if($exitstingAdminList)
      {
          Write-Host "---------Exiting AAS server Admin List-----" 
          $exitstingAdminList
          $adminList = $exitstingAdminList -join ","
          $newAdminList = "$adminList" + "," + "$adminUserNameORList"

          Write-Verbose "Adding new member to AAS admin list"

          $output = Set-AzureRmAnalysisServicesServer -ResourceGroupName $resourceGroupName -Name $analysisServiceName -Administrator $newAdminList
          if(!($output))
          {
            Write-Verbose "added user to AAS admin list successfully "
          
          }
     }
     Else{
       Write-Verbose "Could not get the admin user list from provided analysis service, please check the analysis service running status"
     
     }


}

Else{
       Write-Error "Analysis service name '$analysisServiceName' does not exist or invalid.Exiting from current execution";

}


$currentAdminList = (Get-AzureRmAnalysisServicesServer -ResourceGroupName $resourceGroupName -Name $analysisServiceName -ErrorAction SilentlyContinue).AsAdministrators

Write-Verbose "-------------Current AAS Server Admit List ------"
$currentAdminList