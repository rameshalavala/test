﻿######################################Add-firewall-IP_AAS###############################################################################################
#NAME: Add-firewall-IP_AAS.ps1
#AUTHOR: NileshKumar Rawal
#DATE: 30/10/2018
#DESCRIPTION: This script updates the firewall rule with provided public ip range to aas server.
#ARGUMENTS: $subscriptionId, $resourceGroupName, $dataFactoryName, $analysisServiceName, $firewallIP
######################################Add-firewall-IP_AAS###############################################################################################
Param(

 [Parameter(Mandatory=$True)]
 [string]
 $subscriptionID,

 [Parameter(Mandatory=$True)]
 [string]
 $resourceGroupName,

 [Parameter(Mandatory=$True)]
 [string]
 $analysisServiceName,

[Parameter(Mandatory=$True)]
 [string]
 $firewallIP

)

$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"
if($firewallIP.Contains(','))
{
  
  $firewallIPs = $firewallIP.Split(',')

}

# select subscription
Write-Output "Selecting subscription '$subscriptionId'";
$subscriptionContext = Select-AzureRmSubscription -SubscriptionID $subscriptionId;
Write-Output $subscriptionContext

#Getting Blob container URI and SAS token for setting up Backup for AAS
Write-Verbose "Getting Analysis service context...."
$aas_Context = Get-AzureRmAnalysisServicesServer -ResourceGroupName $resourceGroupName -Name $analysisServiceName -ErrorAction SilentlyContinue

if($aas_Context)
{
   $newFirewallConfig = $aas_Context.FirewallConfig

    foreach( $Ip in $firewallIPs)
    {
      $Ip = $Ip.Split(':')
      $startIP = $IP[0]
      $endIP = $Ip[1]
      Start-Sleep -s 2
      $fireWallRuleName = "ClientIPAddress" + "_" + (Get-Date -Format yy-MM-dd_HH-mm-ss)

       Write-Verbose "IP Range Start: $startIP" 
       Write-Verbose "IP Range End:  $endIP "
       
       $newFirewallRule = New-AzureRmAnalysisServicesFirewallRule -FirewallRuleName $fireWallRuleName -RangeStart $startIP -RangeEnd $endIP
       #$newFirewallConfig = New-AzureRmAnalysisServicesFirewallConfig -EnablePowerBIService -FirewallRule $newFirewallRule

          If($newFirewallRule)
           {
        
             Write-Verbose "Adding firewall rule - $fireWallRuleName to existing config"         
             $newFirewallConfig.FirewallRules.Add($newFirewallRule)                    
           }
         else{
        
               Write-Error "Error in creating firewall rule or configuration"      
             }
      }

      if($newFirewallConfig)
     {
        Write-Verbose "Applying firewall config to provided analysis service" 
        Set-AzureRmAnalysisServicesServer -ResourceGroupName $resourceGroupName -Name $analysisServiceName -FirewallConfig $newFirewallConfig
      }
     else{
        
               Write-Error "Error in applying firewall configuration"      
            }
 }
     
 
Else{
       Write-Error "Analysis service name '$analysisServiceName' does not exist or invalid.Exiting from current execution";

}