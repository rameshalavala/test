#!/usr/bin/bash

﻿ #####################################Add_Ambari_User###############################################################################################
#NAME: Add_Ambari_User.sh
#AUTHOR: Ranjini M
#DATE: 11/14/2019
#DESCRIPTION: This script add a local user in Ambari and assign role (Cluster User) to the user which was created.
#ARGUMENTS: $clusterName, $Password
######################################Add_Ambari_User###############################################################################################

clusterName=$clusterName
password=$password

echo "Connecting to ambari"
echo "Adding local user to Ambari"
curl -iv -u admin:$password -H "X-Requested-By: ambari" -X POST -d '[{"Users/user_name":"localuser1","Users/password":"localuser@123","Users/active":true,"Users/admin":false}]' https://$clusterName.azurehdinsight.net/api/v1/users
echo "Adding the local user to Cluster group"
curl -iv -u admin:$password -H "X-Requested-By: ambari" -X POST -d '[{"PrivilegeInfo":{"permission_name":"CLUSTER.USER","principal_name":"localuser1","principal_type":"USER"}}]' https://$clusterName.azurehdinsight.net/api/v1/clusters/$clusterName/privileges
