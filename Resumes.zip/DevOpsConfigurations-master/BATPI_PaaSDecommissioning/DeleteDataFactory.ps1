﻿######################################DeleteDataFactory###############################################################################################
#NAME: DeleteDataFactory.ps1
#AUTHOR: NileshKumar Rawal
#DATE: 09/11/2018
#DESCRIPTION: This script decomissions the provided data factory from specified resource group.
#ARGUMENTS: $subscriptionId, $resourceGroupName, $dataFactoryName
######################################DeleteDataFactory###############################################################################################

param(
 [Parameter(Mandatory=$True)]
 [string]
 $subscriptionId,

 [Parameter(Mandatory=$True)]
 [string]
 $resourceGroupName,

 [Parameter(Mandatory=$True)]
 [string]
 $dataFactoryName
 
)

# sign in
Write-Host "Logging in...";
#Login-AzureRmAccount;

# select subscription
Write-Host "Selecting subscription '$subscriptionId'";
Select-AzureRmSubscription -SubscriptionID $subscriptionId;

#Getting cluster context  
$dataFactoryContext = Get-AzureRmDataFactory -Name $dataFactoryName -ResourceGroupName $resourceGroupName -ErrorAction SilentlyContinue 

if (($dataFactoryContext.DataFactoryName -ne ' ') -and ( $dataFactoryContext.ProvisioningState -ne ' ') )
{
  Write-Host "Data Factory Name : " $dataFactoryContext.DataFactoryName
  
  Write-Host "Deleting the data factory : " $dataFactoryContext.DataFactoryName
  Remove-AzureRmDataFactory -Name $dataFactoryContext.DataFactoryName -ResourceGroupName $resourceGroupName -Force 
  
 }

else
{
  Write-Host "Provided storage account is not exist in current resource group or ADLS name is not valid."
}

