﻿######################################DeleteAAS_Server###############################################################################################
#NAME: DeleteAAS_Server.ps1
#AUTHOR: NileshKumar Rawal
#DATE: 24/10/2018
#DESCRIPTION: This script decomissions the provided Azure Analysis service from specified resource group.
#ARGUMENTS: subscriptionId, resourceGroupName, aasServerName
######################################DeleteAAS_Server###############################################################################################

param(
 [Parameter(Mandatory=$True)]
 [string]
 $subscriptionId,

 [Parameter(Mandatory=$True)]
 [string]
 $resourceGroupName,

 [Parameter(Mandatory=$True)]
 [string]
 $aasServerName
 
 [Parameter(Mandatory=$True)]
 [string]
 $configurationFilePath = "PIAzureServicesConfiguration.json"

 
)

# sign in
Write-Host "Logging in...";
#Login-AzureRmAccount;

# select subscription
Write-Host "Selecting subscription '$subscriptionId'";
Select-AzureRmSubscription -SubscriptionID $subscriptionId;

#Getting cluster context  
$aasServerContext = Get-AzureRmAnalysisServicesServer -Name $aasServerName -ResourceGroupName $resourceGroupName -ErrorAction SilentlyContinue 

if ($aasServerContext)
{
  Write-Host "AAS Server Name : " $aasServerContext.ServerFullName
  
  
  Write-Host "Deleting the AAS server  : " $aasServerContext.Name
  Remove-AzureRmAnalysisServicesServer -Name $aasServerContext.Name -ResourceGroupName $resourceGroupName -Force
 
  
 }

else
{
  Write-Host "Provided AAS server is not exist in current resource group or server name is not valid."
}

