﻿######################################DeleteDataLakeStore###############################################################################################
#NAME: DeleteDataLakeStore.ps1
#AUTHOR: NileshKumar Rawal
#DATE: 24/10/2018
#DESCRIPTION: This script decomissions the provided data Lake store service from specified resource group.
#ARGUMENTS: subscriptionId, resourceGroupName, adlsName
######################################DeleteDataLakeStore###############################################################################################

param(
 [Parameter(Mandatory=$True)]
 [string]
 $subscriptionId,

 [Parameter(Mandatory=$True)]
 [string]
 $resourceGroupName,

 [Parameter(Mandatory=$True)]
 [string]
 $adlsName
 
)

# sign in
Write-Host "Logging in...";
#Login-AzureRmAccount;

# select subscription
Write-Host "Selecting subscription '$subscriptionId'";
Select-AzureRmSubscription -SubscriptionID $subscriptionId;

#Getting cluster context  
$adlsContext = Get-AzureRmDataLakeStoreAccount -Name $adlsName -ResourceGroupName $resourceGroupName -ErrorAction SilentlyContinue 

if (($adlsContext.name -ne ' ') -and ($adlsContext.ProvisioningState -ne ' ') )
{
  Write-Host "Data Lake Store Name : " $adlsContext.Name
  
  Write-Host "Deleting the data lake store : " $adlsContext.Name
  Remove-AzureRmDataLakeStoreAccount -Name $adlsContext.Name -ResourceGroupName $resourceGroupName -Force 
  
 }

else
{
  Write-Host "Provided data lake store is not exist in current resource group or ADLS name is not valid."
}

