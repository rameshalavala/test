﻿######################################DeleteStorageAccount###############################################################################################
#NAME: DeleteStorageAccount.ps1
#AUTHOR: NileshKumar Rawal
#DATE: 09/11/2018
#DESCRIPTION: This script decomissions the provided Storage Account service from specified resource group.
#ARGUMENTS: subscriptionId, resourceGroupName, StorageAccountName
######################################DeleteStorageAccount###############################################################################################

param(
 [Parameter(Mandatory=$True)]
 [string]
 $subscriptionId,

 [Parameter(Mandatory=$True)]
 [string]
 $resourceGroupName,

 [Parameter(Mandatory=$True)]
 [string]
 $storageAccountName
 
)

# sign in
Write-Host "Logging in...";
#Login-AzureRmAccount;

# select subscription
Write-Host "Selecting subscription '$subscriptionId'";
Select-AzureRmSubscription -SubscriptionID $subscriptionId;

#Getting cluster context  
$storageAccountContext = Get-AzureRmStorageAccount -Name $storageAccountName -ResourceGroupName $resourceGroupName -ErrorAction SilentlyContinue 

if (($storageAccountContext.StorageAccountName -ne ' ') -and ($storageAccountContext.ProvisioningState -ne ' ') )
{
  Write-Host "Storage Account Name : " $storageAccountContext.StorageAccountName
  
  Write-Host "Deleting the storage account : " $storageAccountContext.StorageAccountName
  Remove-AzureRmStorageAccount -Name $storageAccountContext.StorageAccountName -ResourceGroupName $resourceGroupName -Force 
  
 }

else
{
  Write-Host "Provided storage account is not exist in current resource group or ADLS name is not valid."
}

