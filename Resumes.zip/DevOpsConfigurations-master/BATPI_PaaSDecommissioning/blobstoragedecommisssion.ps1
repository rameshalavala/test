param(

 [Parameter(Mandatory=$True)]
 [string]
 $configurationFilePath = "PIAzureServicesConfiguration.json"

)

$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"
#Validate the input files path
  #setting up the input variables
  Write-Output "Getting Storage Account configuration"
  $configurationContext = Get-Content -Path $ConfigurationFilePath | Out-String | ConvertFrom-Json

  Write-Verbose "Initializing the input variabales and parameters"
  
  $subscriptionId = $configurationContext.SubscriptionID
  $resourceGroupName = $configurationContext.ResourceGroupName
  $storageAccountName  = $configurationContext.StorageAccount.ResourceName
  $resourceLocation = $configurationContext.StorageAccount.ResourceLocation
   
  Write-Output "----------------------------------Configuration parameter----------------------------------------- "
  
  Write-Output "SubscriptionID: " $subscriptionId
  Write-Output "Resource Group Name: " $resourceGroupName
  Write-Output "Resource Name: " $storageAccountName
  Write-Output "ResourceLocation: " $resourceLocation
  Write-Output "----------------------------- -------End Of parameters----------------------------------------------"

  # select subscription
  Write-Output "Selecting subscription '$subscriptionId'";
  $subscriptionContext = Select-AzureRmSubscription -SubscriptionID $subscriptionId;
  Write-Output "Selected Subcription Name: " 
  Write-Output $subscriptionContext

  #Check for existing resource group
  Write-Verbose "Validating the Resource Group"
  $resourceGroupExist = Get-AzureRmResourceGroup -Name $resourceGroupName -ErrorAction SilentlyContinue
  if(!$resourceGroupExist)
     {
       Write-Error "Resource group '$resourceGroupName' does not exist.Exiting from current deployment";
   
     }
  else{
         $storageAccountContext = Get-AzureRmStorageAccount -Name $storageAccountName -ResourceGroupName $resourceGroupName -ErrorAction SilentlyContinue 

if (($storageAccountContext.StorageAccountName -ne ' ') -and ($storageAccountContext.ProvisioningState -ne ' ') )
{
  Write-Host "Storage Account Name : " $storageAccountContext.StorageAccountName
  
  Write-Host "Deleting the storage account : " $storageAccountContext.StorageAccountName
  Remove-AzureRmStorageAccount -Name $storageAccountContext.StorageAccountName -ResourceGroupName $resourceGroupName -Force 
  Write-Host "Deleted the storage account : " $storageAccountContext.StorageAccountName
  
 }
        
         else{
             Write-Error "The storage account deletion has failed due to resource name is not available.Please check the log for more details"
            }
     
       }
 
 