﻿################################DeleteHDInsightCluster###############################################################################################
#NAME: DeleteHDInsightCluster.ps1
#AUTHOR: NileshKumar Rawal
#DATE: 08/06/2018
#DESCRIPTION: This script decomissions the provided HDInsight Cluster service from specified resource group.
#ARGUMENTS: subscriptionId, resourceGroupName, clusterName
################################DeleteHDInsightCluster###############################################################################################
param(
 [Parameter(Mandatory=$True)]
 [string]
 $subscriptionId,

 [Parameter(Mandatory=$True)]
 [string]
 $resourceGroupName,

 [Parameter(Mandatory=$True)]
 [string]
 $clusterName
 
)

# sign in
Write-Host "Logging in...";
#Login-AzureRmAccount;

select subscription
Write-Host "Selecting subscription '$subscriptionId'";
Select-AzureRmSubscription -SubscriptionID $subscriptionId;

#Getting cluster context  
$clusterContext = Get-AzureRmHDInsightCluster -ResourceGroupName $resourceGroupName -ClusterName $clusterName -ErrorAction SilentlyContinue

if ($clusterContext.ClusterState -eq 'Running')
{
  Write-Host "Cluster Name : " $clusterContext.Name
  Write-Host "Cluster httpENdpoint : " $clusterContext.HttpEndpoint 
  
  Write-Host "Deleting the HDIsight cluster : " $clusterContext.Name
  Remove-AzureRmHDInsightCluster -ResourceGroupName $resourceGroupName -ClusterName $clusterContext.Name -Force
  
 }

else
{
  Write-Host "Provided cluster is not exist in current resource group or cluster name is not valid."
}

