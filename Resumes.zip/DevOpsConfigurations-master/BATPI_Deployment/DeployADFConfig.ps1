﻿######################################DeployADFConfig##############################################################################################
#NAME: DeployADFConfig.ps1
#AUTHOR: NileshKumar Rawal
#DATE: 30/05/2018
#DESCRIPTION: This script deploys the json scripts(Linked service, DataSet and Pipeline) to the azure data factory service specified in 
#deployment configuration.
#ARGUMENTS: $configurationFilePath
#######################################DeployADFConfig##############################################################################################

Param(
  
 [Parameter(Mandatory=$True)]
 [string]
 $configurationFilePath = "PIAzureDeploymentConfiguration.json",

 [Parameter(Mandatory=$True)]
 [string]
 $DeploymentFolderPath,

 [Parameter(Mandatory=$True)]
 [string]
 $adfType

)

$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"

Write-Verbose "Validating the Deployment Config file path"
If(Test-Path $ConfigurationFilePath)
{
   Write-Output "---------------------------------------Getting Deployment configuration-------------------------------------"
   $configurationContext = Get-Content -Path $ConfigurationFilePath | Out-String | ConvertFrom-Json
   Write-Verbose "Initializing the input variabales and parameters"
   $DeploymentEnv = $configurationContext.Environment 
   $subscriptionId = $configurationContext.SubscrptionID
   $resourceGroupName = $configurationContext.ResourceGroupName
   #$deploymentFolderPath = $configurationContext.DeploymentFolderPath
   $RootFolderName = $configurationContext.ADF_Scripts.RootFolderName.$adfType
   $RootFolderPath = (Get-ChildItem -Path $DeploymentFolderPath -Include $RootFolderName -Directory -Recurse).FullName
   $DataFactoryName = $configurationContext.ADF_Scripts.DataFactoryName.$adfType
   $packageNumber = Split-Path $deploymentFolderPath -Leaf
  
   Write-Output "----------------------------------Deployment Configuration parameter----------------------------------------- "
   Write-Output "Enviroment Name : $DeploymentEnv"
   Write-Output "SubscriptionID: $subscriptionId"
   Write-Output "Resource Group Name: $resourceGroupName"
   Write-Output "Artifacts Version: $packageNumber"
   Write-Output "ADF Configs Root Folder Path: $RootFolderPath"
   Write-Output "Data Factory Name: $DataFactoryName"
   Write-Output "----------------------------------------End Of parameters-----------------------------------------------------"

   # select subscription
   Write-Output "Selecting subscription '$subscriptionId'";
   $subscriptionContext = Select-AzureRmSubscription -SubscriptionID $subscriptionId;
   Write-Output "Selected Subcription Name: " 
   Write-Output $subscriptionContext

   #Check for existing resource group
   Write-Verbose "Validating the Resource Group and Target Deploymment Service" 

   $resourceNameExist = (Get-AzureRmResource -ResourceName "$DataFactoryName" -ResourceGroupName $resourceGroupName).Name

    if($resourceNameExist)
     {
        $DFContext=Get-AzureRmDataFactory -Name $DataFactoryName -ResourceGroupName $ResourceGroupName
        $Folders = Get-ChildItem -dir -Path $RootFolderPath
         foreach($Folder in $Folders)
          {     
          $temp = $folders[0]
          $folders[0] = $folders[1]
          $folders[1]= $temp
        }

        Write-Output "ADF config deployment order:" $Folders

        Foreach($Folder in $Folders)
          {
            if($Folder.Name -like 'Linked*')
              {  
                              
                Write-Output "---------------------------------------------Deploying linked services to data factory------------------------------------------------------"
                $Files = Get-ChildItem -Path $Folder.FullName -Filter *.json
                $FileCount = $Files.Count
                Write-Output "Number Of Linked Services config files: $FileCount"
                Write-Verbose "Number Of Linked Services config files: $FileCount"
                Write-Verbose "Deploying Linked Service scripts to data factory"

               foreach($File in $Files)
                {
                  $LinkedServiceFileName = $File.Name
                  $LinkedServiceFilePath = $File.FullName
                  $LinkedServiceName = [System.IO.Path]::GetFileNameWithoutExtension($File.Name)
                 
                   If ($LinkedServiceFilePath -and $LinkedServiceName)
                     {
                       Write-Output "LinkedService File Path : " $LinkedServiceFilePath
                       Write-Output "LinkedService Name : " $LinkedServiceName
                       New-AzureRmDataFactoryLinkedService $DFContext -Name "$LinkedServiceName" -File "$LinkedServiceFilePath" -Force
                     }
                 }
              }

            if($folder.Name -like '*Pipeline*')
              {
              Write-Output "-----------------------------------------------Deploying Pipelines to data factory-----------------------------------------------------------"
              $Files = Get-ChildItem -Path $Folder.FullName -Filter *.json
              $FileCount =  $Files.Count
              Write-Verbose "Deploying Pipeline scripts to data factory"
              Write-Verbose "Number Of Pipelines config files: $FileCount"
              Write-Output "Number Of Pipelines config files: $FileCount"
              

             foreach( $File in $Files)
               {
                  $PipelineFileName = $File.Name
                  $PipelineFilePath = $File.FullName
                  $PipelineName = [System.IO.Path]::GetFileNameWithoutExtension($File.Name)
                  If ($PipelineFilePath -and $PipelineName)
                      {
                          
                          Write-Output "Pipeline Name : " $PipelineName 
                          Write-Output "Pipeline File Path : " $PipelineFilePath
                          $output = New-AzureRmDataFactoryPipeline $DFContext -Name "$PipelineName" -File "$PipelineFilePath" -Force -ErrorAction SilentlyContinue
                          Write-Output $output
                       }
                }
          }
            if($folder.Name -like '*dataset*')
             {
                    
                    Write-Output "-----------------------------------------Deploying DataSets to data factory-----------------------------------------------------------"              
                    $Files = Get-ChildItem -Path $Folder.FullName -Filter *.json
                    $FileCount =  $Files.Count
                    Write-Output "Number Of DataSets config files:  $FileCount"
                    Write-Verbose "Deploying Datasets scripts to data factory"
                    Write-Verbose "Number Of DataSets config files: $FileCount"
                    

                     foreach($File in $Files)
                     {
                        $DataSetFileName = $File.Name                      
                        $DataSetFilePath = $File.FullName
                        $DataSetName = [System.IO.Path]::GetFileNameWithoutExtension($File.Name)
                         If ($DataSetFilePath -and $DataSetName)
                           {
                              Write-Output "DataSet Name : " $DataSetName
                              Write-Output "DataSet File Path : " $DataSetFilePath                              
                              New-AzureRmDataFactoryDataset $DFContext -Name $DataSetName -File $DataSetFilePath -Force -ErrorAction SilentlyContinue         
                           }
                      }
                }
          }
     }
     Else
        {
        
        Write-Error "The provided data factory name did not get found.Exiting from deployment..Please check the log for more details" 
    
    }

}