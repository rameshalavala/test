﻿######################################DeployMaster_ConfigScripts##############################################################################################
#NAME: DeployMaster_ConfigScripts.ps1
#AUTHOR: NileshKumar Rawal
#DATE: 26/11/2018
#DESCRIPTION: This script does the ENV changes in master configs scripts mentioned in the input configuration file and deploys the Master Configs scripts 
#to azure data lake store in target env.
#ARGUMENTS: $configurationFilePath,$DeploymentFolderPath
#######################################DeployMaster_ConfigScripts##############################################################################################

Param (
  
 [Parameter(Mandatory=$True)]
 [string]
 $configurationFilePath = "PIAzureDeploymentConfiguration.json",

 [Parameter(Mandatory=$True)]
 [string]
 $DeploymentFolderPath

)

Function ReplaceStringInFile
{
param(
 [Parameter(Mandatory=$True)]
 [string]
 $folderPath,

 [Parameter(Mandatory=$True)]
 [string]
 $findString,

 [Parameter(Mandatory=$True)]
 [string]
 $replaceString

)

Write-Host "-------------------------Input Paramerters---------------------------"
Write-Host "Root Folder Path:" $folderPath -ForegroundColor Yellow
Write-Host "Find String:" $findString -ForegroundColor Yellow
Write-Host "Replace String:" $replaceString -ForegroundColor Yellow

$files = Get-ChildItem $folderPath| Select-Object Name 
$findstrings = $findString.Split(';')

Foreach($string in -split $findStrings)
 {
    Foreach($file in $files)
       {     
         $fileName= $file.Name
         $fileContent = Get-Content $folderPath'\'$fileName         
         #Write-Host "File name : $fileName" -ForegroundColor Green
         #Write-host  "Find string : $string"
         $fileContent -replace "$string", "$replaceString" | Set-Content $folderPath'\'$fileName
      }
 } 
}

Function UpdateServicePrincipalDetails
{

param(

 [Parameter(Mandatory=$True)]
 [string]
 $folderPath,

 [Parameter(Mandatory=$True)]
 [string]
 $tag,

 [Parameter(Mandatory=$True)]
 [string]
 $replaceValue

)
 
Write-Output "-------------------------Input Paramerters for deployment changes---------------------------"
Write-Output "Root Folder Path:" $folderPath -ForegroundColor Yellow
Write-Output "Find Tag :" $tag -ForegroundColor Yellow
Write-Output "Replace with:" $replaceValue -ForegroundColor Yellow


$files = Get-ChildItem $folderPath| Select-Object Name
#$findstrings = $findString.Split

 Foreach($file in $files)
       {     
         $fileName= $file.Name
         $fileContent = Get-Content $folderPath'\'$fileName         
         
         $matchedString = $fileContent -cmatch $tag
         if($matchedString)
         {
            $splittedString = $matchedString -split $tag
            $findValue = $splittedString[1]
            if($findValue)
              {            
                $fileContent -replace [Regex]::Escape($findValue), "$replaceValue" | Set-Content $folderPath'\'$fileName         
              }       
          }
          Else{
               Write-Error "Could not find the Master config changes for deployment, please check the Master config files"
          
          }
       
         
      }

}

$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"

Write-Verbose "PreParing the artifacts to deploy in Requested environment"
Write-Verbose "Validating the Deployment Config file path"
If(Test-Path $ConfigurationFilePath)
{
   Write-Host "-------------------------------Pre-Deployment Activity----------------------------------------------"
   $configurationContext = Get-Content -Path $ConfigurationFilePath | Out-String | ConvertFrom-Json
   Write-Verbose "Initializing the input variabales and parameters"
   $DeploymentEnv = $configurationContext.Environment 
   $subscriptionId = $configurationContext.SubscrptionID
   $resourceGroupName = $configurationContext.ResourceGroupName
   #$deploymentFolderPath = $configurationContext.DeploymentFolderPath
   $RootFolderName = $configurationContext.MasterConfigs_Scripts.RootFolderName
   $RootFolderPath = (Get-ChildItem -Path $DeploymentFolderPath -Include $RootFolderName -Directory -Recurse).FullName
   $ADLSName = $configurationContext.MasterConfigs_Scripts.ADLSName
   $FindString = $configurationContext.MasterConfigs_Scripts.FindString
   $ReplaceString = $configurationContext.MasterConfigs_Scripts.ReplaceString
   $servicePrincipalID = $configurationContext.MasterConfigs_Scripts.ServicePrincipalID
   $servicePrincipalKey = $configurationContext.MasterConfigs_Scripts.ServicePrincipalKey
   $ConfigurationsPath = $configurationContext.MasterConfigs_Scripts.MasterConfigPath
   $fullADLSName = "$ADLSName" + ".azuredatalakestore.net"
   
   $packageNumber = Split-Path $deploymentFolderPath -Leaf
   Write-Output "----------------------------------Deployment Configuration parameter----------------------------------------- "
   Write-Output "Enviroment Name : $DeploymentEnv"
   Write-Output "SubscriptionID: $subscriptionId"
   Write-Output "Resource Group Name: $resourceGroupName"
   Write-Output "Artifacts Version: $packageNumber"
   Write-Output "RootFolderPath: $RootFolderPath"
   Write-Output "Configuration Path for Deployment: $ConfigurationsPath"
   Write-Output "ENV Changes - Find string: $FindString"
   Write-Output "ENV Changes - Replace String: $ReplaceString"
   Write-Output "----------------------------------------End Of parameters-----------------------------------------------------"
   
   # select subscription
   Write-Output "Selecting subscription '$subscriptionId'";
  # $subscriptionContext = Select-AzureRmSubscription -SubscriptionID $subscriptionId;
   Write-Output "Selected Subcription Name: " 
   Write-Output $subscriptionContext

   #Check for existing resource group
   Write-Verbose "Validating the Target deployment resource"
   #Create or check for target resource 
   $resourceNameExist = (Get-AzureRmResource -ResourceName "$ADLSName" -ResourceGroupName $resourceGroupName).Name
   
     if(!$resourceNameExist)
            { 
              Write-Error "Resource name '$resourceNameExist' does not exist.Exiting from current deployment";
            }
      Else{
             Write-Output "Getting the configuration for ENV changes"
             Write-Verbose "Getting the Configuration files for ENV changes"
              for($i=0; $i -lt $ConfigurationsPath.Length; $i++)
                {
                  $filesCount = 0
                  $sourcePath = $ConfigurationsPath[$i].SourcePath
                  $destinationPath = $ConfigurationsPath[$i].DestinationPath
                  $deployValue = $ConfigurationsPath[$i].Deploy
                  
                       $FolderPath = "$RootFolderPath" + "\" + "$sourcePath" 
                       Write-Output "Deploy value: $deployValue"
                       Write-Output "FolderPath: $FolderPath"                 
                       ReplaceStringInFile -folderPath $FolderPath -findString $FindString -replaceString $ReplaceString
                       UpdateServicePrincipalDetails -folderPath $FolderPath -tag ":=ClientId:=" -replaceValue $servicePrincipalID
                       UpdateServicePrincipalDetails -folderPath $FolderPath -tag ":=ClientKey:=" -replaceValue $servicePrincipalKey
                       $Files = Get-ChildItem -Path $FolderPath -File -Recurse -Include "*.txt"
                       $filesCount = $Files.Count
                       Write-Output "Deploying the Config files from path: $sourcePath"
                       Write-Verbose "Deploying the Config files from path: $sourcePath"
                       Write-Verbose "Number of config file  Config files: $filesCount "

                    ForEach($file in $Files)
                      { 
                        $fileName = $file.Name
                        $filePath = $file.FullName
                        $destinationFilePath = "$destinationPath" + "/" + "$fileName"
                        Import-AzureRmDataLakeStoreItem -AccountName $fullADLSName -Path "$filePath" -Destination "$destinationFilePath" -Force
              
                      }
                }

        }
}